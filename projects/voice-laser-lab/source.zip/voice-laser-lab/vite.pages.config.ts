import { fileURLToPath } from 'node:url';
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

const fromRoot = (path: string) => fileURLToPath(new URL(path, import.meta.url));

export default defineConfig({
  root: fromRoot('./pages/'),
  publicDir: fromRoot('./public/'),
  base: './',
  plugins: [react()],
  define: { __VOICE_LASER_BASE_URL__: JSON.stringify('./') },
  build: {
    outDir: fromRoot('./dist-pages/'),
    emptyOutDir: true,
    copyPublicDir: false,
    sourcemap: false,
  },
});
