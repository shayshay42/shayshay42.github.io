# Voice Laser Lab source

This archive contains the editable source for the static Voice Laser Lab application, including its Strudel editor, audio worklet, membrane and mirror simulation, recorder, and Draw a sound solver.

## Build and run

Unzip the archive and open a terminal in `voice-laser-lab`. Use Node.js 22.13 or later and npm.

```sh
npm ci
npm test
npm run build:pages
python3 -m http.server 8000 --directory dist-pages
```

Open [the local lab](http://localhost:8000/). The build generates the workers, poster, browser bundles, notices, and a fresh source ZIP. GitHub Pages serves the same static files beneath `projects/voice-laser-lab/`. The notebook adds its site analytics script to the exported HTML.

Edit the main interface in `src/components/Lab.tsx`, the Strudel mixer in `src/audio/strudel.ts`, and the inverse solver in `src/inverse/`. The optical and mechanical model is described in `docs/physics.md`.

## Licensing and assets

The Voice Laser Lab application code is copyright 2026 Shayan Hajhashemi and licensed under **AGPL-3.0-or-later**. The full license is in `LICENSE.txt`. Third-party components and assets retain their respective terms, collected in `THIRD-PARTY-NOTICES.txt`.

- The vendored Strudel browser engine is `@strudel/web` 1.3.0. The exact editable upstream sources are available for download. [Strudel source archive](https://codeberg.org/uzu/strudel/archive/f610965f4332837febe45743105da170e8b331ed.tar.gz)
- The human model and its CC0 notice are in `public/models/human/`. The three local percussion samples are synthesized one-shots. The online piano preset fetches Alexander Holm’s Salamander Grand Piano V3 from the dough-samples library. [Piano samples and credits](https://github.com/felixroos/dough-samples#piano)
- John Berger’s drawing of Yasmine Hamdan and the excerpt from *Some Notes on Song* retain their original rights. When the local illustration is absent, the build fetches it from a pinned notebook revision and verifies its SHA-256. For an offline rebuild, place that image in `public/art/john-berger-yasmine-hamdan.png` before building. The credit, original source, and checksum are in `public/art/john-berger-source.json`. [Pinned image](https://raw.githubusercontent.com/shayshay42/shayshay42.github.io/7c627ee8e56f3f1197a8a17b0461efb626f09f42/projects/voice-laser-lab/art/john-berger-yasmine-hamdan.png)
