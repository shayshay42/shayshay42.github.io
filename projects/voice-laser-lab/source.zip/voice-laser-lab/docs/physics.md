# From audio to the laser path

The simulator is a driven dynamical system. Its state contains six membrane displacements and six velocities. The spot position on the wall follows from that state through mirror geometry.

For fixed settings, the mechanical equations are linear. The optical equations are nonlinear. The beam has no separate inertial state.

$$
u(t)\ \longrightarrow\ \mathbf q(t)\ \longrightarrow\ w(x,y,t)
\ \longrightarrow\ (\mathbf c,\mathbf n)
\ \longrightarrow\ (\mathbf m,\mathbf r)
\ \longrightarrow\ (X,Y).
$$

## 1. Audio supplies the input

Let $u(t)$ be the mono PCM signal. PCM stores samples of an audio waveform. The samples are dimensionless.

Their scale depends on the recording and the input device. The simulator does not convert them to measured pressure in pascals.

Let $G$ be the input gain. The engine uses an illustrative acceleration scale of 1800. A spatial force pattern sets the coupling to each mode.

$$
f_\epsilon(x,y)=1+\epsilon\left(\frac{x}{R}+0.83\frac{y}{R}\right),
\qquad
\alpha_i=\frac{1}{\pi R^2}\int_{x^2+y^2\le R^2}\phi_i(x,y)f_\epsilon(x,y)\,\mathrm dA,
\qquad
\beta_i=1800\,G\,\alpha_i.
$$

The parameter $\epsilon$ is the asymmetry control. The membrane radius is $R=0.05\,\mathrm m$. The coefficient $\alpha_i$ is the overlap between the assumed force pattern and mode $i$.

The mode shape $\phi_i$ has unit area RMS. RMS means root mean square. The coefficient $\beta_i$ sets the modal acceleration per unit input.

The current engine uses the sample waveform directly. It does not use an FFT or assign frequencies to drawn ellipses.

Source: [forcing coefficients](../src/physics/engine.ts#L337).

## 2. Six modes store the motion

Each mode is a fixed spatial vibration pattern. Its amplitude changes with time. For each mode $i=1,\ldots,6$:

$$
\frac{\mathrm d^2q_i}{\mathrm dt^2}
+2\zeta_i\omega_i\frac{\mathrm dq_i}{\mathrm dt}
+\omega_i^2q_i
=\beta_i u(t).
$$

The displacement $q_i$ uses metres. Time $t$ uses seconds. The damping ratio $\zeta_i$ is dimensionless, and $\omega_i$ is the natural angular frequency in radians per second.

All six equations receive the same input. Each mode has its own frequency, damping, and coupling.

Let $\mathbf q=(q_1,\ldots,q_6)^{\mathsf T}$ and $\mathbf v=\mathrm d\mathbf q/\mathrm dt$. Define the twelve-component state:

$$
\mathbf s=\begin{pmatrix}\mathbf q\\\mathbf v\end{pmatrix},
\qquad
\frac{\mathrm d\mathbf s}{\mathrm dt}=A\mathbf s+B u,
$$

$$
A=\begin{pmatrix}0&I\\-\Omega^2&-2Z\Omega\end{pmatrix},
\qquad
B=\begin{pmatrix}0\\\boldsymbol\beta\end{pmatrix},
\qquad
\Omega=\operatorname{diag}(\omega_1,\ldots,\omega_6),
\qquad
Z=\operatorname{diag}(\zeta_1,\ldots,\zeta_6).
$$

The matrix $I$ is the six-dimensional identity matrix. The column $\boldsymbol\beta$ contains the six input coefficients. These matrices remain constant while the controls remain fixed.

A change to a control can change the matrices. The engine keeps the current displacements and velocities when it applies that change.

### The coefficients in this implementation

The six modes contain two radial patterns and two orthogonal pairs of dipole patterns. A dipole pattern has opposite signs on opposite sides of the membrane.

Their Bessel roots are:

$$
\boldsymbol\chi=(2.40482556,\ 5.52007811,\ 3.83170597,\ 3.83170597,\ 7.01558667,\ 7.01558667).
$$

Let $T$ be the relative tension. Let $\zeta_*$ be the damping control. The engine sets:

$$
\omega_i=2\pi(125)\frac{\chi_i}{\chi_1}\sqrt{T}\,(1+\sigma_i\epsilon),
\qquad
\zeta_i=\delta_i\zeta_*,
$$

$$
\boldsymbol\sigma=(0,0,-0.55,0.55,-0.30,0.30),
\qquad
\boldsymbol\delta=(2.8,2,1,1,1.15,1.15).
$$

Asymmetry changes the dipole frequencies and their input coupling. At zero asymmetry, uniform forcing does not drive the dipole modes.

A system that starts at rest then has no centred-mirror tilt. An existing dipole motion can still decay after the asymmetry control reaches zero.

Source: [mode constants](../src/physics/engine.ts#L74), [coefficient construction](../src/physics/engine.ts#L337).

## 3. The modes define the membrane surface

The height of the membrane is a sum of the six patterns:

$$
w(x,y,t)=\sum_{i=1}^{6}\phi_i(x,y)q_i(t).
$$

The coordinates $x$ and $y$ lie in the resting membrane plane. Let $\rho=\sqrt{x^2+y^2}/R$, and let $\vartheta$ be the angle around its centre.

The two radial shapes use $J_0(\chi_i\rho)/N_i$. The dipole shapes use $J_1(\chi_i\rho)\cos\vartheta/N_i$ or $J_1(\chi_i\rho)\sin\vartheta/N_i$.

The functions $J_0$, $J_1$, and $J_2$ are Bessel functions. The normalizers are:

$$
N_i=|J_1(\chi_i)|\quad\text{for radial modes},
\qquad
N_i=\frac{|J_2(\chi_i)|}{\sqrt2}\quad\text{for dipole modes}.
$$

These shapes vanish at the rim. Their normalization makes each modal displacement comparable in units of metres.

Source: [mode shapes and normalization](../src/physics/engine.ts#L116).

## 4. A plane fit gives the mirror pose

The mirror has radius $R_m=0.008\,\mathrm m$. The engine fits a plane over its circular reference footprint.

It does not use only the surface gradient at the centre. It also does not solve separate equations for mirror rotation.

The plane fit minimizes:

$$
\int_{x^2+y^2\le R_m^2}
\left[w(x,y,t)-c_z-g_xx-g_yy\right]^2\,\mathrm dA.
$$

The fitted height is $c_z$. The fitted slopes are $g_x$ and $g_y$. The mirror centre and unit normal are:

$$
\mathbf c=(0,0,c_z),
\qquad
c_z=\mathbf h^{\mathsf T}\mathbf q,
\qquad
g_x=\mathbf k_x^{\mathsf T}\mathbf q,
\qquad
g_y=\mathbf k_y^{\mathsf T}\mathbf q,
$$

$$
\mathbf n=\frac{(-g_x,-g_y,1)}{\sqrt{1+g_x^2+g_y^2}}.
$$

The columns $\mathbf h$, $\mathbf k_x$, and $\mathbf k_y$ contain fixed fit weights. Only radial modes contribute to $\mathbf h$. Each dipole pair contributes to the two slope columns.

For a radial mode, set $\xi_i=\chi_iR_m/R$. Its height weight is:

$$
h_i=\frac{2J_1(\xi_i)}{\xi_iN_i}.
$$

For a dipole mode, set $\kappa_i=\chi_i/R$. Its nonzero slope weight is:

$$
\ell_i=\frac{4J_2(\kappa_iR_m)}{\kappa_iR_m^2N_i}.
$$

Thus $\mathbf k_x=(0,0,\ell_3,0,\ell_5,0)^{\mathsf T}$ and $\mathbf k_y=(0,0,0,\ell_4,0,\ell_6)^{\mathsf T}$. The remaining height and slope weights are zero.

This fit gives the mirror a pose without adding mechanical states. The model omits feedback from the mirror and glue into the membrane motion.

Source: [finite-footprint weights](../src/physics/engine.ts#L120), [mirror pose](../src/physics/engine.ts#L379).

## 5. The ray equations give the wall coordinates

The resting membrane lies at $z=0$. Positive $z$ points toward the wall. The fixed laser position and incoming unit direction are:

$$
\mathbf a=(0.075,0,0.32)\,\mathrm m,
\qquad
\mathbf d=-\frac{\mathbf a}{\|\mathbf a\|}.
$$

The incoming beam aims at the resting mirror centre. Its intersection with the current mirror plane is:

$$
\tau=\frac{(\mathbf c-\mathbf a)\cdot\mathbf n}{\mathbf d\cdot\mathbf n},
\qquad
\mathbf m=\mathbf a+\tau\mathbf d.
$$

The scalar $\tau$ is distance along the incoming ray. The point $\mathbf m$ is the reflection point. The centred dot denotes the vector dot product.

The reflected unit direction is:

$$
\mathbf r=\mathbf d-2(\mathbf d\cdot\mathbf n)\mathbf n.
$$

The wall plane lies at $z=L$. The parameter $L$ measures distance from the resting membrane plane. It is the wall-distance control.

$$
\lambda=\frac{L-m_z}{r_z},
\qquad
X=m_x+\lambda r_x,
\qquad
Y=m_y+\lambda r_y.
$$

The scalar $\lambda$ is distance along the reflected ray. The coordinates $X$ and $Y$ locate the spot on the wall.

These equations define the output map $H$:

$$
(X,Y)=H(\mathbf s).
$$

The normal calculation and ray intersections make this map nonlinear. The optical calculation uses the current displacement state. It ignores light travel time.

When the mirror has no tilt, axial motion can still move the spot. For this laser position, a valid hit satisfies:

$$
\Delta X=2\frac{a_x}{a_z}c_z,\qquad \Delta Y=0,\qquad \mathbf n=(0,0,1).
$$

The shifts are relative to the resting spot. This motion comes from translation at oblique incidence.

A valid spot must satisfy all these conditions:

- The incoming ray is not parallel to the mirror plane.
- The intersection lies ahead of the laser.
- The intersection lies within the mirror disk.
- The reflected ray points toward the wall and reaches it in the forward direction.
- The wall point lies inside the active rectangle.

The disk condition is $\|\mathbf m-\mathbf c\|\le R_m$. The wall target is 2 m wide and 2 m high.

Its centre is $X_0=-a_xL/a_z$ and $Y_0=0$. The engine therefore requires $|X-X_0|\le1$ and $|Y|\le1$.

The code uses small tolerances near parallel rays. A miss returns an invalid flag and NaN coordinates. The renderer leaves a gap in the trace.

Source: [fixed incoming ray](../src/physics/engine.ts#L171), [mirror and wall intersections](../src/physics/engine.ts#L177).

## 6. Audio time drives the update

The engine advances once per audio sample. Let $F_s$ be the sample rate in hertz. Each sample lasts $\Delta t=1/F_s$ seconds.

The input stays constant within that interval. The exact update for the fixed linear system is:

$$
\mathbf s_{n+1}=F\mathbf s_n+B_d u_n,
\qquad
F=e^{A\Delta t},
\qquad
B_d=\int_0^{\Delta t}e^{A(\Delta t-\tau)}B\,\mathrm d\tau.
$$

The implementation uses the closed-form update for each oscillator. It handles underdamped, critically damped, and overdamped modes.

The update is exact for this constant-input model, apart from floating-point error. It does not use the browser animation frame interval.

The engine calculates a wall point after each sample. The visible trail is the recent history of $X$ and $Y$. The renderer controls its visible persistence.

Persistence does not change the mechanical state. The beam has no separate inertial state.

The 3D room scales its display. The engine still uses metres and the original geometry.

Source: [sample loop](../src/physics/engine.ts#L310), [closed-form coefficients](../src/physics/engine.ts#L337).

## 7. What this permits for inverse audio

One input drives both outputs. Their responses differ because their modal weights and resonances differ.

Near a valid resting configuration, the optical map can be linearized. Then each output has a fixed transfer function:

$$
\widehat{\Delta X}(\omega)=T_X(\omega)\widehat u(\omega),
\qquad
\widehat{\Delta Y}(\omega)=T_Y(\omega)\widehat u(\omega).
$$

The hat denotes a Fourier transform here. The engine does not compute these transforms during playback.

Where $T_X$ is nonzero, the output ratio follows $T_Y/T_X$. Two arbitrary coordinate signals may therefore require incompatible inputs.

The drawing solver samples one ordered loop and searches over integer audio periods. For each harmonic it fits a single complex audio coefficient to both wall coordinates using regularized least squares. A penalty on input energy and a peak bound limit the drive. Dynamic programming can vary progress along the stroke while requiring a full traversal.

For a drawing with free timing, the solver measures point-to-segment distances in both directions. It fits Fourier coefficients to reduce those distances and uses a monotone timing match to retain the stroke order. It screens several ranges of loop periods, refines promising waveforms with up to 32 harmonics below Nyquist, and tests small changes in loop speed.

A fast crossing can draw a long line in just a few audio samples. An extra refinement weights errors by the length of the visible trace and gives the worst 5% of that length extra weight. The final comparison uses the replayed trace. A prescribed timing retains the timed tracking search. Optional membrane fitting screens tension, damping, and asymmetry, then compares finalists at the original sample rate. A measured response table stays tied to its calibrated rig.

The solver replays promising waveforms through the nonlinear optics. It estimates the steady periodic state of each oscillator and checks convergence from rest before scoring the final loop. It corrects the harmonic amplitudes and phases using the remaining tracking error. The returned trace corresponds to the final period of the actual exported samples. Target coverage and off-stroke light use a tolerance of 4% of the drawing's longest sampled span. A single-input fit with rounded corners or unvisited strokes remains visible in the overlay.

For a timed path from rest, the benchmark also solves the finite-horizon Riccati recursion for linearized wall tracking and a quadratic audio-effort penalty. It reports RMS error after replay through the nonlinear simulator. The physical calibration tool can fit the same harmonic inverse to measured frequency responses. Its correction command uses camera measurements of repeated playback. [Hardware workflow](inverse-hardware.md).

## Limits of this model

The membrane equations assume small motion and fixed mode shapes. The coefficients use an illustrative force scale, not a pressure calibration.

The model omits detailed tube acoustics, nonlinear rubber behavior, and separate mirror inertia. It also omits diffraction and light travel time.

The geometric reflection equations remain exact within the ideal ray model. The complete model is an approximation to a real balloon-and-mirror toy.
