import { useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import { Lab } from '../src/components/Lab';
import { assetPath } from '../src/asset-path';
import '../app/globals.css';
import './notebook.css';

function NotebookPage() {
  useEffect(() => {
    if (window.location.hash === '#on-listening') {
      document.getElementById('on-listening')?.scrollIntoView();
    }
  }, []);

  return (
    <>
      <nav className="notebook-navigation" aria-label="Personal website">
        <a href="../../#projects">← Back to the notebook</a>
      </nav>
      <Lab intro={<section className="listening-note" id="on-listening" aria-labelledby="listening-title">
        <figure className="listening-sketch">
          <a href={assetPath('art/john-berger-yasmine-hamdan.png')} target="_blank" rel="noopener" aria-label="Open John Berger’s sketch of Yasmine Hamdan at full size">
            <img src={assetPath('art/john-berger-yasmine-hamdan.png')} width="730" height="573" fetchPriority="high" decoding="async" alt="John Berger’s loose line sketch of Yasmine Hamdan singing." />
          </a>
          <figcaption>
            John Berger’s sketch of Yasmine Hamdan.{' '}
            <a href="https://hummusforthought.com/2018/12/17/listening-the-aural-resonance-of-a-formless-line/">Image source</a>
          </figcaption>
        </figure>
        <div className="listening-copy">
          <h1 id="listening-title">On listening</h1>
          <blockquote>
            <p>“There’s a rhythm in these scribbles — as though my pen were accompanying your voice.”</p>
          </blockquote>
          <p className="listening-credit">
            John Berger, <cite><a href="https://harpers.org/archive/2015/02/some-notes-on-song/">Some Notes on Song</a></cite> (2015)
          </p>
          <p className="listening-reflection">A pen is not a mouth organ. A song needs a body and borrows one.</p>
          <p className="listening-closing">Listening is the song borrowing you.</p>
        </div>
      </section>} />
    </>
  );
}

// Vinext also discovers this static entry while loading its server routes.
const host = typeof document !== 'undefined' && document.getElementById('root');
if (host) createRoot(host).render(<NotebookPage />);
