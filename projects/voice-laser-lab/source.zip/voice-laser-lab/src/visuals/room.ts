import * as THREE from "three";
import { neutralWallX, TOY } from "../physics/engine";
import { assetPath } from "../asset-path";

const LEFT = -2;
const RIGHT = 1.5;
const FRONT = -1.6;
const FLOOR = -1.8;
const HEIGHT = 3.6;
const POSTER_WIDTH = 1.35;
const POSTER_HEIGHT = 1.65;

/** Deterministic fine surface relief. It affects materials, never the simulation. */
function surfaceRelief(seed: number, repeat: number): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = 256;
  const context = canvas.getContext("2d")!;
  const image = context.createImageData(256, 256);
  for (let i = 0; i < image.data.length; i += 4) {
    seed = (1664525 * seed + 1013904223) >>> 0;
    const value = 128 + ((seed >>> 24) - 128) * 0.22;
    image.data[i] = image.data[i + 1] = image.data[i + 2] = value;
    image.data[i + 3] = 255;
  }
  context.putImageData(image, 0, 0);
  const texture = new THREE.CanvasTexture(canvas);
  texture.name = "Fine plaster / floor relief";
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(repeat, repeat);
  return texture;
}

function physicsPoster(): { texture: THREE.Texture; ready: Promise<void> } {
  let resolveReady!: () => void;
  let rejectReady!: (error: Error) => void;
  const ready = new Promise<void>((resolve, reject) => {
    resolveReady = resolve;
    rejectReady = reject;
  });
  const texture = new THREE.TextureLoader().load(
    assetPath("generated/physics-poster.png"),
    () => resolveReady(),
    undefined,
    () => rejectReady(new Error("The physics poster could not load. Rebuild the poster asset and reload.")),
  );
  texture.name = "Sound, motion and light — MathJax physics poster";
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 8;
  return { texture, ready };
}

/** Room coordinates match the uniformly scaled optics used by the renderer. */
export function createLabRoom(displayDistance: number, opticalScale = 1.6): {
  group: THREE.Group;
  update(distance: number): void;
  textures: THREE.Texture[];
  posterTarget: THREE.Vector3;
  bounds: THREE.Box3;
  ready: Promise<void>;
} {
  const group = new THREE.Group();
  group.name = "Acoustics and optics room";
  const plaster = surfaceRelief(21401, 4);
  const floorRelief = surfaceRelief(61781, 5);
  const { texture: posterTexture, ready } = physicsPoster();
  const textures: THREE.Texture[] = [plaster, floorRelief, posterTexture];
  const wallMaterial = new THREE.MeshStandardMaterial({ color: 0xe8e8e8, roughness: 0.94, side: THREE.FrontSide });
  const sideMaterial = new THREE.MeshStandardMaterial({ color: 0xe2e5df, roughness: 0.94, bumpMap: plaster, bumpScale: 0.001, side: THREE.FrontSide });
  const floorMaterial = new THREE.MeshStandardMaterial({ color: 0xd3cec2, roughness: 0.88, bumpMap: floorRelief, bumpScale: 0.0015, side: THREE.FrontSide });
  const trimMaterial = new THREE.MeshStandardMaterial({ color: 0xf0ece2, roughness: 0.65 });

  function plane(name: string, material: THREE.Material, rotationY = 0) {
    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), material);
    mesh.name = name;
    mesh.rotation.y = rotationY;
    mesh.receiveShadow = true;
    group.add(mesh);
    return mesh;
  }
  function trim(name: string) {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1), trimMaterial);
    mesh.name = name;
    mesh.receiveShadow = true;
    group.add(mesh);
    return mesh;
  }

  const mainWall = plane("Main wall — inward normal −Z", wallMaterial, Math.PI);
  const sideWall = plane("Poster wall — inward normal +X", sideMaterial, Math.PI / 2);
  const floor = plane("Pale studio floor", floorMaterial);
  floor.rotation.x = -Math.PI / 2;
  const mainTrim = trim("Main-wall baseboard");
  const sideTrim = trim("Side-wall baseboard");
  const frame = plane("Physics-poster frame", new THREE.MeshStandardMaterial({ color: 0x9b9383, roughness: 0.72, side: THREE.FrontSide }), Math.PI / 2);
  frame.scale.set(POSTER_WIDTH + 0.033, POSTER_HEIGHT + 0.033, 1);
  const poster = plane("Sound → motion → light physics poster", new THREE.MeshBasicMaterial({ map: posterTexture, side: THREE.FrontSide, toneMapped: false }), Math.PI / 2);
  poster.scale.set(POSTER_WIDTH, POSTER_HEIGHT, 1);
  poster.receiveShadow = false;
  const posterTarget = new THREE.Vector3();
  const bounds = new THREE.Box3();

  function update(nextDistance: number) {
    const centerX = neutralWallX(nextDistance);
    const depth = nextDistance - FRONT;
    // The physics is unchanged. These bounds contain its scaled active wall.
    const halfActiveWidth = TOY.wallWidth * opticalScale / 2;
    const left = Math.min(LEFT, centerX - halfActiveWidth - 0.1);
    const right = Math.max(RIGHT, centerX + halfActiveWidth + 0.1);
    mainWall.position.set((left + right) / 2, FLOOR + HEIGHT / 2, nextDistance);
    mainWall.scale.set(right - left, HEIGHT, 1);
    sideWall.position.set(left, FLOOR + HEIGHT / 2, (FRONT + nextDistance) / 2);
    sideWall.scale.set(depth, HEIGHT, 1);
    floor.position.set((left + right) / 2, FLOOR, (FRONT + nextDistance) / 2);
    floor.scale.set(right - left, depth, 1);
    mainTrim.position.set((left + right) / 2, FLOOR + 0.04, nextDistance - 0.009);
    mainTrim.scale.set(right - left, 0.08, 0.018);
    sideTrim.position.set(left + 0.009, FLOOR + 0.04, (FRONT + nextDistance) / 2);
    sideTrim.scale.set(0.018, 0.08, depth);
    const posterZ = Math.min(0.3, nextDistance - POSTER_WIDTH / 2 - 0.12);
    frame.position.set(left + 0.003, 0.1, posterZ);
    poster.position.set(left + 0.005, 0.1, posterZ);
    posterTarget.set(left + 0.005, 0.1, posterZ);
    bounds.min.set(left, FLOOR, FRONT);
    bounds.max.set(right, FLOOR + HEIGHT, nextDistance);
  }
  update(displayDistance);
  return { group, update, textures, posterTarget, bounds, ready };
}
