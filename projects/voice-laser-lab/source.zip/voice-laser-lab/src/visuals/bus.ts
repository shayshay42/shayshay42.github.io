import { DEFAULT_CONFIG, type SimulationConfig, type SimulationFrame, type TraceBlock } from "../physics/engine";

export const DEFAULT_PERSISTENCE = 0.85;

/** Audio and render threads exchange data here, without React state updates. */
export class VisualBus {
  sampleRate = 48_000;
  config: SimulationConfig = { ...DEFAULT_CONFIG };
  frame: SimulationFrame | null = null;
  latestSample = 0;
  running = false;
  /** RMS of the mono input, used only by the explanatory sound cue. */
  inputLevel = 0;
  persistence = DEFAULT_PERSISTENCE;

  // Four seconds at 96 kHz, or two at 192 kHz. Memory never grows with playback.
  readonly capacity = 384_000;
  readonly positions = new Float32Array(this.capacity * 6);
  readonly times = new Float32Array(this.capacity * 2);
  readonly valid = new Float32Array(this.capacity * 2);
  written = 0;
  revision = 0;
  private listeners = new Set<() => void>();
  private previous: { x: number; y: number; time: number; hit: boolean; sample: number } | null = null;

  subscribe(listener: () => void) {
    this.listeners.add(listener);
    return () => { this.listeners.delete(listener); };
  }

  notify() { this.listeners.forEach((listener) => listener()); }

  push(block: TraceBlock) {
    if (!block.count) return;
    if (this.previous && block.startSample < this.previous.sample) this.clear();
    const rate = this.sampleRate;
    for (let i = 0; i < block.count; i++) {
      const sample = block.startSample + i + 1;
      const time = sample / rate;
      const x = block.xy[i * 2];
      const y = block.xy[i * 2 + 1];
      const hit = Boolean(block.hits[i]) && Number.isFinite(x) && Number.isFinite(y);
      const previous = this.previous;
      const slot = this.written % this.capacity;
      const p = slot * 6;
      const t = slot * 2;
      const connected = hit && previous?.hit && sample === previous.sample + 1;
      this.positions[p] = connected ? previous.x : hit ? x : 0;
      this.positions[p + 1] = connected ? previous.y : hit ? y : 0;
      this.positions[p + 2] = 0;
      this.positions[p + 3] = hit ? x : 0;
      this.positions[p + 4] = hit ? y : 0;
      this.positions[p + 5] = 0;
      this.times[t] = connected ? previous.time : time;
      this.times[t + 1] = time;
      this.valid[t] = this.valid[t + 1] = connected ? 1 : 0;
      if (!this.previous) this.previous = { x, y, time, hit, sample };
      else {
        this.previous.x = x;
        this.previous.y = y;
        this.previous.time = time;
        this.previous.hit = hit;
        this.previous.sample = sample;
      }
      this.written++;
    }
    this.latestSample = block.startSample + block.count;
    this.frame = block.lastFrame;
    this.notify();
  }

  clear() {
    this.written = 0;
    this.previous = null;
    this.revision++;
    this.notify();
  }
}
