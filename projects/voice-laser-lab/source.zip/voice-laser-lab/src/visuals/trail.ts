import * as THREE from "three";
import type { VisualBus } from "./bus";

/** The same sample-by-sample path is used by the wall and apparatus views. */
export function createTrail(bus: VisualBus) {
  // One quad per original segment gives a true CSS-pixel stroke on high-DPI
  // displays. No interpolation, simplification, or smoothing changes the path.
  const position = new THREE.InstancedInterleavedBuffer(bus.positions, 6).setUsage(THREE.DynamicDrawUsage);
  const time = new THREE.InstancedInterleavedBuffer(bus.times, 2).setUsage(THREE.DynamicDrawUsage);
  const valid = new THREE.InstancedInterleavedBuffer(bus.valid, 2).setUsage(THREE.DynamicDrawUsage);
  const material = new THREE.ShaderMaterial({
    uniforms: {
      now: { value: 0 },
      persistence: { value: bus.persistence },
      resolution: { value: new THREE.Vector2(1, 1) },
      pixelRatio: { value: 1 },
      color: { value: new THREE.Color("#b3473d") },
    },
    vertexShader: `
      attribute vec3 instanceStart;
      attribute vec3 instanceEnd;
      attribute vec2 sampleTimes;
      attribute vec2 sampleValid;
      uniform float now;
      uniform float persistence;
      uniform vec2 resolution;
      uniform float pixelRatio;
      varying float alpha;
      varying float edge;
      void main() {
        float age = max(0.0, now - mix(sampleTimes.x, sampleTimes.y, position.y));
        float remaining = clamp(1.0 - age / max(0.025, persistence), 0.0, 1.0);
        alpha = min(sampleValid.x, sampleValid.y) * pow(remaining, 0.75);
        vec4 start = projectionMatrix * modelViewMatrix * vec4(instanceStart, 1.0);
        vec4 end = projectionMatrix * modelViewMatrix * vec4(instanceEnd, 1.0);
        vec2 delta = (end.xy / end.w - start.xy / start.w) * resolution;
        float segmentLength = length(delta);
        if (alpha <= 0.0 || segmentLength < 0.00001 || start.w <= 0.0 || end.w <= 0.0) {
          alpha = 0.0;
          edge = 0.0;
          gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
          return;
        }
        vec2 perpendicular = vec2(-delta.y, delta.x) / segmentLength;
        // An extra physical pixel carries antialias coverage outside the stroke.
        edge = position.x * (1.1 + 1.0 / pixelRatio);
        gl_Position = mix(start, end, position.y);
        gl_Position.xy += perpendicular * edge * 2.0 / resolution * gl_Position.w;
      }
    `,
    fragmentShader: `
      uniform vec3 color;
      varying float alpha;
      varying float edge;
      void main() {
        float aa = max(fwidth(edge) * 0.5, 0.0001);
        float coverage = 1.0 - smoothstep(1.1 - aa, 1.1 + aa, abs(edge));
        if (alpha * coverage < 0.003) discard;
        gl_FragColor = vec4(color, alpha * coverage * 0.86);
        #include <colorspace_fragment>
      }
    `,
    transparent: true,
    depthWrite: false,
    blending: THREE.NormalBlending,
    toneMapped: false,
  });
  const line = new THREE.Group();
  const viewport = new THREE.Vector2();
  function makeSpan() {
    const geometry = new THREE.InstancedBufferGeometry();
    geometry.setAttribute("position", new THREE.Float32BufferAttribute([
      -1, 0, 0, 1, 0, 0, -1, 1, 0, 1, 1, 0,
    ], 3));
    geometry.setIndex([0, 2, 1, 2, 3, 1]);
    geometry.instanceCount = 0;
    const mesh = new THREE.Mesh(geometry, material);
    mesh.frustumCulled = false;
    mesh.renderOrder = 2;
    mesh.onBeforeRender = (renderer) => {
      renderer.getSize(viewport);
      material.uniforms.resolution.value.copy(viewport);
      material.uniforms.pixelRatio.value = renderer.getPixelRatio();
    };
    line.add(mesh);
    return { geometry, first: -1 };
  }
  const spans = [makeSpan(), makeSpan()];
  function drawSpan(span: typeof spans[number], first: number, count: number) {
    // New attribute views update the GL offsets; their backing ring buffers stay
    // shared and bounded. Two spans handle wraparound without copying the path.
    if (first !== span.first) {
      span.geometry.setAttribute("instanceStart", new THREE.InterleavedBufferAttribute(position, 3, first * 6));
      span.geometry.setAttribute("instanceEnd", new THREE.InterleavedBufferAttribute(position, 3, first * 6 + 3));
      span.geometry.setAttribute("sampleTimes", new THREE.InterleavedBufferAttribute(time, 2, first * 2));
      span.geometry.setAttribute("sampleValid", new THREE.InterleavedBufferAttribute(valid, 2, first * 2));
      span.first = first;
    }
    span.geometry.instanceCount = count;
  }
  let uploaded = 0;
  let revision = bus.revision;

  function update() {
    material.uniforms.now.value = bus.latestSample / bus.sampleRate;
    material.uniforms.persistence.value = bus.persistence;
    if (revision !== bus.revision) {
      uploaded = 0;
      revision = bus.revision;
    }
    const count = bus.written - uploaded;
    if (count > 0) {
      const start = uploaded % bus.capacity;
      const ranges = count >= bus.capacity
        ? [[0, bus.capacity]]
        : start + count <= bus.capacity
          ? [[start, count]]
          : [[start, bus.capacity - start], [0, (start + count) % bus.capacity]];
      for (const [attribute, stride] of [[position, 6], [time, 2], [valid, 2]] as const) {
        attribute.clearUpdateRanges();
        for (const [offset, length] of ranges) attribute.addUpdateRange(offset * stride, length * stride);
        attribute.needsUpdate = true;
      }
      uploaded = bus.written;
    }
    const visible = Math.min(bus.written, bus.capacity, Math.ceil(bus.persistence * bus.sampleRate) + 2);
    const first = (bus.written - visible) % bus.capacity;
    const initial = Math.min(visible, bus.capacity - first);
    drawSpan(spans[0], first, initial);
    drawSpan(spans[1], 0, visible - initial);
  }
  return { line, update, dispose: () => { spans.forEach(span => span.geometry.dispose()); material.dispose(); } };
}

export function createLaserDot() {
  const geometry = new THREE.PlaneGeometry(1, 1);
  const material = new THREE.ShaderMaterial({
    transparent: true,
    depthWrite: false,
    depthTest: false,
    blending: THREE.NormalBlending,
    toneMapped: false,
    uniforms: { color: { value: new THREE.Color("#b3473d") } },
    vertexShader: `varying vec2 pointUv; void main() { pointUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }`,
    fragmentShader: `
      varying vec2 pointUv;
      uniform vec3 color;
      void main() {
        float r=length(pointUv-0.5)*2.0;
        float aa=fwidth(r);
        float coverage=1.0-smoothstep(1.0-aa,1.0,r);
        if(coverage<0.003) discard;
        gl_FragColor=vec4(color,coverage);
        #include <colorspace_fragment>
      }
    `,
  });
  const mesh = new THREE.Mesh(geometry, material);
  mesh.renderOrder = 10;
  return { mesh, dispose: () => { geometry.dispose(); material.dispose(); } };
}
