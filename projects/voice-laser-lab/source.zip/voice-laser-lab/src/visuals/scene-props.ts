import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';

type Point = [number, number, number];
const UP = new THREE.Vector3(0, 1, 0);

function mesh(
  parent: THREE.Object3D, name: string, geometry: THREE.BufferGeometry,
  material: THREE.Material, position: Point,
): THREE.Mesh {
  const object = new THREE.Mesh(geometry, material);
  object.name = name;
  object.position.set(...position);
  object.castShadow = true;
  object.receiveShadow = true;
  parent.add(object);
  return object;
}

function rod(
  parent: THREE.Object3D, name: string, start: Point, end: Point,
  radius: number, material: THREE.Material,
): THREE.Mesh {
  const a = new THREE.Vector3(...start);
  const b = new THREE.Vector3(...end);
  const middle = a.clone().add(b).multiplyScalar(0.5);
  const object = mesh(parent, name,
    new THREE.CylinderGeometry(radius, radius, a.distanceTo(b), 32),
    material, middle.toArray() as Point);
  object.quaternion.setFromUnitVectors(UP, b.sub(a).normalize());
  return object;
}

/** A plain support silhouette; all positions use the enlarged apparatus's display coordinates. */
export function createTripod(): THREE.Group {
  const group = new THREE.Group();
  group.name = 'tripod';
  const material = new THREE.MeshStandardMaterial({ color: 0x53595c, roughness: 0.84 });
  const x = 0.04;
  const z = -0.136;

  // Its upper surface meets the bottom of the enlarged cylinder at y = -.08.
  mesh(group, 'support-plate', new RoundedBoxGeometry(0.16, 0.0256, 0.095, 3, 0.003),
    material, [x, -0.0928, z]);
  rod(group, 'center-stem', [x, -0.55, z], [x, -0.1056, z], 0.013, material);
  for (let leg = 0; leg < 3; leg++) {
    const angle = leg * 2 * Math.PI / 3;
    const footX = x + Math.sin(angle) * 0.47;
    const footZ = z + Math.cos(angle) * 0.47;
    rod(group, `leg-${leg}`, [x, -0.53, z], [footX, -1.785, footZ], 0.009, material);
    const foot = mesh(group, `foot-${leg}`, new THREE.SphereGeometry(1, 24, 16),
      material, [footX, -1.785, footZ]);
    foot.scale.set(0.017, 0.015, 0.023);
    foot.rotation.y = angle;
  }
  return group;
}

