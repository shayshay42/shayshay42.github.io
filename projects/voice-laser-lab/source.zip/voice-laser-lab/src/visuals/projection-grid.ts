import * as THREE from "three";

export interface ProjectionGridBounds {
  minX: number;
  maxX: number;
  minY: number;
  maxY: number;
  /** Resting laser position in this view's scene coordinates. */
  originX: number;
  originY?: number;
  /** Scene units per physical metre; 1 for the trace, 1.6 for the enlarged room. */
  spacingScale?: number;
}

/** Shared metric grid with no background, border, or change to the laser path. */
export function createProjectionGrid(initial: ProjectionGridBounds): {
  group: THREE.Group;
  update(bounds: ProjectionGridBounds): void;
  setMinorVisible(visible: boolean): void;
  dispose(): void;
} {
  const group = new THREE.Group();
  group.name = "Projection metric grid";
  const minorMaterial = new THREE.LineBasicMaterial({
    color: 0xd2d5d3, transparent: true, opacity: 0.48, depthWrite: false, toneMapped: false,
  });
  const majorMaterial = new THREE.LineBasicMaterial({
    color: 0xb9bfbb, transparent: true, opacity: 0.68, depthWrite: false, toneMapped: false,
  });
  const axisMaterial = new THREE.LineBasicMaterial({
    color: 0x9ca69f, transparent: true, opacity: 0.72, depthWrite: false, toneMapped: false,
  });
  const minor = new THREE.LineSegments(new THREE.BufferGeometry(), minorMaterial);
  const major = new THREE.LineSegments(new THREE.BufferGeometry(), majorMaterial);
  const axes = new THREE.LineSegments(new THREE.BufferGeometry(), axisMaterial);
  minor.name = "1 cm grid";
  major.name = "10 cm grid";
  axes.name = "Resting laser axes";
  group.add(minor, major, axes);
  let previous: Required<ProjectionGridBounds> | undefined;

  function replace(line: THREE.LineSegments, vertices: number[]): void {
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute("position", new THREE.Float32BufferAttribute(vertices, 3));
    geometry.computeBoundingSphere();
    line.geometry.dispose();
    line.geometry = geometry;
  }

  function update(bounds: ProjectionGridBounds): void {
    const next = { ...bounds, originY: bounds.originY ?? 0, spacingScale: bounds.spacingScale ?? 1 };
    if (previous && (Object.keys(next) as (keyof typeof next)[]).every((key) => next[key] === previous![key])) return;
    if (Object.values(next).some((value) => !Number.isFinite(value)) ||
        next.minX >= next.maxX || next.minY >= next.maxY || next.spacingScale <= 0) {
      throw new RangeError("Projection grid needs finite ordered bounds and a positive scale.");
    }
    const fine: number[] = [];
    const coarse: number[] = [];
    const reference: number[] = [];
    const spacing = 0.01 * next.spacingScale;

    function lines(minimum: number, maximum: number, origin: number, vertical: boolean): void {
      const first = Math.ceil((minimum - origin) / spacing - 1e-9);
      const last = Math.floor((maximum - origin) / spacing + 1e-9);
      for (let index = first; index <= last; index++) {
        const position = origin + index * spacing;
        const target = index === 0 ? reference : index % 10 === 0 ? coarse : fine;
        if (vertical) target.push(position, next.minY, 0, position, next.maxY, 0);
        else target.push(next.minX, position, 0, next.maxX, position, 0);
      }
    }
    lines(next.minX, next.maxX, next.originX, true);
    lines(next.minY, next.maxY, next.originY, false);
    replace(minor, fine);
    replace(major, coarse);
    replace(axes, reference);
    previous = next;
  }

  update(initial);
  return {
    group,
    update,
    setMinorVisible(visible: boolean) { minor.visible = visible; },
    dispose() {
      minor.geometry.dispose(); major.geometry.dispose(); axes.geometry.dispose();
      minorMaterial.dispose(); majorMaterial.dispose(); axisMaterial.dispose();
    },
  };
}
