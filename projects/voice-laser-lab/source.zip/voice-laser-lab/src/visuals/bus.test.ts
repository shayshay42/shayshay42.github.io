import test from "node:test";
import assert from "node:assert/strict";
import { Simulator, type TraceBlock } from "../physics/engine";
import { VisualBus } from "./bus";

const frame = new Simulator().getFrame();
function block(startSample: number, xy: number[], hits: number[]): TraceBlock {
  return { startSample, count: hits.length, xy: new Float32Array(xy), hits: new Uint8Array(hits), lastFrame: frame };
}

test("trajectory joins consecutive blocks and timestamps the consumed samples", () => {
  const bus = new VisualBus();
  bus.sampleRate = 100;
  bus.push(block(0, [1, 2, 3, 4], [1, 1]));
  bus.push(block(2, [5, 6], [1]));
  assert.equal(bus.latestSample, 3);
  assert.equal(bus.written, 3);
  assert.deepEqual(Array.from(bus.positions.slice(12, 18)), [3, 4, 0, 5, 6, 0]);
  assert.deepEqual(Array.from(bus.valid.slice(0, 6)), [0, 0, 1, 1, 1, 1]);
  assert.ok(Math.abs(bus.times[5] - 0.03) < 1e-7);
});

test("a missed laser hit, missing block, or clear breaks the visible path", () => {
  const bus = new VisualBus();
  bus.push(block(0, [1, 2, NaN, NaN, 3, 4, 5, 6], [1, 0, 1, 1]));
  assert.deepEqual(Array.from(bus.valid.slice(0, 8)), [0, 0, 0, 0, 0, 0, 1, 1]);
  bus.push(block(8, [7, 8], [1]));
  assert.equal(bus.valid[8], 0);
  bus.clear();
  bus.push(block(9, [9, 10], [1]));
  assert.equal(bus.written, 1);
  assert.equal(bus.valid[0], 0);
});

test("trajectory memory remains fixed and the ring preserves the newest segment", () => {
  const bus = new VisualBus();
  const count = bus.capacity + 3;
  const xy = new Float32Array(count * 2);
  for (let i = 0; i < count; i++) xy[i * 2] = i;
  bus.push({ startSample: 0, count, xy, hits: new Uint8Array(count).fill(1), lastFrame: frame });
  assert.equal(bus.positions.length, bus.capacity * 6);
  assert.equal(bus.written, count);
  assert.deepEqual(Array.from(bus.positions.slice(12, 18)), [count - 2, 0, 0, count - 1, 0, 0]);
});
