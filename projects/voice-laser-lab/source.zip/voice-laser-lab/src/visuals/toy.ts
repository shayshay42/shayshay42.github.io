import * as THREE from "three";
import { RoundedBoxGeometry } from "three/addons/geometries/RoundedBoxGeometry.js";
import { TOY, membraneDisplacement, type SimulationFrame } from "../physics/engine";

/** Visual mounting dimensions. The optical source remains fixed by TOY. */
export const WOOD = {
  position: [0.054, -0.02, 0.09] as [number, number, number],
  width: 0.015, height: 0.007, length: 0.60, cornerRadius: 0.0017,
};

function buildMembrane() {
  const rings = 24;
  const sectors = 80;
  const positions = [0, 0, 0];
  const indices: number[] = [];
  for (let ring = 1; ring <= rings; ring++) {
    const radius = TOY.cylinderRadius * ring / rings;
    for (let sector = 0; sector < sectors; sector++) {
      const angle = sector / sectors * Math.PI * 2;
      positions.push(radius * Math.cos(angle), radius * Math.sin(angle), 0);
    }
  }
  for (let s = 0; s < sectors; s++) indices.push(0, 1 + s, 1 + (s + 1) % sectors);
  for (let ring = 1; ring < rings; ring++) {
    const inner = 1 + (ring - 1) * sectors;
    const outer = 1 + ring * sectors;
    for (let s = 0; s < sectors; s++) {
      const next = (s + 1) % sectors;
      indices.push(inner + s, outer + s, outer + next, inner + s, outer + next, inner + next);
    }
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3).setUsage(THREE.DynamicDrawUsage));
  geometry.setIndex(indices);
  geometry.computeVertexNormals();
  const count = positions.length / 3;
  const weights = new Float32Array(count * 6);
  for (let mode = 0; mode < 6; mode++) {
    const unit = Array(6).fill(0);
    unit[mode] = 1;
    for (let vertex = 0; vertex < count; vertex++) {
      weights[vertex * 6 + mode] = membraneDisplacement(positions[vertex * 3], positions[vertex * 3 + 1], unit);
    }
  }
  return {
    geometry,
    update(modes: number[]) {
      const attribute = geometry.getAttribute("position") as THREE.BufferAttribute;
      const array = attribute.array as Float32Array;
      for (let vertex = 0; vertex < count; vertex++) {
        let displacement = 0;
        for (let mode = 0; mode < 6; mode++) displacement += weights[vertex * 6 + mode] * modes[mode];
        array[vertex * 3 + 2] = displacement;
      }
      attribute.needsUpdate = true;
      geometry.computeVertexNormals();
    },
  };
}

/** Small deterministic material textures, kept local to the rendered toy. */
function surfaceTexture(kind: "paper" | "latex" | "wood") {
  const canvas = document.createElement("canvas");
  canvas.width = 512;
  canvas.height = kind === "wood" ? 1024 : 512;
  const context = canvas.getContext("2d")!;
  const image = context.createImageData(canvas.width, canvas.height);
  let seed = 91423;
  const random = () => { seed = (1664525 * seed + 1013904223) >>> 0; return seed / 4294967296; };
  for (let y = 0; y < canvas.height; y++) {
    for (let x = 0; x < canvas.width; x++) {
      const index = (y * canvas.width + x) * 4;
      const noise = random() - 0.5;
      if (kind === "wood") {
        const grainX = x + 10 * Math.sin(y * 0.006) + 3.5 * Math.sin(y * 0.016 + x * 0.007);
        // Broad growth bands survive the narrow stick's screen footprint.
        const bands = Math.sin(grainX * 0.035) * 17 + Math.sin(grainX * 0.11) * 5;
        const latewood = Math.pow(Math.max(0, Math.sin(grainX * 0.07 + Math.sin(y * 0.002))), 12) * 29;
        const fibers = Math.sin(grainX * 0.82) * 2.4;
        const grain = bands - latewood + fibers + noise * 5;
        image.data[index] = 192 + grain;
        image.data[index + 1] = 140 + grain * 0.86;
        image.data[index + 2] = 82 + grain * 0.63;
      } else {
        const fiber = kind === "paper" ? Math.sin(x * 1.3 + y * 0.013) * 1.1 : 0;
        const value = 249 + noise * (kind === "paper" ? 8 : 4) + fiber;
        image.data[index] = image.data[index + 1] = image.data[index + 2] = value;
      }
      image.data[index + 3] = 255;
    }
  }
  context.putImageData(image, 0, 0);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
  if (kind === "paper") texture.repeat.set(3, 1);
  if (kind === "latex") texture.repeat.set(2, 2);
  return texture;
}


function circleCrossSection(radius: number): THREE.Vector2[] {
  return Array.from({ length: 128 }, (_, i) => {
    const a = i / 128 * Math.PI * 2;
    return new THREE.Vector2(Math.cos(a) * radius, Math.sin(a) * radius);
  });
}

function woodCrossSection(): THREE.Vector2[] {
  const points: THREE.Vector2[] = [];
  const radius = WOOD.cornerRadius;
  const halfWidth = WOOD.width / 2;
  const halfHeight = WOOD.height / 2;
  for (let corner = 0; corner < 4; corner++) {
    const a0 = corner * Math.PI / 2;
    const cx = WOOD.position[0] + (corner === 0 || corner === 3 ? 1 : -1) * (halfWidth - radius);
    const cy = WOOD.position[1] + (corner < 2 ? 1 : -1) * (halfHeight - radius);
    for (let i = 0; i <= 8; i++) {
      const a = a0 + i / 8 * Math.PI / 2;
      points.push(new THREE.Vector2(cx + Math.cos(a) * radius, cy + Math.sin(a) * radius));
    }
  }
  return points;
}

/** CCW boundary of the union's convex hull: a tight band around BOTH objects. */
function convexHull(points: THREE.Vector2[]): THREE.Vector2[] {
  const sorted = points.slice().sort((a, b) => a.x - b.x || a.y - b.y);
  const cross = (a: THREE.Vector2, b: THREE.Vector2, c: THREE.Vector2) =>
    (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
  const half = (entries: THREE.Vector2[]) => {
    const result: THREE.Vector2[] = [];
    for (const point of entries) {
      while (result.length > 1 && cross(result[result.length - 2], result[result.length - 1], point) <= 1e-12) result.pop();
      result.push(point);
    }
    result.pop();
    return result;
  };
  return [...half(sorted), ...half(sorted.slice().reverse())];
}

/**
 * A closed bent ribbon, with a rounded rectangular cross-section.
 * The center path follows the offset hull; no disjoint rings or spacer blocks.
 */
function strapGeometry(hull: THREE.Vector2[], width: number, thickness: number, clearance: number): THREE.BufferGeometry {
  const path: Array<{ point: THREE.Vector2; normal: THREE.Vector2 }> = [];
  const offset = clearance + thickness / 2;
  for (let i = 0; i < hull.length; i++) {
    const previous = hull[(i + hull.length - 1) % hull.length];
    const point = hull[i];
    const next = hull[(i + 1) % hull.length];
    const before = point.clone().sub(previous).normalize();
    const after = next.clone().sub(point).normalize();
    const a0 = Math.atan2(-before.x, before.y);
    let a1 = Math.atan2(-after.x, after.y);
    while (a1 < a0) a1 += Math.PI * 2;
    const steps = Math.max(1, Math.ceil((a1 - a0) / (Math.PI / 24)));
    for (let step = 0; step <= steps; step++) {
      const a = a0 + (a1 - a0) * step / steps;
      const normal = new THREE.Vector2(Math.cos(a), Math.sin(a));
      path.push({ point: point.clone().addScaledVector(normal, offset), normal });
    }
  }
  const section: THREE.Vector2[] = [];
  const radius = Math.min(thickness * 0.38, width * 0.2);
  for (let corner = 0; corner < 4; corner++) {
    const a0 = corner * Math.PI / 2;
    const x = (corner === 0 || corner === 3 ? 1 : -1) * (thickness / 2 - radius);
    const y = (corner < 2 ? 1 : -1) * (width / 2 - radius);
    for (let step = 0; step <= 5; step++) {
      const a = a0 + step / 5 * Math.PI / 2;
      section.push(new THREE.Vector2(x + Math.cos(a) * radius, y + Math.sin(a) * radius));
    }
  }
  const positions = new Float32Array(path.length * section.length * 3);
  const indices: number[] = [];
  for (let i = 0; i < path.length; i++) {
    for (let j = 0; j < section.length; j++) {
      const { point, normal } = path[i];
      const sample = section[j];
      const index = (i * section.length + j) * 3;
      positions[index] = point.x + normal.x * sample.x;
      positions[index + 1] = point.y + normal.y * sample.x;
      positions[index + 2] = sample.y;
      const a = i * section.length + j;
      const b = ((i + 1) % path.length) * section.length + j;
      const c = ((i + 1) % path.length) * section.length + (j + 1) % section.length;
      const d = i * section.length + (j + 1) % section.length;
      indices.push(a, b, c, a, c, d);
    }
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
  geometry.setIndex(indices);
  geometry.computeVertexNormals();
  geometry.computeBoundingBox();
  return geometry;
}

export function createToy(): { group: THREE.Group; update(frame: SimulationFrame): void; textures: THREE.Texture[] } {
  const group = new THREE.Group();
  group.name = "toy";
    const paperMap = surfaceTexture("paper");
    const latexMap = surfaceTexture("latex");
    const woodMap = surfaceTexture("wood");
    const textures = [paperMap, latexMap, woodMap];
    textures.forEach((texture) => { texture.anisotropy = 8; });
    const paper = new THREE.MeshStandardMaterial({ color: 0xe5ddcb, map: paperMap, roughness: 0.83, bumpMap: paperMap, bumpScale: 0.00009 });
    const paperInside = new THREE.MeshStandardMaterial({ color: 0xc7b99d, map: paperMap, roughness: 0.9, side: THREE.BackSide, bumpMap: paperMap, bumpScale: 0.00007 });
    const cutPaper = new THREE.MeshStandardMaterial({ color: 0xcebea1, roughness: 0.95, side: THREE.DoubleSide });
    const latex = new THREE.MeshPhysicalMaterial({
      color: 0xce7896, map: latexMap, bumpMap: latexMap, bumpScale: 0.00004,
      roughness: 0.42, metalness: 0, clearcoat: 0.22, clearcoatRoughness: 0.48,
      sheen: 0.2, sheenColor: new THREE.Color(0xe6b0c6), sheenRoughness: 0.72, side: THREE.DoubleSide,
    });
    const wood = new THREE.MeshStandardMaterial({ map: woodMap, roughness: 0.63, bumpMap: woodMap, bumpScale: 0.00008 });
    const anodized = new THREE.MeshStandardMaterial({ color: 0x30373b, metalness: 0.83, roughness: 0.29 });
    const rubber = new THREE.MeshStandardMaterial({ color: 0x202426, roughness: 0.68, metalness: 0.03 });
    const steel = new THREE.MeshStandardMaterial({ color: 0xd5dee0, metalness: 1, roughness: 0.22 });
    const mirrorMaterial = new THREE.MeshStandardMaterial({ color: 0xf6fafb, metalness: 1, roughness: 0.045, envMapIntensity: 1.2 });
    const redGlass = new THREE.MeshPhysicalMaterial({ color: 0x7e211b, roughness: 0.12, metalness: 0.15, emissive: 0xac2419, emissiveIntensity: 0.45, clearcoat: 1 });
    const positiveZ = new THREE.Vector3(0, 0, 1);
    const positiveY = new THREE.Vector3(0, 1, 0);
    const mesh = (geometry: THREE.BufferGeometry, material: THREE.Material, position: THREE.Vector3, parent: THREE.Object3D = group) => {
      const object = new THREE.Mesh(geometry, material);
      object.position.copy(position);
      object.castShadow = true;
      object.receiveShadow = true;
      parent.add(object);
      return object;
    };
    function cylinder(start: THREE.Vector3, end: THREE.Vector3, radius: number, material: THREE.Material, open = false) {
      const axis = end.clone().sub(start).normalize();
      const body = mesh(new THREE.CylinderGeometry(radius, radius, start.distanceTo(end), 96, 1, open), material, start.clone().add(end).multiplyScalar(0.5));
      body.quaternion.setFromUnitVectors(positiveY, axis);
      return body;
    }
    function ring(radius: number, thickness: number, position: THREE.Vector3, material: THREE.Material, axis = positiveZ) {
      const object = mesh(new THREE.TorusGeometry(radius, thickness, 12, 96), material, position);
      object.quaternion.setFromUnitVectors(positiveZ, axis);
      return object;
    }

    // Paper tube with an open back and a visible cut edge.
    cylinder(new THREE.Vector3(0, 0, -TOY.cylinderLength), new THREE.Vector3(0, 0, 0), TOY.cylinderRadius, paper, true).name = "paper-cylinder";
    cylinder(new THREE.Vector3(0, 0, -TOY.cylinderLength), new THREE.Vector3(0, 0, 0), 0.047, paperInside, true);
    mesh(new THREE.RingGeometry(0.047, 0.05, 96), cutPaper, new THREE.Vector3(0, 0, -TOY.cylinderLength));
    ring(0.049, 0.001, new THREE.Vector3(0, 0, -TOY.cylinderLength), cutPaper);

    const membrane = buildMembrane();
    const membraneSurface = mesh(membrane.geometry, latex, new THREE.Vector3());
    membraneSurface.name = "pink-balloon-membrane";
    // Radial UVs preserve a continuous latex surface, with no triangle outlines.
    const positions = membrane.geometry.getAttribute("position");
    const membraneUV = new Float32Array(positions.count * 2);
    for (let i = 0; i < positions.count; i++) {
      membraneUV[i * 2] = positions.getX(i) / (TOY.cylinderRadius * 2) + 0.5;
      membraneUV[i * 2 + 1] = positions.getY(i) / (TOY.cylinderRadius * 2) + 0.5;
    }
    membrane.geometry.setAttribute("uv", new THREE.BufferAttribute(membraneUV, 2));
    membraneSurface.frustumCulled = false;
    const skirt = cylinder(new THREE.Vector3(0, 0, -0.012), new THREE.Vector3(0, 0, -0.001), 0.05055, latex, true);
    skirt.name = "balloon-skirt";
    ring(0.0501, 0.0013, new THREE.Vector3(0, 0, -0.0011), latex).name = "balloon-rolled-lip";
    const lipBand = mesh(strapGeometry(circleCrossSection(0.05075), 0.0038, 0.00115, 0.00012), rubber, new THREE.Vector3(0, 0, -0.0045));
    lipBand.name = "balloon-lip-retainer";

    const mirror = new THREE.Group();
    mirror.name = "membrane-mirror";
    group.add(mirror);
    const mirrorFace = mesh(new THREE.CircleGeometry(TOY.mirrorRadius, 96), mirrorMaterial, new THREE.Vector3(), mirror);
    mirrorFace.castShadow = false;
    const bevel = mesh(new THREE.TorusGeometry(TOY.mirrorRadius - 0.00018, 0.00022, 10, 96), steel, new THREE.Vector3(0, 0, -0.0001), mirror);
    bevel.castShadow = false;

    // A rounded wood splint, with grain mapped lengthwise on every long face.
    const stickGeometry = new RoundedBoxGeometry(WOOD.width, WOOD.height, WOOD.length, 4, WOOD.cornerRadius);
    const stickPositions = stickGeometry.getAttribute("position");
    const stickNormals = stickGeometry.getAttribute("normal");
    const stickUV = stickGeometry.getAttribute("uv");
    for (let i = 0; i < stickPositions.count; i++) {
      const endFace = Math.abs(stickNormals.getZ(i)) > 0.8;
      const horizontalFace = Math.abs(stickNormals.getY(i)) >= Math.abs(stickNormals.getX(i));
      const u = horizontalFace ? stickPositions.getX(i) / 0.015 + 0.5 : stickPositions.getY(i) / 0.007 + 0.5;
      const v = endFace ? stickPositions.getY(i) / 0.007 + 0.5 : stickPositions.getZ(i) / 0.60 + 0.5;
      stickUV.setXY(i, u, v);
    }
    mesh(stickGeometry, wood, new THREE.Vector3(...WOOD.position)).name = "wooden-stick";
    const wrappedSection = convexHull([...circleCrossSection(TOY.cylinderRadius), ...woodCrossSection()]);
    for (const [name, z] of [["mounting-strap-rear", -0.155], ["mounting-strap-front", -0.027]] as const) {
      const strap = mesh(strapGeometry(wrappedSection, 0.0056, 0.0012, 0.00016), rubber, new THREE.Vector3(0, 0, z));
      strap.name = name;
      strap.userData.encloses = ["paper-cylinder", "wooden-stick"];
    }

    const laserPosition = new THREE.Vector3(...TOY.laserPosition);
    const laserAxis = laserPosition.clone().normalize();
    const half = 0.065 / 2;
    const profile = [
      new THREE.Vector2(0, -half), new THREE.Vector2(0.0082, -half),
      new THREE.Vector2(0.0088, -half + 0.00025), new THREE.Vector2(0.009, -half + 0.0008),
      new THREE.Vector2(0.009, half - 0.0008), new THREE.Vector2(0.0088, half - 0.00025),
      new THREE.Vector2(0.0082, half), new THREE.Vector2(0, half),
    ];
    const laser = mesh(new THREE.LatheGeometry(profile, 96), anodized, laserPosition.clone().addScaledVector(laserAxis, half));
    laser.quaternion.setFromUnitVectors(positiveY, laserAxis);
    const cap = mesh(new THREE.RingGeometry(0.002, 0.00825, 64), steel, laserPosition.clone().addScaledVector(laserAxis, -0.00003));
    cap.quaternion.setFromUnitVectors(positiveZ, laserAxis.clone().negate());
    const aperture = mesh(new THREE.CircleGeometry(0.0019, 32), redGlass, laserPosition.clone());
    aperture.name = "laser-aperture";
    aperture.quaternion.copy(cap.quaternion);
    for (const length of [0.007, 0.053]) ring(0.00905, 0.00022, laserPosition.clone().addScaledVector(laserAxis, length), anodized, laserAxis);
    mesh(new RoundedBoxGeometry(0.035, 0.013, 0.024, 4, 0.003), rubber, new THREE.Vector3(0.068, -0.014, 0.343)).name = "laser-cradle";


  const normal = new THREE.Vector3();
  return {
    group,
    textures,
    update(frame) {
      membrane.update(frame.modes);
      mirror.position.set(...frame.mirrorCenter).addScaledVector(normal.set(...frame.mirrorNormal), 0.00012);
      mirror.quaternion.setFromUnitVectors(positiveZ, normal);
    },
  };
}
