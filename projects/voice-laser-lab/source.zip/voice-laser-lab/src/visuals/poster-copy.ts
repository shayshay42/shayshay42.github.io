/** Prose is separate from TeX so language checks do not parse equations. */
export const POSTER_COPY = {
  title: "Sound → motion → light",
  summary: "For fixed settings, twelve states store six displacements and six velocities.",
  system: ["A: modal dynamics", "B: input coupling", "H: mirror and ray geometry", "dot: time derivative"],
  audio: {
    title: "1. Audio drives six membrane modes.",
    note: "Each mode is a vibration pattern. The input is not calibrated pressure.",
    variables: [
      "u: mono audio", "G: input gain", "t: time", "q_i: mode displacement",
      "ζ_i: damping ratio", "ω_i: natural angular frequency", "α_i: force overlap",
    ],
  },
  mirror: {
    title: "2. The membrane sets the mirror pose.",
    note: "A plane fit over the mirror's circular footprint gives fixed weights.",
    variables: [
      "w: membrane height", "φ_i: shape of mode i", "c: mirror centre",
      "g_x, g_y: mirror slopes", "n: unit mirror normal", "h, k_x, k_y: fit weights",
    ],
  },
  ray: {
    title: "3. The ray meets the wall.",
    variables: [
      "a: fixed laser position", "d: incoming direction", "r: reflected direction",
      "τ: ray distance", "m: point on mirror", "L: wall plane coordinate", "X, Y: wall coordinates",
    ],
    miss: "A ray that misses the mirror or wall gives no point.",
  },
  notes: [
    "Each audio sample advances the state. We ignore light travel time.",
    "Asymmetry changes the mode coupling and resonance frequencies.",
    "From rest, zero asymmetry gives no centred-mirror tilt.",
    "One input drives both outputs. Some target paths may be unreachable.",
  ],
} as const;

function strings(value: unknown): string[] {
  if (typeof value === "string") return [value];
  if (Array.isArray(value)) return value.flatMap(strings);
  if (value && typeof value === "object") return Object.values(value).flatMap(strings);
  return [];
}
export const POSTER_PROSE = strings(POSTER_COPY).map(value => value.includes(":") ? `- ${value}` : value).join("\n");
