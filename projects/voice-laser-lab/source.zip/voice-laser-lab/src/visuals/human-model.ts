import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { mergeVertices } from 'three/addons/utils/BufferGeometryUtils.js';
import { assetPath } from '../asset-path';

const ASSET_URL = assetPath('models/human/speaker.glb');
let sourceBytes: Promise<ArrayBuffer> | null = null;
const FLOOR = -1.8;
const MOUTH_TARGET = new THREE.Vector3(0, 0, -0.46);

function setWorldQuaternion(bone: THREE.Bone, world: THREE.Quaternion) {
  const parent = bone.parent!.getWorldQuaternion(new THREE.Quaternion());
  bone.quaternion.copy(parent.invert().multiply(world));
  bone.updateWorldMatrix(false, true);
}
function rotateWorld(bone: THREE.Bone, axis: THREE.Vector3, angle: number) {
  const world = bone.getWorldQuaternion(new THREE.Quaternion());
  world.premultiply(new THREE.Quaternion().setFromAxisAngle(axis, angle));
  setWorldQuaternion(bone, world);
}
function aimBone(bone: THREE.Bone, child: THREE.Bone, target: THREE.Vector3) {
  const start = bone.getWorldPosition(new THREE.Vector3());
  const from = child.getWorldPosition(new THREE.Vector3()).sub(start).normalize();
  const to = target.clone().sub(start).normalize();
  const world = bone.getWorldQuaternion(new THREE.Quaternion());
  world.premultiply(new THREE.Quaternion().setFromUnitVectors(from, to));
  setWorldQuaternion(bone, world);
}

/** Two-link IK retains the source arm lengths and places each elbow outward. */
function poseCallingArm(source: THREE.Group, side: 'l' | 'r', wristTarget: THREE.Vector3) {
  const sign = side === 'l' ? 1 : -1;
  const bone = (name: string) => source.getObjectByName(name + '_' + side) as THREE.Bone;
  const upper = bone('upperarm'), lower = bone('lowerarm'), hand = bone('hand');
  const shoulder = upper.getWorldPosition(new THREE.Vector3());
  const elbow = lower.getWorldPosition(new THREE.Vector3());
  const wrist = hand.getWorldPosition(new THREE.Vector3());
  const upperLength = shoulder.distanceTo(elbow), lowerLength = elbow.distanceTo(wrist);
  const direction = wristTarget.clone().sub(shoulder);
  const distance = THREE.MathUtils.clamp(direction.length(), Math.abs(upperLength - lowerLength) + 0.001, upperLength + lowerLength - 0.001);
  direction.normalize();
  const pole = new THREE.Vector3(sign, -0.85, 0.1);
  pole.addScaledVector(direction, -pole.dot(direction)).normalize();
  const along = (upperLength ** 2 - lowerLength ** 2 + distance ** 2) / (2 * distance);
  const height = Math.sqrt(Math.max(0, upperLength ** 2 - along ** 2));
  const elbowTarget = shoulder.clone().addScaledVector(direction, along).addScaledVector(pole, height);
  aimBone(upper, lower, elbowTarget);
  aimBone(lower, hand, wristTarget);

  // Match the actual hand's finger/width basis to a vertical, inward-facing cup.
  const middle = bone('middle_01'), index = bone('index_01'), pinky = bone('pinky_01');
  const localLong = middle.position.clone().normalize();
  const localWidth = pinky.position.clone().sub(index.position).multiplyScalar(sign);
  localWidth.addScaledVector(localLong, -localWidth.dot(localLong)).normalize();
  const localNormal = new THREE.Vector3().crossVectors(localWidth, localLong).normalize();
  const long = new THREE.Vector3(-sign * 0.12, 0.70, 0.70).normalize();
  const normal = new THREE.Vector3(-sign, 0, 0.12);
  normal.addScaledVector(long, -normal.dot(long)).normalize();
  const width = new THREE.Vector3().crossVectors(long, normal).normalize();
  const localBasis = new THREE.Matrix4().makeBasis(localWidth, localLong, localNormal);
  const worldBasis = new THREE.Matrix4().makeBasis(width, long, normal);
  const orientation = new THREE.Quaternion().setFromRotationMatrix(worldBasis.multiply(localBasis.invert()));
  setWorldQuaternion(hand, orientation);
  for (const finger of ['index', 'middle', 'ring', 'pinky']) {
    bone(finger + '_01').rotateX(THREE.MathUtils.degToRad(5));
    bone(finger + '_02').rotateX(THREE.MathUtils.degToRad(16));
    bone(finger + '_03').rotateX(THREE.MathUtils.degToRad(12));
  }
  bone('thumb_02').rotateX(THREE.MathUtils.degToRad(8));
  source.updateMatrixWorld(true);
}

/** A downloaded MakeHuman/MPFB mesh, posed through its original 53-bone rig. */
export async function loadHumanModel(): Promise<THREE.Group> {
  sourceBytes ??= fetch(ASSET_URL).then(response => {
    if (!response.ok) throw new Error(`Human model could not load (${response.status}).`);
    return response.arrayBuffer();
  }).catch(error => { sourceBytes = null; throw error; });
  const gltf = await new GLTFLoader().parseAsync((await sourceBytes).slice(0), assetPath('models/human/'));
  const source = gltf.scene;
  const skins: THREE.SkinnedMesh[] = [];
  source.traverse(object => { if ((object as THREE.SkinnedMesh).isSkinnedMesh) skins.push(object as THREE.SkinnedMesh); });
  skins.forEach(mesh => mesh.skeleton.pose());
  source.updateMatrixWorld(true);
  const bone = (name: string) => source.getObjectByName(name) as THREE.Bone;
  const head = bone('head');
  if (!head || !bone('spine_01')) throw new Error('The local human asset is missing its expected rig.');
  // The lip seam is a measured source-mesh landmark, below the nose, not its forehead.
  const mouthLocal = head.worldToLocal(new THREE.Vector3(0, 1.506, 0.157));
  const floorBefore = new THREE.Box3().setFromObject(source).min.y;
  rotateWorld(bone('spine_01'), new THREE.Vector3(1, 0, 0), THREE.MathUtils.degToRad(6));
  rotateWorld(head, new THREE.Vector3(1, 0, 0), THREE.MathUtils.degToRad(-2));
  const mouth = head.localToWorld(mouthLocal.clone());
  const scale = -FLOOR / (mouth.y - floorBefore);
  source.scale.multiplyScalar(scale);
  source.position.set(-mouth.x * scale, FLOOR - floorBefore * scale, MOUTH_TARGET.z - mouth.z * scale);
  source.updateMatrixWorld(true);

  const handTargets = {
    left: new THREE.Vector3(0.13, -0.13, -0.555),
    right: new THREE.Vector3(-0.13, -0.13, -0.555),
  };
  poseCallingArm(source, 'l', handTargets.left);
  poseCallingArm(source, 'r', handTargets.right);
  source.updateMatrixWorld(true);
  skins.forEach(mesh => mesh.skeleton.update());
  const mouthPosition = head.localToWorld(mouthLocal.clone());

  const group = new THREE.Group();
  group.name = 'speaker-mannequin';
  group.userData.asset = 'MakeHuman/MPFB anatomical base, prepared by Innerscene';
  group.userData.attribution = 'Innerscene / MakeHuman / MPFB — CC0 1.0';
  group.userData.source = 'https://www.innerscene.com/tools/library/3d-parts/human-base-mesh-with-editable-53-bone-rig-8e7c8ab1';
  group.userData.mouthPosition = mouthPosition.toArray();
  group.userData.headFront = mouthPosition.toArray();
  group.userData.handTargets = { left: handTargets.left.toArray(), right: handTargets.right.toArray() };
  const material = new THREE.MeshStandardMaterial({ color: 0x989c9d, roughness: 0.97, metalness: 0 });
  const vertex = new THREE.Vector3();
  const loadedMaterials = new Set<THREE.Material>();
  source.traverse(object => {
    const mesh = object as THREE.Mesh;
    if (!mesh.isMesh) return;
    let geometry = mesh.geometry.clone();
    const positions = geometry.getAttribute('position') as THREE.BufferAttribute;
    for (let i = 0; i < positions.count; i++) {
      mesh.getVertexPosition(i, vertex);
      vertex.applyMatrix4(mesh.matrixWorld);
      positions.setXYZ(i, vertex.x, vertex.y, vertex.z);
    }
    geometry.deleteAttribute('skinIndex'); geometry.deleteAttribute('skinWeight');
    geometry.deleteAttribute('uv'); geometry.deleteAttribute('normal');
    const unwelded = geometry;
    geometry = mergeVertices(unwelded, 1e-6);
    unwelded.dispose();
    geometry.computeVertexNormals(); geometry.computeBoundingBox(); geometry.computeBoundingSphere();
    const posed = new THREE.Mesh(geometry, material);
    posed.name = 'sourced-human-calling-pose';
    posed.castShadow = true; posed.receiveShadow = true;
    group.add(posed);
    (Array.isArray(mesh.material) ? mesh.material : [mesh.material]).forEach(value => loadedMaterials.add(value));
    mesh.geometry.dispose();
  });
  loadedMaterials.forEach(value => value.dispose());
  skins.forEach(mesh => mesh.skeleton.dispose());
  if (!group.children.length) { material.dispose(); throw new Error('The local human asset contains no mesh.'); }
  group.updateMatrixWorld(true);
  group.userData.height = new THREE.Box3().setFromObject(group).getSize(new THREE.Vector3()).y;
  return group;
}
