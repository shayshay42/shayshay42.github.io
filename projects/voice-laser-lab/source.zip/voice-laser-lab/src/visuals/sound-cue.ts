import * as THREE from "three";

export interface SoundCueUpdate {
  /** Audio simulation time, not wall-clock or render time. */
  timeSeconds: number;
  /** Measured RMS of the input samples. */
  level: number;
  running: boolean;
  mouth?: [number, number, number];
}

/**
 * An explanatory, slowed sound envelope in the enlarged apparatus's scene units.
 * It does not represent acoustic wave speed or drive any simulation state.
 */
export function createSoundCue(): {
  group: THREE.Group;
  update(state: SoundCueUpdate): void;
  dispose(): void;
} {
  const group = new THREE.Group();
  group.name = "Sound entering the cylinder";
  group.visible = false;

  const opening = new THREE.Vector3(0, 0, -0.32);
  const end = new THREE.Vector3(0, 0, -0.018);
  const defaultMouth = new THREE.Vector3(0, 0, -0.44);
  const mouth = defaultMouth.clone();
  const direction = new THREE.Vector3();
  const center = new THREE.Vector3();
  const arrowTip = new THREE.Vector3();
  const arrowStart = new THREE.Vector3();
  const arrowBase = new THREE.Vector3();
  const forward = new THREE.Vector3(0, 0, 1);
  const up = new THREE.Vector3(0, 1, 0);

  const ringGeometry = new THREE.TorusGeometry(1, 0.033, 8, 64);
  const rings: THREE.Mesh<THREE.TorusGeometry, THREE.MeshBasicMaterial>[] = [];
  for (let i = 0; i < 6; i++) {
    const material = new THREE.MeshBasicMaterial({
      color: 0x247d91,
      transparent: true,
      opacity: 0,
      depthWrite: false,
      depthTest: true,
      toneMapped: false,
    });
    const ring = new THREE.Mesh(ringGeometry, material);
    ring.name = `Sound wavefront ${i + 1}`;
    rings.push(ring);
    group.add(ring);
  }

  const arrowMaterial = new THREE.MeshBasicMaterial({
    color: 0x247d91,
    transparent: true,
    opacity: 0,
    depthWrite: false,
    depthTest: true,
    toneMapped: false,
  });
  const shaftGeometry = new THREE.CylinderGeometry(1, 1, 1, 12);
  const headGeometry = new THREE.ConeGeometry(1, 1, 20);
  const shaft = new THREE.Mesh(shaftGeometry, arrowMaterial);
  const head = new THREE.Mesh(headGeometry, arrowMaterial);
  shaft.name = "Sound direction shaft";
  head.name = "Sound direction arrowhead";
  group.add(shaft, head);

  let disposed = false;
  function update({ timeSeconds, level, running, mouth: mouthPosition }: SoundCueUpdate): void {
    if (disposed) return;
    const active = running && Number.isFinite(timeSeconds) && Number.isFinite(level) && level > 0.0008;
    group.visible = active;
    if (!active) return;

    if (mouthPosition?.every(Number.isFinite)) mouth.set(...mouthPosition);
    else mouth.copy(defaultMouth);
    const strength = Math.min(1, Math.sqrt(Math.max(0, level) / 0.18));
    const outsideLength = mouth.distanceTo(opening);
    const insideLength = opening.distanceTo(end);
    const totalLength = outsideLength + insideLength;
    direction.copy(opening).sub(mouth).normalize();
    // The supplied source should remain behind the open end, with sound travelling +Z.
    if (outsideLength < 0.015 || direction.z <= 0) {
      group.visible = false;
      return;
    }

    const speed = 0.13; // Deliberately slow enough to read as a direction cue.
    for (let i = 0; i < rings.length; i++) {
      const travelled = ((timeSeconds * speed + i * totalLength / rings.length) % totalLength + totalLength) % totalLength;
      const progress = travelled / totalLength;
      const outsideProgress = Math.min(1, travelled / outsideLength);
      if (travelled < outsideLength) {
        center.copy(mouth).addScaledVector(direction, travelled);
        rings[i].quaternion.setFromUnitVectors(forward, direction);
      } else {
        center.copy(opening).lerp(end, (travelled - outsideLength) / insideLength);
        rings[i].quaternion.identity();
      }
      const spread = outsideProgress * (2 - outsideProgress);
      const radius = (0.017 + 0.041 * spread) * (0.87 + 0.13 * strength);
      const emerge = Math.min(1, travelled / 0.018);
      const disappear = Math.min(1, (1 - progress) / 0.12);
      rings[i].position.copy(center);
      rings[i].scale.set(radius, radius, 0.047);
      rings[i].material.opacity = (0.2 + 0.5 * strength) * emerge * disappear;
    }

    // One short arrow stays between the mouth and opening; its tip always faces into the tube.
    arrowStart.copy(mouth).addScaledVector(direction, outsideLength * 0.2);
    arrowTip.copy(mouth).addScaledVector(direction, outsideLength * 0.86);
    const headLength = Math.min(0.014, outsideLength * 0.2);
    arrowBase.copy(arrowTip).addScaledVector(direction, -headLength);
    shaft.position.copy(arrowStart).add(arrowBase).multiplyScalar(0.5);
    shaft.quaternion.setFromUnitVectors(up, direction);
    shaft.scale.set(0.0014, arrowStart.distanceTo(arrowBase), 0.0014);
    head.position.copy(arrowTip).addScaledVector(direction, -headLength / 2);
    head.quaternion.copy(shaft.quaternion);
    head.scale.set(0.005, headLength, 0.005);
    arrowMaterial.opacity = 0.32 + 0.34 * strength;
  }

  return {
    group,
    update,
    dispose() {
      if (disposed) return;
      disposed = true;
      group.visible = false;
      ringGeometry.dispose();
      shaftGeometry.dispose();
      headGeometry.dispose();
      rings.forEach((ring) => ring.material.dispose());
      arrowMaterial.dispose();
    },
  };
}
