import assert from 'node:assert/strict';
import test from 'node:test';
import {
  DEFAULT_CONFIG, Simulator, TOY, membraneDisplacement, neutralWallX,
  reflect, traceLaser, type SimulationState,
} from './engine';

const RATE = 48000;
function tone(frequency: number, duration = 0.3, amplitude = 0.25): Float32Array {
  return Float32Array.from({ length: Math.round(RATE * duration) }, (_, i) =>
    amplitude * Math.sin(2 * Math.PI * frequency * i / RATE));
}
function near(actual: number, expected: number, tolerance = 1e-10): void {
  assert.ok(Math.abs(actual - expected) <= tolerance, `${actual} differs from ${expected}`);
}

test('silence holds the neutral mirror and beam, with sample-time indexing', () => {
  const sim = new Simulator();
  const block = sim.process(new Float32Array(512));
  assert.equal(block.startSample, 0);
  assert.equal(block.count, 512);
  assert.equal(block.lastFrame.sampleIndex, 512);
  assert.equal(block.lastFrame.hit, true);
  near(block.lastFrame.x, neutralWallX(DEFAULT_CONFIG.wallDistance));
  near(block.lastFrame.y, 0);
  assert.deepEqual(block.lastFrame.mirrorCenter, [0, 0, 0]);
  assert.deepEqual(block.lastFrame.mirrorNormal, [-0, -0, 1]);
  assert.deepEqual(block.lastFrame.modes, [0, 0, 0, 0, 0, 0]);
  assert.ok(block.hits.every(hit => hit === 1));
  const empty = sim.process(new Float32Array());
  assert.equal(empty.startSample, 512);
  assert.equal(empty.lastFrame.sampleIndex, 512);
});

test('an ideal uniformly driven membrane translates without tilting its centred mirror', () => {
  const sim = new Simulator({ ...DEFAULT_CONFIG, asymmetry: 0 });
  const block = sim.process(tone(125, 0.2));
  const state = sim.getState();
  assert.ok(Math.abs(state.q[0]) > 1e-5);
  assert.deepEqual(state.q.slice(2), [0, 0, 0, 0]);
  assert.deepEqual(state.v.slice(2), [0, 0, 0, 0]);
  assert.deepEqual(block.lastFrame.mirrorNormal, [-0, -0, 1]);
  for (let i = 0; i < block.count; i++) {
    if (block.hits[i]) near(block.xy[2 * i + 1], 0);
  }
});

test('modal resonance is stronger than off-resonant response and follows sqrt(tension)', () => {
  const firstDipole = 125 * 3.8317059702075125 / 2.404825557695773 * (1 - 0.55 * DEFAULT_CONFIG.asymmetry);
  function modalRms(frequency: number, tension = 1): number {
    const sim = new Simulator({ ...DEFAULT_CONFIG, tension });
    const input = tone(frequency, 0.4);
    sim.process(input.subarray(0, 12000));
    let sum = 0;
    let count = 0;
    for (let i = 12000; i < input.length; i += 32) {
      sim.process(input.subarray(i, i + 32));
      sum += sim.getState().q[2] ** 2;
      count++;
    }
    return Math.sqrt(sum / count);
  }
  const resonant = modalRms(firstDipole);
  assert.ok(resonant > modalRms(110) * 7);
  assert.ok(modalRms(firstDipole * 2, 4) > modalRms(firstDipole, 4) * 7);
});

test('positive damping dissipates a free membrane vibration', () => {
  const initial: SimulationState = { sampleIndex: 0, q: [0, 0, 0.0001, -0.0001, 0, 0], v: [0, 0, 0, 0, 0, 0] };
  // Keep a fixed decay reference so UI presets do not change this time-bound assertion.
  const sim = new Simulator({ ...DEFAULT_CONFIG, tension: 1, damping: 0.03, asymmetry: 0.12 }, RATE, initial);
  sim.process(new Float32Array(RATE / 2));
  const state = sim.getState();
  assert.ok(Math.max(...state.q.map(Math.abs)) < 1e-10);
  assert.ok(Math.max(...state.v.map(Math.abs)) < 1e-7);
});

test('undamped, critical, and overdamped recurrences remain finite', () => {
  for (const damping of [0, 1 / 2.8, 1]) {
    const sim = new Simulator({ ...DEFAULT_CONFIG, damping });
    const impulse = new Float32Array(4096);
    impulse[0] = 0.5;
    sim.process(impulse);
    const state = sim.getState();
    assert.ok([...state.q, ...state.v].every(Number.isFinite));
    assert.ok(Math.max(...state.q.map(Math.abs)) < 0.001);
  }
});

test('Bessel membrane basis has the fixed rim and dipole symmetry', () => {
  const xMode = [0, 0, 1, 0, 0, 0];
  near(membraneDisplacement(TOY.cylinderRadius, 0, xMode), 0);
  near(membraneDisplacement(0, TOY.cylinderRadius, xMode), 0);
  near(membraneDisplacement(0, 0, xMode), 0);
  near(membraneDisplacement(0, 0.02, xMode), 0);
  near(membraneDisplacement(0.02, 0.01, xMode), -membraneDisplacement(-0.02, 0.01, xMode));
  // Independent midpoint quadrature checks the area-RMS normalization.
  for (const index of [0, 1, 2, 4]) {
    const modes = [0, 0, 0, 0, 0, 0];
    modes[index] = 1;
    let meanSquare = 0;
    const radialSteps = 180;
    const angularSteps = 40;
    for (let ri = 0; ri < radialSteps; ri++) {
      const rho = (ri + 0.5) / radialSteps;
      for (let ai = 0; ai < angularSteps; ai++) {
        const angle = (ai + 0.5) * 2 * Math.PI / angularSteps;
        const shape = membraneDisplacement(rho * TOY.cylinderRadius * Math.cos(angle),
          rho * TOY.cylinderRadius * Math.sin(angle), modes);
        meanSquare += shape * shape * 2 * rho / (radialSteps * angularSteps);
      }
    }
    near(meanSquare, 1, 0.0002);
  }
});

test('reflection doubles mirror angle and respects the finite mirror and wall', () => {
  const angle = 0.001;
  const reflected = reflect([0, 0, -1], [Math.sin(angle), 0, Math.cos(angle)]);
  near(Math.atan2(reflected[0], reflected[2]), 2 * angle, 1e-12);
  near(Math.hypot(...reflected), 1);
  const neutral = traceLaser([0, 0, 0], [0, 0, 1], 2);
  assert.equal(neutral.hit, true);
  near(neutral.x, neutralWallX(2));
  near(traceLaser([0, 0, 0], [0, 0, 1], 4).x, 2 * neutral.x);
  const mirrorMiss = traceLaser([0.02, 0, 0], [0, 0, 1], 2);
  assert.equal(mirrorMiss.hit, false);
  assert.equal(mirrorMiss.mirrorHit, null);
  assert.ok(Number.isNaN(mirrorMiss.x));
  const wallMiss = traceLaser([0, 0, 0], [Math.sin(0.4), 0, Math.cos(0.4)], 2);
  assert.equal(wallMiss.hit, false);
  assert.notEqual(wallMiss.mirrorHit, null);
  assert.ok(Number.isNaN(wallMiss.x));
  const backwards = traceLaser([0, 0, 0], [Math.sin(1.2), 0, Math.cos(1.2)], 2);
  assert.equal(backwards.hit, false);
});

test('audio block size cannot change the trace or final mechanical state', () => {
  const input = Float32Array.from({ length: 12017 }, (_, i) =>
    0.2 * Math.sin(i * 0.027) + 0.15 * Math.sin(i * 0.0441));
  const whole = new Simulator();
  const expected = whole.process(input);
  for (const size of [1, 128, 1024, 4096]) {
    const sim = new Simulator();
    const xy = new Float32Array(input.length * 2);
    const hits = new Uint8Array(input.length);
    for (let start = 0; start < input.length; start += size) {
      const block = sim.process(input.subarray(start, start + size));
      assert.equal(block.startSample, start);
      xy.set(block.xy, start * 2);
      hits.set(block.hits, start);
    }
    assert.deepEqual(xy, expected.xy);
    assert.deepEqual(hits, expected.hits);
    assert.deepEqual(sim.getState(), whole.getState());
  }
});

test('state snapshots resume exactly and do not share mutable arrays', () => {
  const input = tone(220, 0.15);
  const first = new Simulator();
  first.process(input.subarray(0, 1024));
  const saved = first.getState();
  const restored = new Simulator(DEFAULT_CONFIG, RATE, saved);
  const expected = first.process(input.subarray(1024));
  const actual = restored.process(input.subarray(1024));
  assert.deepEqual(actual, expected);
  saved.q[0] = 1;
  assert.notEqual(restored.getState().q[0], 1);
  restored.reset();
  assert.equal(restored.getState().sampleIndex, 0);
});

test('config validation rejects invalid sessions and failed patches preserve the state', () => {
  const sim = new Simulator();
  assert.throws(() => sim.setConfig({ tension: 0 }), RangeError);
  assert.deepEqual(sim.getConfig(), DEFAULT_CONFIG);
  assert.throws(() => new Simulator({ ...DEFAULT_CONFIG, gain: NaN }), RangeError);
  assert.throws(() => new Simulator(DEFAULT_CONFIG, 0), RangeError);
  assert.throws(() => sim.reset({ sampleIndex: -1, q: [], v: [] }), RangeError);
  sim.process(new Float32Array([NaN, Infinity, -Infinity]));
  assert.ok(sim.getState().q.every(q => q === 0));
});
