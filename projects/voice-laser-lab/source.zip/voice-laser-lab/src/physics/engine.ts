/**
 * A deterministic, small-deflection membrane model, in metres and seconds.
 *
 * Six area-RMS-normalized circular Bessel modes respond to the same pressure
 * signal. A weak pressure gradient and a split between orthogonal resonances
 * represent imperfect balloon tension / mounting. Zero asymmetry removes tilt
 * forcing. A uniformly driven membrane that starts at rest then has no centre tilt.
 *
 * PCM amplitude is converted to illustrative pressure acceleration. This is an
 * uncalibrated toy model, not a measured latex / glue / acoustic-cavity model.
 */

export type Vec3 = [number, number, number];

export interface SimulationConfig {
  gain: number;
  /** Membrane tension relative to the reference value; frequencies scale as sqrt(T). */
  tension: number;
  /** Modal damping ratio; the radiating radial modes receive more damping. */
  damping: number;
  asymmetry: number;
  wallDistance: number;
}

export const DEFAULT_CONFIG: SimulationConfig = {
  gain: 1.7,
  tension: 0.85,
  damping: 0.015,
  asymmetry: 0.23,
  wallDistance: 2.5,
};

export const MODEL_VERSION = 'membrane-six-mode-v1';
export const TOY = {
  cylinderRadius: 0.05,
  cylinderLength: 0.2,
  mirrorRadius: 0.008,
  laserPosition: [0.075, 0, 0.32] as Vec3,
  wallWidth: 2,
  wallHeight: 2,
};

/** sampleIndex counts consumed samples; q and v have six entries, in m and m/s. */
export interface SimulationState {
  sampleIndex: number;
  q: number[];
  v: number[];
}

export interface SimulationFrame {
  sampleIndex: number;
  /** Wall coordinates in world metres. NaN when hit is false. */
  x: number;
  y: number;
  hit: boolean;
  mirrorCenter: Vec3;
  mirrorNormal: Vec3;
  /** Incoming beam intersection, or null when the finite mirror is missed. */
  mirrorHit: Vec3 | null;
  modes: number[];
}

export interface TraceBlock {
  /** Input index of the block's first sample, before consuming that sample. */
  startSample: number;
  count: number;
  /** Pair i is the state at (startSample + i + 1) / sampleRate; misses are NaN. */
  xy: Float32Array;
  hits: Uint8Array;
  lastFrame: SimulationFrame;
}

const MODE_COUNT = 6;
const FUNDAMENTAL_HZ = 125;
// Full-scale PCM is arbitrary; keep this fixed and exported sessions reproducible.
const PRESSURE_ACCELERATION = 1800;
const ROOT_01 = 2.404825557695773;
const ROOT_02 = 5.520078110286311;
const ROOT_11 = 3.8317059702075125;
const ROOT_12 = 7.015586669815619;
const ROOTS = [ROOT_01, ROOT_02, ROOT_11, ROOT_11, ROOT_12, ROOT_12];
const AXES = [0, 0, 1, 2, 1, 2];
const DAMPING_WEIGHTS = [2.8, 2, 1, 1, 1.15, 1.15];
const SPLITS = [0, 0, -0.55, 0.55, -0.3, 0.3];

// Power series are accurate over this model's range, |x| <= ROOT_12.
function besselJ0(x: number): number {
  const factor = -x * x / 4;
  let term = 1;
  let sum = 1;
  for (let k = 1; k < 40; k++) {
    term *= factor / (k * k);
    sum += term;
    if (Math.abs(term) < 1e-16) break;
  }
  return sum;
}

function besselJ1(x: number): number {
  const factor = -x * x / 4;
  let term = x / 2;
  let sum = term;
  for (let k = 1; k < 40; k++) {
    term *= factor / (k * (k + 1));
    sum += term;
    if (Math.abs(term) < 1e-16) break;
  }
  return sum;
}

function besselJ2(x: number): number {
  if (Math.abs(x) < 1e-4) return x * x / 8 - x ** 4 / 96;
  return 2 * besselJ1(x) / x - besselJ0(x);
}

const NORMALIZERS = ROOTS.map((root, i) => AXES[i] === 0
  ? Math.abs(besselJ1(root))
  : Math.abs(besselJ2(root)) / Math.SQRT2);

// The rigid mirror follows a least-squares plane fitted over its circular area.
const MIRROR_HEIGHT = ROOTS.map((root, i) => {
  const x = root * TOY.mirrorRadius / TOY.cylinderRadius;
  return AXES[i] === 0 ? 2 * besselJ1(x) / (x * NORMALIZERS[i]) : 0;
});
const MIRROR_SLOPE = ROOTS.map((root, i) => {
  const k = root / TOY.cylinderRadius;
  return AXES[i] === 0 ? 0
    : 4 * besselJ2(k * TOY.mirrorRadius)
      / (k * TOY.mirrorRadius ** 2 * NORMALIZERS[i]);
});

/** Surface displacement in metres, with physical x/y positions in metres. */
export function membraneDisplacement(x: number, y: number, modes: ArrayLike<number>): number {
  const radius = Math.hypot(x, y);
  if (radius >= TOY.cylinderRadius) return 0;
  let z = 0;
  for (let i = 0; i < MODE_COUNT; i++) {
    const radial = ROOTS[i] * radius / TOY.cylinderRadius;
    const shape = AXES[i] === 0 ? besselJ0(radial)
      : radius === 0 ? 0
        : besselJ1(radial) * (AXES[i] === 1 ? x : y) / radius;
    z += (modes[i] ?? 0) * shape / NORMALIZERS[i];
  }
  return z;
}

export function neutralWallX(distance: number): number {
  return -TOY.laserPosition[0] / TOY.laserPosition[2] * distance;
}

export function reflect(direction: Vec3, normal: Vec3): Vec3 {
  const length = Math.hypot(...normal);
  if (!Number.isFinite(length) || length === 0) throw new RangeError('Mirror normal must be finite and nonzero.');
  const nx = normal[0] / length;
  const ny = normal[1] / length;
  const nz = normal[2] / length;
  const dot = direction[0] * nx + direction[1] * ny + direction[2] * nz;
  return [direction[0] - 2 * dot * nx, direction[1] - 2 * dot * ny, direction[2] - 2 * dot * nz];
}

interface RayResult {
  hit: boolean;
  x: number;
  y: number;
  mirrorHit: boolean;
  hx: number;
  hy: number;
  hz: number;
}

const LASER_LENGTH = Math.hypot(...TOY.laserPosition);
const DX = -TOY.laserPosition[0] / LASER_LENGTH;
const DY = -TOY.laserPosition[1] / LASER_LENGTH;
const DZ = -TOY.laserPosition[2] / LASER_LENGTH;

/** Allocation-free intersection used at audio rate. The normal must be unit length. */
function castLaser(
  cx: number, cy: number, cz: number,
  nx: number, ny: number, nz: number,
  distance: number, result: RayResult,
): void {
  result.hit = false;
  result.mirrorHit = false;
  result.x = Number.NaN;
  result.y = Number.NaN;
  const dot = DX * nx + DY * ny + DZ * nz;
  if (Math.abs(dot) < 1e-12) return;
  const t = ((cx - TOY.laserPosition[0]) * nx
    + (cy - TOY.laserPosition[1]) * ny
    + (cz - TOY.laserPosition[2]) * nz) / dot;
  if (t <= 0 || !Number.isFinite(t)) return;
  const hx = TOY.laserPosition[0] + DX * t;
  const hy = TOY.laserPosition[1] + DY * t;
  const hz = TOY.laserPosition[2] + DZ * t;
  if ((hx - cx) ** 2 + (hy - cy) ** 2 + (hz - cz) ** 2 > TOY.mirrorRadius ** 2) return;
  result.mirrorHit = true;
  result.hx = hx;
  result.hy = hy;
  result.hz = hz;
  const rx = DX - 2 * dot * nx;
  const ry = DY - 2 * dot * ny;
  const rz = DZ - 2 * dot * nz;
  if (rz <= 1e-12) return;
  const wallT = (distance - hz) / rz;
  if (wallT <= 0 || !Number.isFinite(wallT)) return;
  const x = hx + wallT * rx;
  const y = hy + wallT * ry;
  if (Math.abs(x - neutralWallX(distance)) > TOY.wallWidth / 2
    || Math.abs(y) > TOY.wallHeight / 2) return;
  result.hit = true;
  result.x = x;
  result.y = y;
}

/** Exact finite-mirror and finite-wall ray trace, also useful for geometry tests. */
export function traceLaser(mirrorCenter: Vec3, mirrorNormal: Vec3, wallDistance: number): {
  hit: boolean; x: number; y: number; mirrorHit: Vec3 | null;
} {
  const n = Math.hypot(...mirrorNormal);
  if (!Number.isFinite(n) || n === 0) throw new RangeError('Mirror normal must be finite and nonzero.');
  const result: RayResult = { hit: false, x: NaN, y: NaN, mirrorHit: false, hx: 0, hy: 0, hz: 0 };
  castLaser(...mirrorCenter, mirrorNormal[0] / n, mirrorNormal[1] / n, mirrorNormal[2] / n, wallDistance, result);
  return { hit: result.hit, x: result.x, y: result.y,
    mirrorHit: result.mirrorHit ? [result.hx, result.hy, result.hz] : null };
}

export function validateConfig(config: SimulationConfig): void {
  for (const name of Object.keys(DEFAULT_CONFIG) as (keyof SimulationConfig)[]) {
    if (!Number.isFinite(config[name])) throw new RangeError(`${name} must be finite.`);
  }
  if (config.gain < 0 || config.gain > 50) throw new RangeError('Gain must be between 0 and 50.');
  if (config.tension < 0.05 || config.tension > 20) throw new RangeError('Tension must be between 0.05 and 20.');
  if (config.damping < 0 || config.damping > 1) throw new RangeError('Damping must be between 0 and 1.');
  if (config.asymmetry < 0 || config.asymmetry > 1) throw new RangeError('Asymmetry must be between 0 and 1.');
  if (config.wallDistance < 0.1 || config.wallDistance > 100) throw new RangeError('Wall distance must be between 0.1 and 100 metres.');
}

export class Simulator {
  readonly sampleRate: number;
  private config: SimulationConfig;
  private sampleIndex = 0;
  private q = new Float64Array(MODE_COUNT);
  private v = new Float64Array(MODE_COUNT);
  // Per-mode affine recurrence [m00,m01,m10,m11,bq,bv].
  private coefficients = new Float64Array(MODE_COUNT * 6);
  private centerZ = 0;
  private nx = 0;
  private ny = 0;
  private nz = 1;
  private ray: RayResult = { hit: false, x: NaN, y: NaN, mirrorHit: false, hx: 0, hy: 0, hz: 0 };

  constructor(config: SimulationConfig = DEFAULT_CONFIG, sampleRate = 48000, initialState?: SimulationState) {
    validateConfig(config);
    if (!Number.isFinite(sampleRate) || sampleRate < 8000 || sampleRate > 384000) {
      throw new RangeError('Sample rate must be between 8000 and 384000 Hz.');
    }
    this.config = { ...config };
    this.sampleRate = sampleRate;
    this.updateCoefficients();
    this.reset(initialState);
  }

  setConfig(patch: Partial<SimulationConfig>): void {
    const config = { ...this.config, ...patch };
    validateConfig(config);
    this.config = config;
    this.updateCoefficients();
    this.updateFrame();
  }

  getConfig(): SimulationConfig {
    return { ...this.config };
  }

  reset(state?: SimulationState): void {
    if (state) {
      if (!Number.isSafeInteger(state.sampleIndex) || state.sampleIndex < 0
        || state.q.length !== MODE_COUNT || state.v.length !== MODE_COUNT
        || !state.q.every(Number.isFinite) || !state.v.every(Number.isFinite)) {
        throw new RangeError('State needs a nonnegative sample index and six finite q/v entries.');
      }
      this.sampleIndex = state.sampleIndex;
      this.q.set(state.q);
      this.v.set(state.v);
    } else {
      this.sampleIndex = 0;
      this.q.fill(0);
      this.v.fill(0);
    }
    this.updateFrame();
  }

  getState(): SimulationState {
    return { sampleIndex: this.sampleIndex, q: Array.from(this.q), v: Array.from(this.v) };
  }

  getFrame(): SimulationFrame {
    return {
      sampleIndex: this.sampleIndex,
      x: this.ray.x,
      y: this.ray.y,
      hit: this.ray.hit,
      mirrorCenter: [0, 0, this.centerZ],
      mirrorNormal: [this.nx, this.ny, this.nz],
      mirrorHit: this.ray.mirrorHit ? [this.ray.hx, this.ray.hy, this.ray.hz] : null,
      modes: Array.from(this.q),
    };
  }

  process(pcm: ArrayLike<number>): TraceBlock {
    const count = pcm.length;
    const startSample = this.sampleIndex;
    const xy = new Float32Array(count * 2);
    const hits = new Uint8Array(count);
    const q = this.q;
    const v = this.v;
    const c = this.coefficients;
    for (let sample = 0; sample < count; sample++) {
      // Bad source samples must not permanently poison the mechanical state.
      const input = Number.isFinite(pcm[sample]) ? pcm[sample] : 0;
      for (let mode = 0; mode < MODE_COUNT; mode++) {
        const i = mode * 6;
        const previousQ = q[mode];
        const previousV = v[mode];
        q[mode] = c[i] * previousQ + c[i + 1] * previousV + c[i + 4] * input;
        v[mode] = c[i + 2] * previousQ + c[i + 3] * previousV + c[i + 5] * input;
      }
      this.sampleIndex++;
      this.updateFrame();
      xy[sample * 2] = this.ray.x;
      xy[sample * 2 + 1] = this.ray.y;
      hits[sample] = this.ray.hit ? 1 : 0;
    }
    return { startSample, count, xy, hits, lastFrame: this.getFrame() };
  }

  private updateCoefficients(): void {
    const h = 1 / this.sampleRate;
    for (let mode = 0; mode < MODE_COUNT; mode++) {
      const root = ROOTS[mode];
      const omega = 2 * Math.PI * FUNDAMENTAL_HZ * root / ROOT_01
        * Math.sqrt(this.config.tension) * (1 + SPLITS[mode] * this.config.asymmetry);
      const omega2 = omega * omega;
      const a = this.config.damping * DAMPING_WEIGHTS[mode] * omega;
      const discriminant = a * a - omega2;
      let ec: number;
      let es: number;
      if (Math.abs(discriminant) < 1e-12 * omega2) {
        ec = Math.exp(-a * h);
        es = h * ec;
      } else if (discriminant < 0) {
        const wd = Math.sqrt(-discriminant);
        const envelope = Math.exp(-a * h);
        ec = envelope * Math.cos(wd * h);
        es = envelope * Math.sin(wd * h) / wd;
      } else {
        const wd = Math.sqrt(discriminant);
        const plus = Math.exp((-a + wd) * h);
        const minus = Math.exp((-a - wd) * h);
        ec = (plus + minus) / 2;
        es = (plus - minus) / (2 * wd);
      }
      // Area projection of p(t) * (1 + asymmetry * (x/R + .83*y/R)).
      const coupling = AXES[mode] === 0
        ? 2 * besselJ1(root) / (root * NORMALIZERS[mode])
        : this.config.asymmetry * (AXES[mode] === 1 ? 1 : 0.83)
          * besselJ2(root) / (root * NORMALIZERS[mode]);
      const equilibrium = coupling * PRESSURE_ACCELERATION * this.config.gain / omega2;
      const i = mode * 6;
      this.coefficients[i] = ec + a * es;
      this.coefficients[i + 1] = es;
      this.coefficients[i + 2] = -omega2 * es;
      this.coefficients[i + 3] = ec - a * es;
      this.coefficients[i + 4] = (1 - this.coefficients[i]) * equilibrium;
      this.coefficients[i + 5] = -this.coefficients[i + 2] * equilibrium;
    }
  }

  private updateFrame(): void {
    this.centerZ = this.q[0] * MIRROR_HEIGHT[0] + this.q[1] * MIRROR_HEIGHT[1];
    const slopeX = this.q[2] * MIRROR_SLOPE[2] + this.q[4] * MIRROR_SLOPE[4];
    const slopeY = this.q[3] * MIRROR_SLOPE[3] + this.q[5] * MIRROR_SLOPE[5];
    const length = Math.hypot(slopeX, slopeY, 1);
    this.nx = -slopeX / length;
    this.ny = -slopeY / length;
    this.nz = 1 / length;
    castLaser(0, 0, this.centerZ, this.nx, this.ny, this.nz, this.config.wallDistance, this.ray);
  }
}

export function simulatePCM(pcm: ArrayLike<number>, config: SimulationConfig = DEFAULT_CONFIG,
  sampleRate = 48000, initialState?: SimulationState): TraceBlock {
  return new Simulator(config, sampleRate, initialState).process(pcm);
}
