import { strFromU8, strToU8, unzipSync, zipSync } from "fflate";
import type { RecordedSession } from "./types";
import { replaySession, TRACE_CSV_HEADER, traceBlockToCsv, validateSession, validateSessionMetadata } from "./replay";
import { decodeFloatWav, encodeFloatWav } from "./wav";

export function encodeSessionZip(session: RecordedSession, options: { includeTrace?: boolean } = {}): Uint8Array {
  validateSession(session);
  const files: Record<string, Uint8Array> = {
    "session.json": strToU8(JSON.stringify(session.metadata, null, 2)),
    "audio.wav": encodeFloatWav(session.pcm, session.metadata.sampleRate),
  };
  if (options.includeTrace !== false) {
    const parts = [TRACE_CSV_HEADER];
    replaySession(session, { onTrace: (block) => parts.push(traceBlockToCsv(block, session.metadata.sampleRate)) });
    files["trace.csv"] = strToU8(parts.join(""));
  }
  return zipSync(files, { level: 1 });
}

export function decodeSessionZip(bytes: Uint8Array): RecordedSession {
  let files: Record<string, Uint8Array>;
  try {
    files = unzipSync(bytes, { filter: (file) => file.name === "session.json" || file.name === "audio.wav" });
  } catch {
    throw new Error("This file is not a valid session ZIP.");
  }
  if (!files["session.json"] || !files["audio.wav"]) {
    throw new Error("Session ZIP must contain session.json and audio.wav.");
  }
  let metadata: unknown;
  try { metadata = JSON.parse(strFromU8(files["session.json"])); }
  catch { throw new Error("Session metadata is not valid JSON."); }
  validateSessionMetadata(metadata);
  const audio = decodeFloatWav(files["audio.wav"]);
  if (audio.sampleRate !== metadata.sampleRate) throw new Error("Session metadata and WAV sample rates differ.");
  const session = { metadata, pcm: audio.pcm };
  validateSession(session);
  return session;
}
