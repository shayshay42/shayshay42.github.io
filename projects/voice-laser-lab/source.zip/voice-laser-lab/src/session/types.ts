import type { SimulationConfig, SimulationState } from "../physics/engine";

export interface ParameterEvent {
  /** Absolute input sample boundary. Apply before consuming this sample. */
  sampleIndex: number;
  patch: Partial<SimulationConfig>;
}

export interface SessionMetadata {
  modelVersion: string;
  sampleRate: number;
  initialConfig: SimulationConfig;
  initialState: SimulationState;
  parameterEvents: ParameterEvent[];
  sampleCount: number;
}

export interface RecordedSession {
  metadata: SessionMetadata;
  /** Mono samples before the simulation's input gain. */
  pcm: Float32Array;
}
