/** Lossless storage for the exact Float32 samples supplied to the model. */
export function encodeFloatWav(pcm: Float32Array, sampleRate: number): Uint8Array {
  validateSampleRate(sampleRate);
  const dataLength = pcm.length * 4;
  if (dataLength > 0xffffffff - 48) throw new Error("Recording is too large for a WAV file.");
  const bytes = new Uint8Array(56 + dataLength);
  const view = new DataView(bytes.buffer);
  writeText(bytes, 0, "RIFF");
  view.setUint32(4, bytes.length - 8, true);
  writeText(bytes, 8, "WAVE");
  writeText(bytes, 12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 3, true); // IEEE floating-point PCM.
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 4, true);
  view.setUint16(32, 4, true);
  view.setUint16(34, 32, true);
  writeText(bytes, 36, "fact");
  view.setUint32(40, 4, true);
  view.setUint32(44, pcm.length, true);
  writeText(bytes, 48, "data");
  view.setUint32(52, dataLength, true);
  for (let i = 0; i < pcm.length; i++) {
    if (!Number.isFinite(pcm[i])) throw new Error(`Audio sample ${i} is not finite.`);
    view.setFloat32(56 + i * 4, pcm[i], true);
  }
  return bytes;
}

export function decodeFloatWav(bytes: Uint8Array): { pcm: Float32Array; sampleRate: number } {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (bytes.length < 12 || readText(bytes, 0, 4) !== "RIFF" || readText(bytes, 8, 4) !== "WAVE") {
    throw new Error("Session audio must be a RIFF WAV file.");
  }
  const riffEnd = view.getUint32(4, true) + 8;
  if (riffEnd > bytes.length || riffEnd < 12) throw new Error("Session WAV is truncated.");
  let sampleRate: number | undefined;
  let dataStart = -1;
  let dataLength = 0;
  for (let offset = 12; offset + 8 <= riffEnd;) {
    const id = readText(bytes, offset, 4);
    const size = view.getUint32(offset + 4, true);
    const start = offset + 8;
    if (start + size > riffEnd) throw new Error("Session WAV contains a truncated chunk.");
    if (id === "fmt ") {
      if (size < 16) throw new Error("Session WAV has an invalid format chunk.");
      if (view.getUint16(start, true) !== 3 || view.getUint16(start + 2, true) !== 1 ||
          view.getUint16(start + 12, true) !== 4 || view.getUint16(start + 14, true) !== 32) {
        throw new Error("Session WAV must contain mono IEEE Float32 audio. Import other audio through the audio-file control.");
      }
      sampleRate = view.getUint32(start + 4, true);
      validateSampleRate(sampleRate);
      if (view.getUint32(start + 8, true) !== sampleRate * 4) throw new Error("Session WAV has an invalid byte rate.");
    } else if (id === "data") {
      if (dataStart !== -1) throw new Error("Session WAV has multiple audio chunks.");
      dataStart = start;
      dataLength = size;
    }
    offset = start + size + (size % 2);
  }
  if (sampleRate === undefined || dataStart === -1 || dataLength % 4 !== 0) {
    throw new Error("Session WAV is missing valid format or audio data.");
  }
  const pcm = new Float32Array(dataLength / 4);
  for (let i = 0; i < pcm.length; i++) {
    const value = view.getFloat32(dataStart + i * 4, true);
    if (!Number.isFinite(value)) throw new Error(`Session audio sample ${i} is not finite.`);
    pcm[i] = value;
  }
  return { pcm, sampleRate };
}

export function validateSampleRate(value: number): void {
  if (!Number.isSafeInteger(value) || value <= 0 || value > 0xffffffff / 4) {
    throw new Error("Audio sample rate must be a positive integer.");
  }
}

function writeText(bytes: Uint8Array, offset: number, value: string): void {
  for (let i = 0; i < value.length; i++) bytes[offset + i] = value.charCodeAt(i);
}

function readText(bytes: Uint8Array, offset: number, length: number): string {
  return String.fromCharCode(...bytes.subarray(offset, offset + length));
}
