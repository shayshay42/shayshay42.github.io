import { DEFAULT_CONFIG, MODEL_VERSION, Simulator, validateConfig as validateModelConfig } from "../physics/engine";
import type { SimulationConfig, SimulationState, TraceBlock } from "../physics/engine";
import type { RecordedSession, SessionMetadata } from "./types";
import { validateSampleRate } from "./wav";

const CONFIG_KEYS = Object.keys(DEFAULT_CONFIG) as (keyof SimulationConfig)[];

export function validateSessionMetadata(value: unknown): asserts value is SessionMetadata {
  if (!isRecord(value)) throw new Error("Session metadata must be an object.");
  if (value.modelVersion !== MODEL_VERSION) {
    throw new Error(`Unsupported model version ${String(value.modelVersion)}. This app uses ${MODEL_VERSION}.`);
  }
  validateSampleRate(value.sampleRate as number);
  if ((value.sampleRate as number) < 8000 || (value.sampleRate as number) > 384000) {
    throw new Error("Session sample rate must be between 8000 and 384000 Hz.");
  }
  if (!Number.isSafeInteger(value.sampleCount) || (value.sampleCount as number) < 0) {
    throw new Error("Session sample count must be a non-negative integer.");
  }
  validateConfig(value.initialConfig, false);
  let config = value.initialConfig as unknown as SimulationConfig;
  validateModelConfig(config);
  if (!isRecord(value.initialState) || !Number.isSafeInteger(value.initialState.sampleIndex) ||
      (value.initialState.sampleIndex as number) < 0) {
    throw new Error("Session starting state has an invalid sample index.");
  }
  for (const field of ["q", "v"]) {
    const items = value.initialState[field];
    if (!Array.isArray(items) || items.length !== 6 || !items.every(Number.isFinite)) {
      throw new Error(`Session starting state must contain six finite ${field} values.`);
    }
  }
  const start = value.initialState.sampleIndex as number;
  const end = start + (value.sampleCount as number);
  if (!Number.isSafeInteger(end)) throw new Error("Session sample range is too large.");
  if (!Array.isArray(value.parameterEvents)) throw new Error("Session parameter events must be an array.");
  let previous = start;
  for (const event of value.parameterEvents) {
    if (!isRecord(event) || !Number.isSafeInteger(event.sampleIndex) ||
        (event.sampleIndex as number) < previous || (event.sampleIndex as number) > end) {
      throw new Error("Session parameter events must be ordered sample boundaries within the recording.");
    }
    validateConfig(event.patch, true);
    config = { ...config, ...event.patch as Partial<SimulationConfig> };
    validateModelConfig(config);
    previous = event.sampleIndex as number;
  }
}

export function validateSession(session: RecordedSession): void {
  validateSessionMetadata(session.metadata);
  if (!(session.pcm instanceof Float32Array) || session.pcm.length !== session.metadata.sampleCount) {
    throw new Error("Session PCM length does not match its sample count.");
  }
  for (let i = 0; i < session.pcm.length; i++) {
    if (!Number.isFinite(session.pcm[i])) throw new Error(`Session audio sample ${i} is not finite.`);
  }
}

/** DOM-free replay; also usable inside an AudioWorklet or a training harness. */
export class SessionReplayer {
  readonly simulator: Simulator;
  readonly session: RecordedSession;
  private offset = 0;
  private eventIndex = 0;
  private currentConfig: SimulationConfig;

  constructor(session: RecordedSession) {
    validateSession(session);
    this.session = session;
    this.currentConfig = { ...session.metadata.initialConfig };
    this.simulator = new Simulator(this.currentConfig, session.metadata.sampleRate, session.metadata.initialState);
    this.applyEvents();
  }

  get position(): number { return this.offset; }
  get done(): boolean { return this.offset === this.session.pcm.length; }
  get config(): SimulationConfig { return { ...this.currentConfig }; }

  processNext(maxFrames = 4096): TraceBlock | null {
    if (!Number.isSafeInteger(maxFrames) || maxFrames < 1) throw new Error("Replay block size must be a positive integer.");
    if (this.done) return null;
    const count = Math.min(maxFrames, this.session.pcm.length - this.offset);
    const startSample = this.session.metadata.initialState.sampleIndex + this.offset;
    const xy = new Float32Array(count * 2);
    const hits = new Uint8Array(count);
    let written = 0;
    while (written < count) {
      this.applyEvents();
      const nextEvent = this.session.metadata.parameterEvents[this.eventIndex];
      const now = this.session.metadata.initialState.sampleIndex + this.offset;
      const segmentLength = Math.min(count - written, nextEvent ? nextEvent.sampleIndex - now : Infinity);
      const block = this.simulator.process(this.session.pcm.subarray(this.offset, this.offset + segmentLength));
      xy.set(block.xy, written * 2);
      hits.set(block.hits, written);
      this.offset += segmentLength;
      written += segmentLength;
      this.applyEvents();
    }
    return { startSample, count, xy, hits, lastFrame: this.simulator.getFrame() };
  }

  private applyEvents(): void {
    const events = this.session.metadata.parameterEvents;
    const absoluteIndex = this.session.metadata.initialState.sampleIndex + this.offset;
    while (this.eventIndex < events.length && events[this.eventIndex].sampleIndex === absoluteIndex) {
      const { patch } = events[this.eventIndex++];
      this.currentConfig = { ...this.currentConfig, ...patch };
      this.simulator.setConfig(patch);
    }
  }
}

export function createSessionReplayer(session: RecordedSession): SessionReplayer {
  return new SessionReplayer(session);
}

export function replaySession(
  session: RecordedSession,
  options: { chunkSize?: number; onTrace?: (block: TraceBlock) => void } = {},
): { finalState: SimulationState; finalConfig: SimulationConfig; sampleCount: number } {
  const replayer = createSessionReplayer(session);
  while (!replayer.done) {
    const block = replayer.processNext(options.chunkSize ?? 4096)!;
    options.onTrace?.(block);
  }
  return {
    finalState: replayer.simulator.getState(),
    finalConfig: replayer.config,
    sampleCount: replayer.position,
  };
}

export const TRACE_CSV_HEADER = "sampleIndex,timeSeconds,x,y,hit\n";

/** Coordinates are wall-plane metres; each row describes the state after that input sample. */
export function traceBlockToCsv(block: TraceBlock, sampleRate: number, includeHeader = false): string {
  validateSampleRate(sampleRate);
  const rows = new Array<string>(block.count);
  for (let i = 0; i < block.count; i++) {
    const sampleIndex = block.startSample + i + 1;
    const x = block.hits[i] ? block.xy[i * 2] : "";
    const y = block.hits[i] ? block.xy[i * 2 + 1] : "";
    rows[i] = `${sampleIndex},${sampleIndex / sampleRate},${x},${y},${block.hits[i]}\n`;
  }
  return (includeHeader ? TRACE_CSV_HEADER : "") + rows.join("");
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function validateConfig(value: unknown, partial: boolean): void {
  if (!isRecord(value)) throw new Error("Session parameters must be an object.");
  if (!partial && CONFIG_KEYS.some((key) => !(key in value))) throw new Error("Session parameters are incomplete.");
  for (const [key, item] of Object.entries(value)) {
    if (!CONFIG_KEYS.includes(key as keyof SimulationConfig) || typeof item !== "number" || !Number.isFinite(item)) {
      throw new Error(`Invalid session parameter: ${key}.`);
    }
  }
}
