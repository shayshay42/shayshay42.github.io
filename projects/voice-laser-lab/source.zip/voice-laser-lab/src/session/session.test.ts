import test from "node:test";
import assert from "node:assert/strict";
import { unzipSync, strFromU8 } from "fflate";
import { DEFAULT_CONFIG, MODEL_VERSION, Simulator } from "../physics/engine";
import type { TraceBlock } from "../physics/engine";
import type { RecordedSession } from "./types";
import {
  createSessionReplayer,
  decodeFloatWav,
  decodeSessionZip,
  encodeFloatWav,
  encodeSessionZip,
  replaySession,
  traceBlockToCsv,
  validateSession,
} from "./index";

function makeSession(count = 5301): RecordedSession {
  const simulator = new Simulator(DEFAULT_CONFIG, 48000);
  const warmup = Float32Array.from({ length: 193 }, (_, i) => Math.sin(i * 0.13) * 0.22);
  simulator.process(warmup);
  const initialState = simulator.getState();
  const pcm = Float32Array.from({ length: count }, (_, i) => Math.sin(i * 0.19) * 0.3 + Math.cos(i * 0.081) * 0.11);
  return {
    metadata: {
      modelVersion: MODEL_VERSION,
      sampleRate: 48000,
      initialConfig: { ...DEFAULT_CONFIG },
      initialState,
      parameterEvents: [
        { sampleIndex: initialState.sampleIndex, patch: { gain: 1.2 } },
        { sampleIndex: initialState.sampleIndex + 37, patch: { tension: 1.15 } },
        { sampleIndex: initialState.sampleIndex + 128, patch: { damping: 0.08 } },
        { sampleIndex: initialState.sampleIndex + 128, patch: { gain: 0.8 } },
        { sampleIndex: initialState.sampleIndex + count, patch: { wallDistance: 2.4 } },
      ],
      sampleCount: pcm.length,
    },
    pcm,
  };
}

function collectedReplay(session: RecordedSession, chunkSize: number) {
  const xy = new Float32Array(session.pcm.length * 2);
  const hits = new Uint8Array(session.pcm.length);
  let offset = 0;
  const result = replaySession(session, {
    chunkSize,
    onTrace(block) {
      xy.set(block.xy, offset * 2);
      hits.set(block.hits, offset);
      offset += block.count;
    },
  });
  return { xy, hits, ...result };
}

test("Float32 WAV preserves every finite bit pattern, including negative zero", () => {
  const pcm = new Float32Array([0, -0, 1, -1, 1 / 3, 1e-38, -1e-38, 3.4028234663852886e38]);
  const decoded = decodeFloatWav(encodeFloatWav(pcm, 48000));
  assert.equal(decoded.sampleRate, 48000);
  assert.deepEqual(new Uint32Array(decoded.pcm.buffer), new Uint32Array(pcm.buffer));
  assert.ok(Object.is(decoded.pcm[1], -0));
});

test("WAV accepts a Uint8Array view with a nonzero byte offset", () => {
  const pcm = new Float32Array([0.2, -0.3]);
  const wav = encodeFloatWav(pcm, 44100);
  const container = new Uint8Array(wav.length + 9);
  container.set(wav, 5);
  assert.deepEqual(decodeFloatWav(container.subarray(5, 5 + wav.length)).pcm, pcm);
});

test("WAV rejects truncated data, integer PCM and nonfinite samples", () => {
  const wav = encodeFloatWav(new Float32Array([0.5]), 48000);
  assert.throws(() => decodeFloatWav(wav.subarray(0, wav.length - 1)), /truncated/);
  const altered = wav.slice();
  new DataView(altered.buffer).setUint16(20, 1, true);
  assert.throws(() => decodeFloatWav(altered), /Float32/);
  assert.throws(() => encodeFloatWav(new Float32Array([NaN]), 48000), /not finite/);
});

test("session replay is invariant to chunk sizes and respects absolute event boundaries", () => {
  const session = makeSession();
  const small = collectedReplay(session, 1);
  assert.deepEqual(collectedReplay(session, 128), small);
  assert.deepEqual(collectedReplay(session, 4096), small);
  assert.equal(small.finalConfig.wallDistance, 2.4);
  assert.equal(small.finalState.sampleIndex, session.metadata.initialState.sampleIndex + session.pcm.length);

  const manual = new Simulator(session.metadata.initialConfig, session.metadata.sampleRate, session.metadata.initialState);
  let nextEvent = 0;
  const xy = new Float32Array(session.pcm.length * 2);
  const hits = new Uint8Array(session.pcm.length);
  for (let i = 0; i <= session.pcm.length; i++) {
    const absolute = session.metadata.initialState.sampleIndex + i;
    while (session.metadata.parameterEvents[nextEvent]?.sampleIndex === absolute) {
      manual.setConfig(session.metadata.parameterEvents[nextEvent++].patch);
    }
    if (i < session.pcm.length) {
      const block = manual.process(session.pcm.subarray(i, i + 1));
      xy.set(block.xy, i * 2);
      hits[i] = block.hits[0];
    }
  }
  assert.deepEqual(xy, small.xy);
  assert.deepEqual(hits, small.hits);
  assert.deepEqual(manual.getState(), small.finalState);
});

test("replayer exposes PCM position and stops at the recording boundary", () => {
  const session = makeSession(301);
  const replayer = createSessionReplayer(session);
  assert.equal(replayer.position, 0);
  assert.equal(replayer.processNext(256)?.count, 256);
  assert.equal(replayer.position, 256);
  assert.equal(replayer.processNext(256)?.count, 45);
  assert.equal(replayer.done, true);
  assert.equal(replayer.processNext(), null);
  assert.throws(() => replayer.processNext(0), /positive integer/);
});

test("session ZIP restores exact PCM, model state, parameters and a complete CSV", () => {
  const session = makeSession(301);
  const zip = encodeSessionZip(session);
  const restored = decodeSessionZip(zip);
  assert.deepEqual(restored, session);
  assert.deepEqual(collectedReplay(restored, 123), collectedReplay(session, 256));
  const files = unzipSync(zip);
  const rows = strFromU8(files["trace.csv"]).trimEnd().split("\n");
  assert.equal(rows.length, session.pcm.length + 1);
  assert.equal(rows[0], "sampleIndex,timeSeconds,x,y,hit");
  assert.ok(rows[1].startsWith(`${session.metadata.initialState.sampleIndex + 1},`));
});

test("CSV uses output-state time and leaves missed wall coordinates empty", () => {
  const frame = new Simulator().getFrame();
  const block: TraceBlock = {
    startSample: 23999, count: 2,
    xy: new Float32Array([0.125, -0.25, NaN, NaN]),
    hits: new Uint8Array([1, 0]), lastFrame: frame,
  };
  const rows = traceBlockToCsv(block, 48000).trimEnd().split("\n");
  assert.equal(rows[0], "24000,0.5,0.125,-0.25,1");
  assert.equal(rows[1], `24001,${24001 / 48000},,,0`);
});

test("session import rejects incompatible models and malformed metadata", () => {
  const original = makeSession(301);
  const invalid = () => structuredClone(original);
  let session = invalid();
  session.metadata.modelVersion = "unsupported";
  assert.throws(() => validateSession(session), /Unsupported model/);
  session = invalid();
  session.metadata.initialState.q = [0];
  assert.throws(() => validateSession(session), /six finite/);
  session = invalid();
  session.metadata.parameterEvents.reverse();
  assert.throws(() => validateSession(session), /ordered sample boundaries/);
  session = invalid();
  session.metadata.sampleCount++;
  assert.throws(() => validateSession(session), /PCM length/);
  session = invalid();
  session.metadata.initialConfig.gain = Infinity;
  assert.throws(() => validateSession(session), /Invalid session parameter/);
});
