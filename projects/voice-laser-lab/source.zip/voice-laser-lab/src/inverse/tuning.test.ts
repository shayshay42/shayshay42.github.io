import assert from 'node:assert/strict';
import test from 'node:test';
import { DEFAULT_CONFIG, neutralWallX, Simulator } from '../physics/engine';
import { solveInverse } from './solver';
import { solveWithTuning } from './tuning';

test('opt-in tuning fits both lobes while preserving the wall, gain and waveform limits', () => {
  const config = { ...DEFAULT_CONFIG };
  const path = Array.from({ length: 128 }, (_, i) => ({
    x: 0.025 * Math.sin(2 * Math.PI * i / 128), y: 0.015 * Math.sin(4 * Math.PI * i / 128),
  }));
  const options = { config, path, maxAmplitude: 0.2, sampleRate: 16000, search: 'quick' as const };
  const fixed = solveInverse(options);
  const tuned = solveWithTuning(options);
  assert.deepEqual(config, DEFAULT_CONFIG);
  assert.equal(tuned.config.gain, config.gain);
  assert.equal(tuned.config.wallDistance, config.wallDistance);
  assert.ok(tuned.config.tension >= 0.25 && tuned.config.tension <= 4);
  assert.ok(tuned.config.damping >= 0.005 && tuned.config.damping <= 0.15);
  assert.ok(tuned.config.asymmetry >= 0 && tuned.config.asymmetry <= 0.5);
  assert.ok(tuned.result.metrics.rmsDistance < fixed.metrics.rmsDistance * 0.5);
  assert.ok(tuned.result.metrics.coverage >= 0.92);
  assert.ok(tuned.result.pcm.every(value => Math.abs(value) <= options.maxAmplitude));
  const replay = new Simulator(tuned.config, options.sampleRate).process(tuned.result.pcm);
  const neutral = neutralWallX(tuned.config.wallDistance);
  tuned.result.trace.forEach((point, i) => {
    const index = tuned.result.warmupSamples + i;
    assert.equal(point.x, replay.xy[2 * index] - neutral);
    assert.equal(point.y, replay.xy[2 * index + 1]);
  });
});

test('the complete 48 kHz search keeps most of a square within the 2 mm trace tolerance', () => {
  const path = [{ x: -0.025, y: 0.025 }, { x: 0.025, y: 0.025 },
    { x: 0.025, y: -0.025 }, { x: -0.025, y: -0.025 }];
  const { result } = solveWithTuning({ path, config: DEFAULT_CONFIG, sampleRate: 48000 });
  assert.equal(result.metrics.tolerance, 0.002);
  assert.ok(result.metrics.coverage >= 0.90);
  assert.ok(result.metrics.offStroke <= 0.05);
  assert.ok(result.metrics.rmsDistance <= 0.0012);
});

test('a measured response always retains the calibrated apparatus and prescribed timing', () => {
  const path = Array.from({ length: 80 }, (_, i) => ({
    x: 0.02 * Math.cos(2 * Math.PI * i / 80), y: 0.02 * Math.sin(2 * Math.PI * i / 80),
  }));
  const options = { path, config: { ...DEFAULT_CONFIG, tension: 1.75, wallDistance: 1.25 },
    response: [{ frequency: 100, xRe: 1, xIm: 0, yRe: 0, yIm: 0 }],
    sampleRate: 8000, periodSamples: 80, preserveTiming: true };
  const { result, config } = solveWithTuning(options);
  assert.deepEqual(config, options.config);
  assert.equal(result.model, 'measured');
  assert.equal(result.periodSamples, 80);
  assert.deepEqual(result.pcm, solveInverse(options).pcm);
  assert.ok(result.metrics.coverage < 0.5);
});
