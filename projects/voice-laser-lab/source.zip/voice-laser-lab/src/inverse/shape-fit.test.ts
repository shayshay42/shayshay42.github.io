import assert from 'node:assert/strict';
import test from 'node:test';
import { DEFAULT_CONFIG, Simulator, neutralWallX } from '../physics/engine';
import { modelResponse, shapeMetrics } from './solver';
import { fitPeriodicShape } from './shape-fit';
import { nearestSquared, outlineError } from './outline-error';

const tau = 2 * Math.PI;
function audio(tones: {re: number; im: number}[], period: number) {
  return Float32Array.from({ length: period }, (_, j) => tones.reduce((sum, tone, k) => {
    const angle = tau * (k + 1) * j / period;
    return sum + tone.re * Math.cos(angle) - tone.im * Math.sin(angle);
  }, 0));
}

test('direct geometry optimization covers square edges on nonlinear replay with a bounded mono drive', () => {
  const rate = 16000, period = 400;
  const h = modelResponse(DEFAULT_CONFIG, rate);
  const transfer = Array.from({ length: 16 }, (_, k) => h((k + 1) * rate / period));
  const target = [{ x: -0.025, y: 0.025 }, { x: 0.025, y: 0.025 }, { x: 0.025, y: -0.025 }, { x: -0.025, y: -0.025 }];
  const dense = Array.from({ length: 96 }, (_, i) => {
    const index = Math.floor(i / 24), t = (i % 24) / 24, a = target[index], b = target[(index + 1) % 4];
    return { x: a.x * (1 - t) + b.x * t, y: a.y * (1 - t) + b.y * t };
  });
  const tones = transfer.map((_, k) => ({ re: 0.01 * Math.cos(k * k) / (k + 1), im: 0.01 * Math.sin(k * k) / (k + 1) }));
  const args = { target: dense, transfer, tones, period, limit: 0.8 };
  const start = fitPeriodicShape({ ...args, iterations: 0 });
  const fit = fitPeriodicShape(args);
  assert.ok(fit.score < 0.4 * start.score);
  const cycle = audio(fit.tones, period);
  assert.ok(cycle.every(value => Math.abs(value) <= args.limit + 1e-7));
  const replay = new Simulator(DEFAULT_CONFIG, rate).process(Float32Array.from({ length: rate }, (_, j) => cycle[j % period]));
  assert.ok(replay.hits.subarray(-period).every(Boolean));
  const neutral = neutralWallX(DEFAULT_CONFIG.wallDistance);
  const trace = Array.from({ length: period }, (_, j) => ({ x: replay.xy[2 * (rate - period + j)] - neutral,
    y: replay.xy[2 * (rate - period + j) + 1] }));
  const observed = shapeMetrics(trace, dense, 0.05);
  assert.ok(observed.rmsDistance < 0.006);
  assert.ok(Math.abs(observed.rmsDistance - fit.score) < 0.0007);
  assert.equal(fit.reference.length, dense.length);
});

test('a calibrated ellipse keeps its scale and orientation and gets no worse when it already fits', () => {
  const h = [{ frequency: 100, xRe: 1, xIm: 0, yRe: 0, yIm: -0.6 }];
  const target = Array.from({ length: 128 }, (_, j) => ({ x: 0.025 * Math.cos(tau * j / 128), y: 0.015 * Math.sin(tau * j / 128) }));
  const args = { target, transfer: h, tones: [{ re: 0.025, im: 0 }], period: 151, limit: 0.1 };
  const baseline = fitPeriodicShape({ ...args, iterations: 0 });
  const fit = fitPeriodicShape(args);
  assert.ok(fit.score <= baseline.score + 1e-12 && fit.score < 0.00002);
  assert.ok(Math.abs(Math.hypot(fit.tones[0].re, fit.tones[0].im) - 0.025) < 0.0001);
});

test('the amplitude bound holds between optimization grid nodes and a single axis keeps its limits', () => {
  const period = 977, limit = 0.011;
  const target = Array.from({ length: 75 }, (_, j) => ({ x: 0.025 * Math.cos(tau * j / 75), y: 0.025 * Math.sin(tau * j / 75) }));
  const transfer = Array.from({ length: 16 }, (_, k) => ({ frequency: (k + 1) * 20, xRe: 1, xIm: 0, yRe: 0, yIm: 0 }));
  const tones = transfer.map((_, k) => ({ re: Math.cos(k * 0.13), im: Math.sin(k * 0.13) }));
  const result = fitPeriodicShape({ target, transfer, tones, period, limit });
  assert.ok(audio(result.tones, period).every(u => Math.abs(u) <= limit + 1e-9));
  assert.ok(result.score > 0.012);
});


test('arc-length and tail polish reduces the excursion of the replayed figure eight', () => {
  const rate = 16000, period = 400, config = DEFAULT_CONFIG, neutral = neutralWallX(config.wallDistance);
  const target = Array.from({ length: 96 }, (_, i) =>
    ({ x: 0.025 * Math.sin(tau * i / 96), y: 0.015 * Math.sin(2 * tau * i / 96) }));
  const h = modelResponse(config, rate);
  const transfer = Array.from({ length: 16 }, (_, k) => h((k + 1) * rate / period));
  const tones = transfer.map((_, k) => ({ re: 0.01 * Math.cos(k * k) / (k + 1), im: 0.01 * Math.sin(k * k) / (k + 1) }));
  const options = { target, transfer, tones, period, limit: 0.8 };
  const initial = fitPeriodicShape(options);
  const fitted = fitPeriodicShape({ ...options, tones: initial.tones, lineWeight: 1, orderWeight: 0.002, iterations: 90 });
  assert.ok(fitted.lineScore < 0.80 * initial.lineScore);
  function replayErrors(wave: Float32Array) {
    const sim = new Simulator(config, rate);
    sim.process(Float32Array.from({ length: rate }, (_, j) => wave[j % period]));
    const b = sim.process(wave);
    assert.ok(b.hits.every(Boolean));
    const trace = Array.from({ length: period }, (_, j) => ({ x: b.xy[2 * j] - neutral, y: b.xy[2 * j + 1] }));
    const metrics = shapeMetrics(trace, target, 0.05);
    return { combined: outlineError(trace, target, metrics), maxSq: Math.max(...trace.map(p => nearestSquared(p, target, 1))) };
  }
  const before = replayErrors(audio(initial.tones, period));
  const after = replayErrors(audio(fitted.tones, period));
  assert.ok(after.combined < before.combined);
  assert.ok(after.maxSq < before.maxSq);
});
