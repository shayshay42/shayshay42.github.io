import { Simulator, neutralWallX, validateConfig, type SimulationConfig, type SimulationState } from '../physics/engine';
import { fitPeriodicShape } from './shape-fit';
import { geometrySeeds } from './geometry-seeds';
import { nearestSquared, outlineError } from './outline-error';

export interface Point { x: number; y: number }
/** Metres per unit PCM. A cosine input gives Re(H exp(iωt)). */
export interface FrequencyResponse { frequency: number; xRe: number; xIm: number; yRe: number; yIm: number }
export interface InverseOptions {
  /** One ordered loop in wall metres relative to the neutral spot. Includes visible return strokes. */
  path: Point[];
  config: SimulationConfig;
  sampleRate?: number;
  response?: FrequencyResponse[];
  periodSamples?: number;
  preserveTiming?: boolean;
  maxAmplitude?: number;
  /** Quick ranks fits by timed tracking. Thorough also optimizes the shape of the complete loop. */
  search?: 'quick' | 'thorough';
}
export interface InverseMetrics {
  /** Fraction of target within tolerance, fraction of trace outside tolerance, fraction of missed samples. */
  coverage: number;
  offStroke: number;
  missFraction: number;
  /** Symmetric RMS distance in metres including a drawing-width penalty per missed sample. */
  rmsDistance: number;
  tolerance: number;
}
export interface InverseResult {
  pcm: Float32Array;
  sampleRate: number;
  periodSamples: number;
  frequency: number;
  warmupSamples: number;
  /** Relative modal-state distance to the exact periodic orbit. A frequency-response table has no transient model. */
  closureError: number | null;
  /** Final PCM period, after each consumed input sample. A simulated miss has NaN coordinates. */
  trace: Point[];
  reference: Point[];
  metrics: InverseMetrics;
  /** Spatial fit in metres, including visible excursions between slow sections of the stroke. */
  outlineError: number;
  model: 'simulator' | 'measured';
}

const GRID = 96;
const HARMONICS = 16;
const TAU = 2 * Math.PI;
const LIMIT_PATH_POINTS = 100_000;

interface Complex { re: number; im: number }
interface Coefficients { x: Complex[]; y: Complex[] }
type Transfer = (frequency: number) => FrequencyResponse;
interface Candidate {
  period: number;
  target: Point[];
  transfer: FrequencyResponse[];
  tones: Complex[];
  score: number;
  shapeError?: number;
}

/** Probe the simulator's exact discrete oscillator update and differentiate only the wall geometry. */
export function linearizedModes(config: SimulationConfig, rate: number) {
  const engine = new Simulator(config, rate);
  const rest = engine.getState();
  engine.process([1]);
  const b = engine.getState();
  return rest.q.map((_, j) => {
    const state = { q: [...rest.q], v: [...rest.v], sampleIndex: 0 };
    const epsilon = 1e-7;
    state.q[j] = -epsilon;
    engine.reset(state);
    const minus = engine.getFrame();
    state.q[j] = epsilon;
    engine.reset(state);
    const plus = engine.getFrame();
    const cx = (plus.x - minus.x) / (2 * epsilon);
    const cy = (plus.y - minus.y) / (2 * epsilon);
    engine.process([0]);
    const column = engine.getState();
    const a00 = column.q[j] / epsilon;
    const a10 = column.v[j] / epsilon;
    state.q[j] = 0;
    state.v[j] = 1;
    engine.reset(state);
    engine.process([0]);
    const second = engine.getState();
    return { cx, cy, a00, a01: second.q[j], a10, a11: second.v[j], bq: b.q[j], bv: b.v[j] };
  });
}

export function modelResponse(config: SimulationConfig, rate: number): Transfer {
  const modes = linearizedModes(config, rate).map(m => ({
    cx: m.cx, cy: m.cy, tr: m.a00 + m.a11, det: m.a00 * m.a11 - m.a10 * m.a01,
    b0: m.bq, b1: m.a01 * m.bv - m.a11 * m.bq,
  }));
  return frequency => {
    const theta = -TAU * frequency / rate;
    const c = Math.cos(theta), s = Math.sin(theta);
    const c2 = Math.cos(theta * 2), s2 = Math.sin(theta * 2);
    let xRe = 0, xIm = 0, yRe = 0, yIm = 0;
    for (const m of modes) {
      const dr = 1 - m.tr * c + m.det * c2;
      const di = -m.tr * s + m.det * s2;
      const norm = dr * dr + di * di;
      if (norm < 1e-24) continue;
      const nr = m.b0 + m.b1 * c, ni = m.b1 * s;
      const re = (nr * dr + ni * di) / norm, im = (ni * dr - nr * di) / norm;
      xRe += m.cx * re; xIm += m.cx * im;
      yRe += m.cy * re; yIm += m.cy * im;
    }
    return { frequency, xRe, xIm, yRe, yIm };
  };
}

function measuredResponse(rows: FrequencyResponse[]): Transfer {
  if (rows.length > 8192) throw new RangeError('Calibration supports up to 8192 frequency rows.');
  const sorted = [...rows].sort((a, b) => a.frequency - b.frequency);
  if (!sorted.length || sorted.some((r, i) => ![r.frequency, r.xRe, r.xIm, r.yRe, r.yIm].every(Number.isFinite)
    || r.frequency <= 0 || (i > 0 && r.frequency === sorted[i - 1].frequency))) {
    throw new RangeError('Calibration requires distinct positive frequencies and finite complex responses.');
  }
  if (sorted.every(r => !(r.xRe || r.xIm || r.yRe || r.yIm))) throw new RangeError('The measured response is zero. Check the optical tracking and the playback level.');
  return frequency => {
    const zero = { frequency, xRe: 0, xIm: 0, yRe: 0, yIm: 0 };
    // Do not invent a transfer function outside the measured band.
    if (frequency < sorted[0].frequency || frequency > sorted[sorted.length - 1].frequency) return zero;
    let lo = 0, hi = sorted.length - 1;
    while (hi - lo > 1) {
      const mid = (lo + hi) >>> 1;
      if (sorted[mid].frequency <= frequency) lo = mid;
      else hi = mid;
    }
    const a = sorted[lo], b = sorted[hi];
    const t = hi === lo ? 0 : (frequency - a.frequency) / (b.frequency - a.frequency);
    return { frequency, xRe: a.xRe + (b.xRe - a.xRe) * t, xIm: a.xIm + (b.xIm - a.xIm) * t,
      yRe: a.yRe + (b.yRe - a.yRe) * t, yIm: a.yIm + (b.yIm - a.yIm) * t };
  };
}

function resample(path: Point[], count: number, byLength = false): Point[] {
  const ends = [0];
  for (let i = 0; i < path.length; i++) {
    const a = path[i], b = path[(i + 1) % path.length];
    ends.push(ends[i] + (byLength ? Math.hypot(b.x - a.x, b.y - a.y) : 1));
  }
  const total = ends[path.length];
  let index = 0;
  return Array.from({ length: count }, (_, i) => {
    const position = total * i / count;
    while (index + 1 < path.length && ends[index + 1] <= position) index++;
    const a = path[index], b = path[(index + 1) % path.length];
    const t = (position - ends[index]) / (ends[index + 1] - ends[index] || 1);
    return { x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t };
  });
}

function gridBasis(count: number, length: number) {
  return Array.from({ length: count }, (_, h) => ({
    cos: Float64Array.from({ length }, (_, j) => Math.cos(TAU * (h + 1) * j / length)),
    sin: Float64Array.from({ length }, (_, j) => Math.sin(TAU * (h + 1) * j / length)),
  }));
}
const BASIS = gridBasis(HARMONICS, GRID);

function spectrum(path: Point[]): Coefficients {
  const x: Complex[] = [], y: Complex[] = [];
  for (const { cos, sin } of BASIS) {
    let xr = 0, xi = 0, yr = 0, yi = 0;
    for (let j = 0; j < GRID; j++) {
      xr += path[j].x * cos[j]; xi -= path[j].x * sin[j];
      yr += path[j].y * cos[j]; yi -= path[j].y * sin[j];
    }
    x.push({ re: 2 * xr / GRID, im: 2 * xi / GRID });
    y.push({ re: 2 * yr / GRID, im: 2 * yi / GRID });
  }
  return { x, y };
}

function inverseTones(h: FrequencyResponse[], target: Coefficients, ridge = 1e-8): Complex[] {
  return h.map(({ xRe, xIm, yRe, yIm }, k) => {
    const power = xRe * xRe + xIm * xIm + yRe * yRe + yIm * yIm;
    const x = target.x[k], y = target.y[k];
    return { re: (xRe * x.re + xIm * x.im + yRe * y.re + yIm * y.im) / (power + ridge),
      im: (xRe * x.im - xIm * x.re + yRe * y.im - yIm * y.re) / (power + ridge) };
  });
}

function synthesize(tones: Complex[], basis: ReturnType<typeof gridBasis>): Float32Array {
  const samples = new Float32Array(basis[0].cos.length);
  for (let k = 0; k < tones.length; k++) {
    const { re, im } = tones[k], { cos, sin } = basis[k];
    for (let j = 0; j < samples.length; j++) samples[j] += re * cos[j] - im * sin[j];
  }
  return samples;
}
function bounded(tones: Complex[], basis: ReturnType<typeof gridBasis>, limit: number) {
  const values = synthesize(tones, basis);
  let peak = 0;
  for (const value of values) peak = Math.max(peak, Math.abs(value));
  const scale = peak > limit ? limit / peak : 1;
  return tones.map(({ re, im }) => ({ re: re * scale, im: im * scale }));
}
/** Increase the input-energy penalty until the high harmonics fit the available drive headroom. */
function initialTones(transfer: FrequencyResponse[], target: Coefficients, limit: number) {
  let ridge = 1e-8;
  let tones = inverseTones(transfer, target, ridge);
  const peak = (candidate: Complex[]) => {
    let maximum = 0;
    for (const value of synthesize(candidate, BASIS)) maximum = Math.max(maximum, Math.abs(value));
    return maximum;
  };
  if (peak(tones) <= limit) return tones;
  do {
    ridge *= 4;
    tones = inverseTones(transfer, target, ridge);
  } while (peak(tones) > limit && ridge < 1e6);
  let low = ridge / 4, high = ridge;
  for (let i = 0; i < 4; i++) {
    const mid = Math.sqrt(low * high);
    const trial = inverseTones(transfer, target, mid);
    if (peak(trial) <= limit) { high = mid; tones = trial; }
    else low = mid;
  }
  return bounded(tones, BASIS, limit);
}
function predicted(tones: Complex[], h: FrequencyResponse[], basis: ReturnType<typeof gridBasis>): Point[] {
  function axis(isX: boolean) {
    return synthesize(tones.map(({ re, im }, k) => {
      const hr = isX ? h[k].xRe : h[k].yRe, hi = isX ? h[k].xIm : h[k].yIm;
      return { re: hr * re - hi * im, im: hr * im + hi * re };
    }), basis);
  }
  const x = axis(true), y = axis(false);
  return Array.from(x, (value, i) => ({ x: value, y: y[i] }));
}
function dist2(a: Point, b: Point) { return (a.x - b.x) ** 2 + (a.y - b.y) ** 2; }
function trackCost(output: Point[], target: Point[], size: number) {
  let error = 0;
  for (let i = 0; i < output.length; i++) {
    error += Number.isFinite(output[i].x) ? dist2(output[i], target[i]) : size * size;
  }
  return error / output.length;
}

/** Walk the ordered target ring once. A cell may advance 0, 1 or 2 target points per time step. */
function retime(output: Point[], target: Point[], size: number): Point[] {
  const n = GRID;
  const last = new Int8Array((n + 1) * (n + 1));
  let row = new Float64Array(n + 1).fill(Infinity);
  row[0] = 0;
  const speedPenalty = (size / n) ** 2 * 0.2;
  for (let t = 1; t <= n; t++) {
    const next = new Float64Array(n + 1).fill(Infinity);
    const p = output[t % n];
    for (let j = Math.max(0, 2 * t - n); j <= Math.min(n, 2 * t); j++) {
      let step = 0, best = row[j] + speedPenalty;
      if (j > 0 && row[j - 1] < best) { step = 1; best = row[j - 1]; }
      if (j > 1 && row[j - 2] + speedPenalty < best) { step = 2; best = row[j - 2] + speedPenalty; }
      next[j] = best + (Number.isFinite(p.x) ? dist2(p, target[j % n]) : size * size);
      last[t * (n + 1) + j] = step;
    }
    row = next;
  }
  const timed = [...target];
  let j = n;
  for (let t = n; t > 0; t--) {
    timed[t % n] = target[j % n];
    j -= last[t * (n + 1) + j];
  }
  return timed;
}

export function shapeMetrics(trace: Point[], target: Point[], size: number): InverseMetrics {
  const tolerance = Math.max(1e-6, 0.04 * size);
  let coverage = 0, offStroke = 0, misses = 0, targetError = 0, drawnError = 0;
  for (const p of target) {
    const d = nearestSquared(p, trace, size * size);
    if (d <= tolerance ** 2) coverage++;
    targetError += d;
  }
  for (const p of trace) {
    const hit = Number.isFinite(p.x);
    if (!hit) misses++;
    const d = hit ? nearestSquared(p, target, size * size) : size * size;
    if (!hit || d > tolerance ** 2) offStroke++;
    drawnError += d;
  }
  return { coverage: coverage / target.length, offStroke: offStroke / trace.length, missFraction: misses / trace.length,
    rmsDistance: Math.sqrt((targetError / target.length + drawnError / trace.length) / 2), tolerance };
}

function periodsFor(options: InverseOptions, rate: number) {
  if (options.periodSamples !== undefined) {
    if (!Number.isInteger(options.periodSamples) || options.periodSamples < 8 || options.periodSamples > rate) {
      throw new RangeError('A period must contain 8 samples to one second of audio.');
    }
    return [options.periodSamples];
  }
  const measured = options.response;
  const lower = measured ? Math.max(4, Math.min(...measured.map(h => h.frequency)) / HARMONICS)
    : Math.max(8, 25 * Math.sqrt(options.config.tension));
  const upper = measured ? Math.min(rate / 8, Math.max(...measured.map(h => h.frequency)))
    : Math.min(rate / 8, 460 * Math.sqrt(options.config.tension));
  const periods = new Set<number>();
  for (let f = lower; f <= upper; f *= 1.014) periods.add(Math.round(rate / f));
  // Include measured test tones and lower fundamentals that can place harmonics on them.
  for (const row of measured ?? []) {
    for (let h = 1; h <= 4; h++) {
      const n = Math.round(h * rate / row.frequency);
      if (n >= 8 && n <= rate / lower) periods.add(n);
    }
  }
  if (!periods.size) throw new RangeError('No usable audio frequencies in the calibration.');
  return [...periods];
}

/** Each independent oscillator has a two-by-two transition over a whole period. */
function periodTransition(config: SimulationConfig, rate: number, length: number) {
  const simulator = new Simulator(config, rate);
  const rest = simulator.getState();
  const zeros = new Float32Array(length);
  function column(axis: 'q' | 'v') {
    const state = { ...rest, [axis]: rest[axis].map(() => 1) };
    simulator.reset(state);
    simulator.process(zeros);
    return simulator.getState();
  }
  const q = column('q'), v = column('v');
  return rest.q.map((_, i) => ({ a: 1 - q.q[i], b: -v.q[i], c: -q.v[i], d: 1 - v.v[i] }));
}

function periodicState(transition: ReturnType<typeof periodTransition>, forced: SimulationState) {
  const q: number[] = [], v: number[] = [];
  for (let i = 0; i < transition.length; i++) {
    const { a, b, c, d } = transition[i];
    const det = a * d - b * c;
    q.push((d * forced.q[i] - b * forced.v[i]) / det);
    v.push((a * forced.v[i] - c * forced.q[i]) / det);
  }
  return { q, v };
}

function orbitError(state: SimulationState, periodic: Pick<SimulationState, 'q' | 'v'>): number {
  let difference = 0, power = 0;
  // Scale velocities to displacements using a common angular frequency near the membrane resonances.
  for (let i = 0; i < state.q.length; i++) {
    difference += (state.q[i] - periodic.q[i]) ** 2 + ((state.v[i] - periodic.v[i]) / 1000) ** 2;
    power += periodic.q[i] ** 2 + (periodic.v[i] / 1000) ** 2;
  }
  return Math.sqrt(difference / Math.max(1e-30, power));
}

function distinctPeriods(ranked: Candidate[], count: number): Candidate[] {
  const selected: Candidate[] = [];
  for (const candidate of ranked) {
    if (selected.some(s => Math.abs(s.period / candidate.period - 1) < 0.035)) continue;
    selected.push(candidate);
    if (selected.length === count) break;
  }
  return selected;
}

/** Give slower loops a chance to put several harmonics near distinct membrane resonances.
 * A ranking based solely on the initial waveform discards these loops before their tones can move.
 */
function geometricCandidates(pool: Candidate[], seeds: Candidate[], uniform: Point[], periods: number[],
  rate: number, response: Transfer, limit: number): Candidate[] {
  const ranked = [...pool].sort((a, b) => a.shapeError! - b.shapeError!);
  const bands = new Map<number, Candidate>();
  for (const candidate of ranked) {
    const band = Math.floor(Math.log(candidate.period) / Math.log(1.10));
    if (!bands.has(band)) bands.set(band, candidate);
  }
  const matches = geometrySeeds(uniform, periods, rate, response, limit).map(seed => ({
    ...seed, transfer: seed.tones.map((_, i) => response(rate * (i + 1) / seed.period)),
  }));
  const starts = [...new Set([...seeds, ...distinctPeriods(ranked, 5), ...bands.values(), ...matches])];
  function refine(candidate: Candidate, iterations: number, harmonics = candidate.tones.length, orderWeight = 0.045, lineWeight = 0) {
    const count = Math.min(harmonics, Math.floor((candidate.period - 1) / 2));
    const tones = Array.from({ length: count }, (_, i) => candidate.tones[i] ?? { re: 0, im: 0 });
    const transfer = tones.map((_, i) => candidate.transfer[i] ?? response(rate * (i + 1) / candidate.period));
    const fit = fitPeriodicShape({ target: candidate.target, transfer, tones, period: candidate.period, limit, iterations, orderWeight, lineWeight });
    // Keep the full stroke between passes. Its timed reference can skip fine details.
    return { ...candidate, transfer, tones: fit.tones, reference: fit.reference, shapeError: fit.score, lineScore: fit.lineScore };
  }
  const coarse = starts.map(seed => refine(seed, 35)).sort((a, b) => a.shapeError - b.shapeError);
  const fine = distinctPeriods(coarse, 7).map(seed => refine(seed, 120)).sort((a, b) => a.shapeError - b.shapeError);
  const extended = fine.slice(0, 3).map(seed => refine(seed, 155, 32, 0.002)).sort((a, b) => a.shapeError - b.shapeError);
  const finalists = [...fine, ...extended];
  if (periods.length > 1) {
    const seed = extended[0];
    const nearby = new Set([0.98, 0.9925, 1.0075, 1.02].map(factor => Math.round(seed.period * factor)));
    for (const period of nearby) {
      if (period === seed.period || period < 2 * seed.tones.length + 1 || period > rate) continue;
      const transfer = seed.tones.map((_, k) => response(rate * (k + 1) / period));
      // Project the previous wall harmonics onto the new transfer vector before changing the loop speed.
      const tones = seed.tones.map((u, k) => {
        const a = seed.transfer[k], b = transfer[k];
        const power = b.xRe ** 2 + b.xIm ** 2 + b.yRe ** 2 + b.yIm ** 2 + 1e-10;
        const re = (b.xRe * a.xRe + b.xIm * a.xIm + b.yRe * a.yRe + b.yIm * a.yIm) / power;
        const im = (b.xRe * a.xIm - b.xIm * a.xRe + b.yRe * a.yIm - b.yIm * a.yRe) / power;
        return { re: re * u.re - im * u.im, im: re * u.im + im * u.re };
      });
      finalists.push(refine({ ...seed, period, tones, transfer }, 85, tones.length, 0.002));
    }
  }
  // A fast chord can have little influence on a time-sampled score and still
  // leave a long stray line on the wall. Compete on its actual drawn length.
  const byLine = [...finalists].sort((a, b) => a.lineScore - b.lineScore);
  const lineFits = distinctPeriods(byLine, 3).map(seed => refine(seed, 130, 32, 0.005, 0.85));
  const aligned = finalists.sort((a, b) => a.shapeError - b.shapeError)
    .map(seed => ({ ...seed, target: seed.reference }));
  return [...distinctPeriods(aligned, 4), ...lineFits.map(seed => ({ ...seed, target: seed.reference }))];
}

export function solveInverse(options: InverseOptions): InverseResult {
  const rate = options.sampleRate ?? 48000, limit = options.maxAmplitude ?? 0.8;
  validateConfig(options.config);
  if (!options.response && options.config.gain === 0) throw new RangeError('Increase the input gain so that audio can move the mirror.');
  if (!options.response && options.config.damping === 0) throw new RangeError('Set positive damping to let a repeated waveform settle from rest.');
  if (!Number.isInteger(rate) || rate < 8000 || rate > 384000) throw new RangeError('Choose an audio sample rate from 8 to 384 kHz.');
  if (!Number.isFinite(limit) || limit <= 0 || limit > 1) throw new RangeError('Maximum PCM amplitude must be in (0, 1].');
  if (!Array.isArray(options.path) || options.path.length < 2 || options.path.length > LIMIT_PATH_POINTS
    || options.path.some(p => !p || !Number.isFinite(p.x) || !Number.isFinite(p.y))) {
    throw new RangeError('A path needs 2 to 100,000 finite wall-coordinate points.');
  }
  const path = options.path.slice();
  if (path.length > 2 && dist2(path[0], path[path.length - 1]) === 0) path.pop();
  const uniform = resample(path, GRID, true);
  const width = Math.max(...uniform.map(p => p.x)) - Math.min(...uniform.map(p => p.x));
  const height = Math.max(...uniform.map(p => p.y)) - Math.min(...uniform.map(p => p.y));
  const size = Math.max(width, height);
  if (!(size > 1e-8)) throw new RangeError('The drawn path needs a visible extent.');
  const response = options.response ? measuredResponse(options.response) : modelResponse(options.config, rate);
  const periods = periodsFor(options, rate);
  // Round down to a representable PCM magnitude. The nearest Float32 can be above the limit.
  const roundedLimit = new Float32Array([limit]);
  if (roundedLimit[0] > limit) new Uint32Array(roundedLimit.buffer)[0]--;
  const pcmLimit = roundedLimit[0];
  const original = resample(path, GRID);
  const targets = options.preserveTiming ? [original] : [uniform, [uniform[0], ...uniform.slice(1).reverse()], original];
  const pool: Candidate[] = [];
  const fitShape = !options.preserveTiming && options.search !== 'quick';
  const coarseTarget = uniform.filter((_, i) => i % 2 === 0);
  for (const target of targets) {
    const spec = spectrum(target);
    for (const period of periods) {
      const count = Math.min(HARMONICS, Math.floor((period - 1) / 2));
      const transfer = Array.from({ length: count }, (_, k) => response(rate * (k + 1) / period));
      if (!transfer.some(h => h.xRe || h.xIm || h.yRe || h.yIm)) continue;
      const tones = initialTones(transfer, spec, limit);
      const output = predicted(tones, transfer, BASIS);
      const score = trackCost(output, target, size);
      const shapeError = fitShape ? shapeMetrics(output.filter((_, i) => i % 2 === 0), coarseTarget, size).rmsDistance : undefined;
      pool.push({ period, target, transfer, tones, score, shapeError });
    }
  }
  if (!pool.length) throw new RangeError('No calibrated response at the harmonics of the selected period.');
  pool.sort((a, b) => a.score - b.score);
  // Keep several distinct frequency neighbourhoods for exact optical replay.
  const seeds = distinctPeriods(pool, 4);
  if (fitShape) {
    seeds.push(...geometricCandidates(pool, seeds, uniform, periods, rate, response, limit));
  }

  let best: InverseResult | undefined;
  let bestScore = Infinity;
  for (const seed of seeds) {
    const period = seed.period, basis = gridBasis(seed.tones.length, period);
    const initialCycles = Math.max(3, Math.ceil(0.65 * rate / period));
    const transition = options.response ? null : periodTransition(options.config, rate, period);
    let tones = seed.tones, target = seed.target;
    let previous = Infinity;
    for (let iteration = 0; iteration < 4; iteration++) {
      tones = bounded(tones, basis, limit);
      const cycle = synthesize(tones, basis);
      // Clamp the final float-rounding overshoot as well as the continuous candidate peaks.
      for (let j = 0; j < period; j++) cycle[j] = Math.max(-pcmLimit, Math.min(pcmLimit, cycle[j]));
      let cycles = initialCycles;
      let closureError: number | null = null;
      let trace: Point[];
      if (options.response) {
        // Resolve coefficients from the exported Float32 waveform, including roundoff.
        const actual = tones.map((_, k) => {
          let re = 0, im = 0;
          for (let j = 0; j < period; j++) { re += cycle[j] * basis[k].cos[j]; im -= cycle[j] * basis[k].sin[j]; }
          return { re: 2 * re / period, im: 2 * im / period };
        });
        trace = predicted(actual, seed.transfer, basis);
      } else {
        const engine = new Simulator(options.config, rate);
        let block = engine.process(cycle);
        const equilibrium = periodicState(transition!, engine.getState());
        let consumed = 1;
        for (;;) {
          // A bounded block size also bounds temporary XY storage at high device sample rates.
          while (consumed < cycles - 1) {
            const batch = Math.min(cycles - consumed - 1, Math.max(1, Math.floor(8192 / period)));
            const samples = new Float32Array(batch * period);
            for (let j = 0; j < batch; j++) samples.set(cycle, j * period);
            engine.process(samples);
            consumed += batch;
          }
          block = engine.process(cycle);
          consumed++;
          closureError = orbitError(engine.getState(), equilibrium);
          if (closureError <= 0.005 || cycles * period >= 6 * rate) break;
          cycles = Math.min(cycles * 2, Math.ceil(6 * rate / period));
        }
        if (closureError > 0.005) break;
        const neutral = neutralWallX(options.config.wallDistance);
        trace = Array.from(block.hits, (hit, j) => hit
          ? { x: block.xy[j * 2] - neutral, y: block.xy[j * 2 + 1] } : { x: NaN, y: NaN });
      }
      const metrics = shapeMetrics(trace, uniform, size);
      const output = resample(trace, GRID);
      const spatialError = outlineError(trace, uniform, metrics);
      const score = (fitShape ? spatialError : metrics.rmsDistance)
        + 0.04 * Math.sqrt(trackCost(output, target, size)) + size * metrics.missFraction;
      if (score < bestScore) {
        bestScore = score;
        const pcm = new Float32Array(cycles * period);
        for (let c = 0; c < cycles; c++) pcm.set(cycle, c * period);
        best = { pcm, warmupSamples: pcm.length - period, closureError, periodSamples: period, sampleRate: rate, frequency: rate / period, trace, reference: resample(target, period),
          metrics, outlineError: spatialError, model: options.response ? 'measured' : 'simulator' };
      }
      if (iteration > 0 && score >= previous) break;
      previous = score;
      if (!options.preserveTiming) target = retime(output, seed.target, size);
      const error = output.map((p, j) => Number.isFinite(p.x)
        ? { x: target[j].x - p.x, y: target[j].y - p.y } : { x: 0, y: 0 });
      const correction = initialTones(seed.transfer.slice(0, HARMONICS), spectrum(error), 0.4 * limit);
      const scale = metrics.missFraction > 0.02 ? 0.65 : 1;
      tones = tones.map((u, k) => ({ re: scale * u.re + 0.75 * (correction[k]?.re ?? 0), im: scale * u.im + 0.75 * (correction[k]?.im ?? 0) }));
    }
  }
  if (!best) throw new Error('The membrane did not settle within six seconds. Increase damping and try again.');
  return best;
}
