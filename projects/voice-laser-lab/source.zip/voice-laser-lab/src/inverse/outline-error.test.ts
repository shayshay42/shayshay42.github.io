import assert from 'node:assert/strict';
import test from 'node:test';
import { outlineError } from './outline-error';
import { shapeMetrics } from './solver';

const a = { x: -0.025, y: -0.025 }, b = { x: 0.025, y: -0.025 };
const c = { x: 0.025, y: 0.025 }, d = { x: -0.025, y: 0.025 };
const square = [a, b, c, d];
const extent = 0.05;

test('a rapid diagonal crossing costs more than a slight uniform contour error', () => {
  const crossing = [...square, a, c, a];
  const offset = square.map(p => ({ ...p, x: p.x + 0.0007 }));
  const crossingMetrics = shapeMetrics(crossing, square, extent);
  const offsetMetrics = shapeMetrics(offset, square, extent);
  assert.ok(crossingMetrics.rmsDistance < offsetMetrics.rmsDistance);
  const error = outlineError(crossing, square, crossingMetrics);
  assert.ok(error > 0.005);
  assert.ok(error > 5 * outlineError(offset, square, offsetMetrics));
  const pauses = crossing.flatMap(p => Array(17).fill(p));
  assert.equal(outlineError(pauses, square, crossingMetrics), error);
});

test('no light is drawn between detections separated by a miss', () => {
  const miss = { x: NaN, y: NaN };
  const trace = [...square, a, miss, c, d, miss];
  const m = shapeMetrics(trace, square, extent);
  const expected = 0.35 * m.rmsDistance + m.tolerance * (1 - m.coverage);
  assert.ok(Math.abs(outlineError(trace, square, m) - expected) < 1e-12);

  const gone = [miss, miss];
  const noHits = shapeMetrics(gone, square, extent);
  assert.ok(outlineError(gone, square, noHits) >= extent);
});
