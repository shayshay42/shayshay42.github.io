import type { FrequencyResponse, Point } from './solver';

interface Tone { re: number; im: number }
export interface ShapeFitOptions {
  /** Ring in metres, with its orientation and intended start point. */
  target: Point[];
  transfer: FrequencyResponse[];
  tones: Tone[];
  period: number;
  limit: number;
  iterations?: number;
  /** Weight of the ordered traversal relative to the symmetric shape loss. */
  orderWeight?: number;
  /** Blend the symmetric RMS objective with error per unit of drawn length, including its worst 5%. */
  lineWeight?: number;
}

/** Sample a ring by arc length so input point density cannot change coverage. */
function arcSamples(points: Point[], count: number) {
  const arc = [0];
  for (let i = 0; i < points.length; i++) {
    const a = points[i], b = points[(i + 1) % points.length];
    arc.push(arc[i] + Math.hypot(b.x - a.x, b.y - a.y));
  }
  const ring = new Float64Array(2 * count);
  let edge = 0;
  for (let i = 0; i < count; i++) {
    const at = arc[arc.length - 1] * i / count;
    while (edge + 1 < points.length && arc[edge + 1] <= at) edge++;
    const a = points[edge], b = points[(edge + 1) % points.length];
    const t = (at - arc[edge]) / (arc[edge + 1] - arc[edge] || 1);
    ring[i * 2] = a.x + t * (b.x - a.x);
    ring[i * 2 + 1] = a.y + t * (b.y - a.y);
  }
  return ring;
}

function extent(ring: Float64Array) {
  let xmin = Infinity, xmax = -Infinity, ymin = Infinity, ymax = -Infinity;
  for (let i = 0; i < ring.length; i += 2) {
    xmin = Math.min(xmin, ring[i]); xmax = Math.max(xmax, ring[i]);
    ymin = Math.min(ymin, ring[i + 1]); ymax = Math.max(ymax, ring[i + 1]);
  }
  return Math.max(xmax - xmin, ymax - ymin, 1e-10);
}

/** Sum squared point-to-segment distances. Differentiate the closest segment's two endpoints or the query. */
function distanceGradient(queries: Float64Array, edges: Float64Array, updateQuery: boolean, gradient: Float64Array, residual?: Float64Array) {
  const n = edges.length / 2;
  const dx = new Float64Array(n), dy = new Float64Array(n), inverseLength = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    const j = (i + 1) % n;
    dx[i] = edges[2 * j] - edges[2 * i]; dy[i] = edges[2 * j + 1] - edges[2 * i + 1];
    const length = dx[i] ** 2 + dy[i] ** 2;
    inverseLength[i] = length ? 1 / length : 0;
  }
  let sum = 0;
  for (let k = 0; k < queries.length; k += 2) {
    const x = queries[k], y = queries[k + 1];
    let best = Infinity, edge = 0, t = 0, ex = 0, ey = 0;
    for (let i = 0; i < n; i++) {
      const qx = x - edges[2 * i], qy = y - edges[2 * i + 1];
      const u = Math.min(1, Math.max(0, (qx * dx[i] + qy * dy[i]) * inverseLength[i]));
      const rx = qx - u * dx[i], ry = qy - u * dy[i];
      const d = rx * rx + ry * ry;
      if (d < best) { best = d; edge = i; t = u; ex = rx; ey = ry; }
    }
    sum += best;
    if (residual) { residual[k] = ex; residual[k + 1] = ey; }
    if (updateQuery) {
      gradient[k] += ex;
      gradient[k + 1] += ey;
    } else {
      const next = (edge + 1) % n;
      gradient[2 * edge] -= (1 - t) * ex;
      gradient[2 * edge + 1] -= (1 - t) * ey;
      gradient[2 * next] -= t * ex;
      gradient[2 * next + 1] -= t * ey;
    }
  }
  return sum;
}

/** Simpson quadrature along the rendered segments. The tail takes exactly 5% of total drawn length. */
function shapeObjective(trace: Float64Array, ring: Float64Array, lineWeight: number, reportLine = false) {
  const n = trace.length / 2, gradient = new Float64Array(trace.length);
  const useLine = lineWeight > 0 || reportLine;
  const nodeError = useLine ? new Float64Array(trace.length) : undefined;
  const sum = distanceGradient(trace, ring, true, gradient, nodeError) + distanceGradient(ring, trace, false, gradient);
  const rms = Math.sqrt(sum / (2 * n));
  if (!nodeError) return { gradient, rms, lineScore: rms, objective: rms };

  const midpoint = new Float64Array(trace.length), midpointError = new Float64Array(trace.length);
  const lengths = new Float64Array(n), weights = new Float64Array(2 * n), squared = new Float64Array(2 * n);
  let total = 0;
  for (let i = 0; i < n; i++) {
    const j = (i + 1) % n;
    midpoint[2 * i] = (trace[2 * i] + trace[2 * j]) / 2;
    midpoint[2 * i + 1] = (trace[2 * i + 1] + trace[2 * j + 1]) / 2;
    const length = Math.hypot(trace[2 * i] - trace[2 * j], trace[2 * i + 1] - trace[2 * j + 1]);
    lengths[i] = length; total += length;
    weights[i] += length / 6; weights[j] += length / 6; weights[n + i] = 2 * length / 3;
  }
  if (total < 1e-12) return { gradient, rms, lineScore: rms, objective: rms };
  distanceGradient(midpoint, ring, true, midpointError);
  let arcSq = 0;
  for (let i = 0; i < 2 * n; i++) {
    const residual = i < n ? nodeError : midpointError;
    const j = 2 * (i % n);
    squared[i] = residual[j] ** 2 + residual[j + 1] ** 2;
    arcSq += weights[i] * squared[i] / total;
  }
  const order = Array.from({ length: 2 * n }, (_, i) => i).sort((a, b) => squared[b] - squared[a]);
  const tailMass = 0.05 * total, tailWeights = new Float64Array(2 * n);
  let remaining = tailMass, cutoff = 0, tailSq = 0;
  for (const i of order) {
    const mass = Math.min(weights[i], remaining);
    tailWeights[i] = mass / tailMass;
    tailSq += tailWeights[i] * squared[i];
    remaining -= mass; cutoff = squared[i];
    if (remaining <= 0) break;
  }
  const arc = Math.sqrt(arcSq), tail = Math.sqrt(tailSq);
  const lineScore = 0.35 * rms + 0.4 * arc + 0.25 * tail;
  const objective = (1 - lineWeight) * rms + lineWeight * lineScore;
  if (!lineWeight) return { gradient, rms, lineScore, objective };
  const regular = (1 - 0.65 * lineWeight) * objective / Math.max(rms, 1e-12);
  const arcFactor = 0.4 * lineWeight * n * objective / Math.max(arc, 1e-12);
  const tailFactor = 0.25 * lineWeight * n * objective / Math.max(tail, 1e-12);
  for (let j = 0; j < gradient.length; j++) gradient[j] *= regular;
  for (let i = 0; i < n; i++) {
    const j = (i + 1) % n, mid = n + i;
    const vertexWeight = 2 * (arcFactor * weights[i] / total + tailFactor * tailWeights[i]);
    const midpointWeight = arcFactor * weights[mid] / total + tailFactor * tailWeights[mid];
    // The derivative of CVaR with respect to segment length depends on excess above its cutoff.
    const edgeSq = (squared[i] + 4 * squared[mid] + squared[j]) / 6;
    const excess = (Math.max(0, squared[i] - cutoff) + 4 * Math.max(0, squared[mid] - cutoff)
      + Math.max(0, squared[j] - cutoff)) / 6;
    const stretch = lengths[i] > 1e-12 ? (arcFactor * (edgeSq - arcSq)
      + tailFactor * (excess / 0.05 - (tailSq - cutoff))) / (total * lengths[i]) : 0;
    for (let axis = 0; axis < 2; axis++) {
      const a = 2 * i + axis, b = 2 * j + axis;
      const stretchGradient = stretch * (trace[a] - trace[b]);
      gradient[a] += vertexWeight * nodeError[a] + midpointWeight * midpointError[a] + stretchGradient;
      gradient[b] += midpointWeight * midpointError[a] - stretchGradient;
    }
  }
  return { gradient, rms, lineScore, objective };
}

/** Monotone correspondence, from the first target point back to it over one complete traversal. */
function align(trace: Float64Array, target: Float64Array): Float64Array {
  const n = trace.length / 2;
  const steps = new Uint8Array((n + 1) ** 2);
  let last = new Float64Array(n + 1).fill(Infinity), next = new Float64Array(n + 1);
  last[0] = 0;
  for (let t = 1; t <= n; t++) {
    next.fill(Infinity);
    const sample = 2 * (t % n);
    for (let j = Math.max(0, 3 * t - 2 * n); j <= Math.min(n, 3 * t); j++) {
      let cost = Infinity, step = 0;
      for (let advance = 0; advance <= Math.min(3, j); advance++) {
        const total = last[j - advance] + 0.1 * ((advance - 1) / n) ** 2;
        if (total < cost) { cost = total; step = advance; }
      }
      const p = 2 * (j % n);
      next[j] = cost + (trace[sample] - target[p]) ** 2 + (trace[sample + 1] - target[p + 1]) ** 2;
      steps[t * (n + 1) + j] = step;
    }
    [last, next] = [next, last];
  }
  const result = new Float64Array(trace.length);
  let j = n;
  for (let t = n; t > 0; t--) {
    const i = 2 * (t % n), p = 2 * (j % n);
    result[i] = target[p]; result[i + 1] = target[p + 1];
    j -= steps[t * (n + 1) + j];
  }
  return result;
}

function wallBasis(response: FrequencyResponse[], scale: Float64Array, size: number, n: number) {
  return Array.from({ length: 2 * response.length }, (_, k) => {
    const harmonic = k >> 1, h = response[harmonic], column = new Float64Array(2 * n);
    for (let j = 0; j < n; j++) {
      const phase = 2 * Math.PI * (harmonic + 1) * j / n + (k % 2) * Math.PI / 2;
      const c = Math.cos(phase), s = Math.sin(phase), gain = scale[harmonic] / size;
      column[j * 2] = gain * (h.xRe * c - h.xIm * s);
      column[j * 2 + 1] = gain * (h.yRe * c - h.yIm * s);
    }
    return column;
  });
}

function audioBasis(scale: Float64Array, count: number) {
  return Array.from({ length: count }, (_, i) => {
    const row = new Float64Array(2 * scale.length);
    for (let k = 0; k < scale.length; k++) {
      const phase = 2 * Math.PI * (k + 1) * i / count;
      row[2 * k] = scale[k] * Math.cos(phase);
      row[2 * k + 1] = -scale[k] * Math.sin(phase);
    }
    return row;
  });
}
function dot(a: Float64Array, b: Float64Array) {
  let sum = 0;
  for (let i = 0; i < a.length; i++) sum += a[i] * b[i];
  return sum;
}

/** Project peaks onto the sample half-spaces, then scale any remaining overshoot into the amplitude box. */
function limitDrive(coef: Float64Array, rows: Float64Array[], norm2: number, limit: number) {
  if (!norm2) return;
  for (let pass = 0; pass < 2; pass++) {
    for (const row of rows) {
      const u = dot(coef, row);
      if (Math.abs(u) <= limit) continue;
      const delta = (u - Math.sign(u) * limit) / norm2;
      for (let k = 0; k < coef.length; k++) coef[k] -= delta * row[k];
    }
  }
  let peak = 0;
  for (const row of rows) peak = Math.max(peak, Math.abs(dot(coef, row)));
  if (peak > limit) for (let k = 0; k < coef.length; k++) coef[k] *= limit / peak;
}

export function fitPeriodicShape({ target, transfer, tones, period, limit, iterations = 60, orderWeight = 0.045, lineWeight = 0 }: ShapeFitOptions) {
  if (!tones.length || transfer.length !== tones.length || target.length < 2 ||
      !Number.isInteger(period) || period < 2 * tones.length + 1 || !(limit > 0 && limit <= 1) ||
      !Number.isInteger(iterations) || iterations < 0 || !Number.isFinite(orderWeight) || orderWeight < 0 || !(lineWeight >= 0 && lineWeight <= 1)) throw new Error('Invalid shape optimizer dimensions or drive limits.');
  const n = Math.min(period, Math.max(96, 6 * tones.length));
  const ring = arcSamples(target, n), size = extent(ring);
  for (let i = 0; i < ring.length; i++) ring[i] /= size;
  // Scale a parameter by its wall gain, capping the step near transfer zeros.
  const scale = Float64Array.from(transfer, h => {
    const gain = Math.hypot(h.xRe, h.xIm, h.yRe, h.yIm);
    return Math.min(limit * 2, size / Math.max(gain, 1e-12));
  });
  const coefficients = Float64Array.from(tones.flatMap((h, i) => [h.re / scale[i], h.im / scale[i]]));
  const basis = wallBasis(transfer, scale, size, n);
  const peakGrid = audioBasis(scale, Math.min(period, Math.max(160, tones.length * 10)));
  const norm2 = dot(scale, scale);
  const render = (v: Float64Array) => {
    const trace = new Float64Array(n * 2);
    for (let k = 0; k < v.length; k++) {
      const column = basis[k];
      for (let j = 0; j < trace.length; j++) trace[j] += v[k] * column[j];
    }
    return trace;
  };
  limitDrive(coefficients, peakGrid, norm2, limit);
  const first = new Float64Array(coefficients.length), second = new Float64Array(coefficients.length);
  let best = coefficients.slice(), bestLoss = Infinity;
  let ordered: Float64Array = ring;
  for (let step = 0; step <= iterations; step++) {
    const trace = render(coefficients);
    const { gradient, objective } = shapeObjective(trace, ring, lineWeight);
    const loss = objective * objective;
    if (loss < bestLoss) { bestLoss = loss; best = coefficients.slice(); }
    if (step === iterations || bestLoss < 1e-12) break;
    if (step % 10 === 0) ordered = align(trace, ring);
    for (let i = 0; i < gradient.length; i++) gradient[i] += orderWeight * (trace[i] - ordered[i]);
    const time = step + 1;
    const learningRate = 0.017 * (0.16 + 0.84 * (1 - step / iterations));
    for (let k = 0; k < coefficients.length; k++) {
      const g = dot(gradient, basis[k]) / n;
      first[k] = 0.9 * first[k] + 0.1 * g;
      second[k] = 0.98 * second[k] + 0.02 * g * g;
      const adjusted = first[k] / (1 - 0.9 ** time) / (Math.sqrt(second[k] / (1 - 0.98 ** time)) + 1e-7);
      coefficients[k] -= learningRate * adjusted;
    }
    limitDrive(coefficients, peakGrid, norm2, limit);
  }
  // The final bound is applied on every exported sample, even for long periods.
  if (peakGrid.length !== period) {
    const cycle = new Float64Array(period);
    for (let k = 0; k < scale.length; k++) {
      const re = best[2 * k] * scale[k], im = best[2 * k + 1] * scale[k];
      const step = 2 * Math.PI * (k + 1) / period;
      for (let i = 0; i < period; i++) cycle[i] += re * Math.cos(step * i) - im * Math.sin(step * i);
    }
    let peak = 0;
    for (const u of cycle) peak = Math.max(peak, Math.abs(u));
    if (peak > limit) for (let k = 0; k < best.length; k++) best[k] *= limit / peak;
  }
  const trace = render(best);
  const final = shapeObjective(trace, ring, lineWeight, true);
  const matched = align(trace, ring);
  const reference = Array.from({ length: target.length }, (_, i) => {
    const j = i * n / target.length, index = Math.floor(j), next = (index + 1) % n, f = j - index;
    return { x: size * ((1 - f) * matched[2 * index] + f * matched[2 * next]),
      y: size * ((1 - f) * matched[2 * index + 1] + f * matched[2 * next + 1]) };
  });
  return { tones: tones.map((_, k) => ({ re: best[2 * k] * scale[k], im: best[2 * k + 1] * scale[k] })),
    score: size * final.rms, lineScore: size * final.lineScore, reference };
}
