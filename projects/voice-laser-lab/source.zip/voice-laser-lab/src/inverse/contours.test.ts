import assert from 'node:assert/strict';
import test from 'node:test';
import { extractContours } from './contours';

function raster(rows: string[], invert = false): ImageData {
  const width = rows[0].length;
  const data = new Uint8ClampedArray(width * rows.length * 4);
  for (let y = 0; y < rows.length; y++) {
    for (let x = 0; x < width; x++) {
      const i = 4 * (y * width + x);
      const level = (rows[y][x] === '#') !== invert ? 0 : 255;
      data.set([level, level, level, rows[y][x] === ' ' ? 0 : 255], i);
    }
  }
  return { data, width, height: rows.length } as ImageData;
}

test('blank images and transparent backgrounds', () => {
  assert.deepEqual(extractContours(raster(['....', '....'])), []);
  const rows = ['      ', ' #### ', ' #### ', '      '];
  assert.deepEqual(extractContours(raster(rows)), [[
    { x: 1, y: 1 }, { x: 5, y: 1 }, { x: 5, y: 3 }, { x: 1, y: 3 }, { x: 1, y: 1 },
  ]]);
});

test('ordered outlines preserve holes, disconnected strokes, and light ink on dark', () => {
  const rows = ['.............', '.######..###.', '.#....#..###.', '.#....#......', '.######......', '.............'];
  const contours = extractContours(raster(rows));
  assert.equal(contours.length, 3);
  assert.deepEqual(contours, extractContours(raster(rows, true)));
  for (const path of contours) assert.deepEqual(path[0], path.at(-1));
});

test('diagonally touching components remain independently selectable', () => {
  const rows = ['........', '.###....', '.###....', '....###.', '....###.', '........'];
  assert.equal(extractContours(raster(rows)).length, 2);
});
