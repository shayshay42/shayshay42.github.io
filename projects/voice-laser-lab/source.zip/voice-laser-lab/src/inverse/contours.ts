interface Point { x: number; y: number }

// Otsu's threshold maximizes the variance between the two luminance classes.
function threshold(histogram: Uint32Array, count: number): number {
  const total = histogram.reduce((sum, n, level) => sum + n * level, 0);
  let dark = 0, darkSum = 0, best = -1, split = 0;
  for (let level = 0; level < 255; level++) {
    dark += histogram[level];
    darkSum += level * histogram[level];
    if (!dark || dark === count) continue;
    const difference = (total - darkSum) / (count - dark) - darkSum / dark;
    const variance = dark * (count - dark) * difference * difference;
    if (variance > best) { best = variance; split = level; }
  }
  return split;
}

/** Return ordered, closed outlines of contrasting regions, in image pixel coordinates. */
export function extractContours({ width, height, data }: ImageData): Point[][] {
  if (width < 2 || height < 2) return [];
  const gray = new Uint8Array(width * height);
  const histogram = new Uint32Array(256);
  for (let i = 0; i < gray.length; i++) {
    const j = i * 4;
    const luminance = 0.2126 * data[j] + 0.7152 * data[j + 1] + 0.0722 * data[j + 2];
    gray[i] = Math.round(255 - (255 - luminance) * data[j + 3] / 255);
    histogram[gray[i]]++;
  }
  if (histogram.some(count => count === gray.length)) return [];
  const split = threshold(histogram, gray.length);
  let darkBorder = 0, border = 0;
  for (let y = 0; y < height; y++) {
    const step = y === 0 || y === height - 1 ? 1 : width - 1;
    for (let x = 0; x < width; x += step) {
      if (gray[y * width + x] <= split) darkBorder++;
      border++;
    }
  }
  const backgroundIsDark = 2 * darkBorder > border;
  const ink = gray.map(level => Number((level <= split) !== backgroundIsDark));
  // Each pixel contributes its exposed sides, clockwise. Four bits store the
  // outgoing edges at a grid corner in east, south, west, north order.
  const stride = width + 1;
  const edges = new Uint8Array(stride * (height + 1));
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const pixel = y * width + x;
      if (!ink[pixel]) continue;
      const topLeft = y * stride + x;
      if (!y || !ink[pixel - width]) edges[topLeft] |= 1;
      if (x + 1 === width || !ink[pixel + 1]) edges[topLeft + 1] |= 2;
      if (y + 1 === height || !ink[pixel + width]) edges[topLeft + stride + 1] |= 4;
      if (!x || !ink[pixel - 1]) edges[topLeft + stride] |= 8;
    }
  }

  const steps = [1, stride, -1, -stride];
  const contours: { area: number; points: Point[] }[] = [];
  for (let start = 0; start < edges.length; start++) {
    while (edges[start]) {
      let vertex = start, direction = Math.log2(edges[start] & -edges[start]), area = 0;
      const points = [{ x: vertex % stride, y: Math.floor(vertex / stride) }];
      do {
        edges[vertex] &= ~(1 << direction);
        const next = vertex + steps[direction];
        const x = next % stride, y = Math.floor(next / stride);
        area += (vertex % stride) * y - Math.floor(vertex / stride) * x;
        vertex = next;
        if (vertex === start) break;
        // At diagonally touching pixels, turn right to keep each region separate.
        const right = (direction + 1) % 4;
        let turn = direction;
        if (edges[next] & (1 << right)) turn = right;
        else if (!(edges[next] & (1 << direction))) turn = (direction + 3) % 4;
        if (turn !== direction) points.push({ x, y });
        direction = turn;
      } while (vertex !== start);
      if (Math.abs(area) < 12 || points.length < 3) continue;
      points.push({ ...points[0] });
      contours.push({ area: Math.abs(area), points });
    }
  }
  return contours.sort((a, b) => b.area - a.area).slice(0, 24).map(contour => contour.points);
}
