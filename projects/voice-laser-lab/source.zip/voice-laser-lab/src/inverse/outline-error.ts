import type { InverseMetrics, Point } from './solver';

/** Squared distance to a closed polyline, treating missing detections as breaks. */
export function nearestSquared(p: Point, curve: Point[], fallback: number): number {
  let best = Infinity;
  for (let i = 0; i < curve.length; i++) {
    const a = curve[i], b = curve[(i + 1) % curve.length];
    if (!Number.isFinite(a.x) || !Number.isFinite(a.y)) continue;
    let dx = p.x - a.x, dy = p.y - a.y;
    if (Number.isFinite(b.x) && Number.isFinite(b.y)) {
      const vx = b.x - a.x, vy = b.y - a.y, length2 = vx * vx + vy * vy;
      const t = length2 ? Math.min(1, Math.max(0, (dx * vx + dy * vy) / length2)) : 0;
      dx -= t * vx;
      dy -= t * vy;
    }
    best = Math.min(best, dx * dx + dy * dy);
  }
  return Number.isFinite(best) ? best : fallback;
}

/** Rank an entire visible loop in metres. Arc-length sampling gives rapid
 * connectors weight even when they occupy very few audio samples. The worst
 * five percent of the drawn length distinguishes an excursion from a small
 * uniform offset. The original symmetric RMS and coverage still penalize gaps.
 * target is the solver's fixed, arc-length-resampled target outline.
 */
export function outlineError(trace: Point[], target: Point[], metrics: InverseMetrics): number {
  const lengths = new Float64Array(trace.length);
  let perimeter = 0;
  for (let i = 0; i < trace.length; i++) {
    const a = trace[i], b = trace[(i + 1) % trace.length];
    const length = Math.hypot(b.x - a.x, b.y - a.y);
    if (Number.isFinite(length)) {
      lengths[i] = length;
      perimeter += length;
    }
  }
  const uncovered = metrics.tolerance * (1 - metrics.coverage);
  if (perimeter === 0) return metrics.rmsDistance + uncovered;

  const count = 256;
  const squared = new Float64Array(count);
  let segment = 0, start = 0, total = 0;
  const point = { x: 0, y: 0 };
  for (let j = 0; j < count; j++) {
    const distance = (j + 0.5) * perimeter / count;
    while (segment < lengths.length - 1 && start + lengths[segment] <= distance) {
      start += lengths[segment++];
    }
    const a = trace[segment], b = trace[(segment + 1) % trace.length];
    const t = (distance - start) / lengths[segment];
    point.x = a.x + t * (b.x - a.x);
    point.y = a.y + t * (b.y - a.y);
    squared[j] = nearestSquared(point, target, metrics.rmsDistance ** 2);
    total += squared[j];
  }
  squared.sort();
  const tailCount = Math.ceil(0.05 * count);
  let tail = 0;
  for (let j = count - tailCount; j < count; j++) tail += squared[j];
  return 0.35 * metrics.rmsDistance + 0.40 * Math.sqrt(total / count)
    + 0.25 * Math.sqrt(tail / tailCount) + uncovered;
}
