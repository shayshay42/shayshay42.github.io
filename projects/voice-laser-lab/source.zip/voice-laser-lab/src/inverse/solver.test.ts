import assert from 'node:assert/strict';
import test from 'node:test';
import { DEFAULT_CONFIG, Simulator, neutralWallX } from '../physics/engine';
import { decodeFloatWav, encodeFloatWav } from '../session/wav';
import { modelResponse, shapeMetrics, solveInverse, type Point } from './solver';

const rate = 12000;
const neutral = neutralWallX(DEFAULT_CONFIG.wallDistance);
function periodicPath(n: number, point: (angle: number) => Point) {
  return Array.from({ length: n }, (_, j) => point(2 * Math.PI * j / n));
}
const ellipse = periodicPath(96, a => ({ x: 0.15 * Math.cos(a), y: 0.07 * Math.sin(a) }));

test('free-timing search improves coverage and off-stroke light at fixed size and mechanics', () => {
  const square = [{ x: -0.025, y: 0.025 }, { x: 0.025, y: 0.025 }, { x: 0.025, y: -0.025 }, { x: -0.025, y: -0.025 }];
  const eight = periodicPath(128, a => ({ x: 0.025 * Math.sin(a), y: 0.015 * Math.sin(2 * a) }));
  for (const path of [square, eight]) {
    const input = { path, config: DEFAULT_CONFIG, sampleRate: 16000 };
    const before = solveInverse({ ...input, search: 'quick' });
    const after = solveInverse(input);
    assert.equal(after.metrics.tolerance, before.metrics.tolerance);
    assert.ok(after.metrics.rmsDistance < 0.5 * before.metrics.rmsDistance);
    assert.ok(after.metrics.coverage > before.metrics.coverage && after.metrics.coverage > 0.80);
    assert.ok(after.metrics.offStroke < before.metrics.offStroke);
    assert.equal(after.metrics.missFraction, 0);
    assert.ok(after.pcm.every(u => Math.abs(u) <= 0.8));
  }
});

test('a generated two-tone path is recovered at fixed physical size and the exported WAV reproduces every scored hit', () => {
  const samples = 75;
  const known = Float32Array.from({ length: rate }, (_, i) =>
    0.035 * Math.cos(2 * Math.PI * i / samples) + 0.017 * Math.cos(4 * Math.PI * i / samples));
  const recorded = new Simulator(DEFAULT_CONFIG, rate).process(known);
  const path = Array.from({ length: samples }, (_, j) => {
    const i = known.length - samples + j;
    return { x: recorded.xy[i * 2] - neutral, y: recorded.xy[i * 2 + 1] };
  });
  const fit = solveInverse({ path, config: DEFAULT_CONFIG, sampleRate: rate, maxAmplitude: 0.12 });
  assert.equal(fit.model, 'simulator');
  assert.ok(fit.metrics.rmsDistance < 0.004);
  assert.ok(fit.metrics.coverage >= 0.98);
  assert.equal(fit.metrics.missFraction, 0);
  assert.ok(fit.closureError !== null && fit.closureError <= 0.005);
  assert.equal(fit.warmupSamples, fit.pcm.length - fit.periodSamples);
  const { pcm } = decodeFloatWav(encodeFloatWav(fit.pcm, rate));
  const replay = new Simulator(DEFAULT_CONFIG, rate).process(pcm);
  for (let i = 0; i < pcm.length; i++) {
    assert.ok(Math.abs(pcm[i]) <= 0.12);
    assert.equal(pcm[i], pcm[i % fit.periodSamples]);
  }
  for (let j = 0; j < fit.trace.length; j++) {
    const index = fit.warmupSamples + j;
    assert.equal(fit.trace[j].x, replay.xy[index * 2] - neutral);
    assert.equal(fit.trace[j].y, replay.xy[index * 2 + 1]);
  }
});

test('calibrated complex axes give an ellipse with the prescribed orientation and timing', () => {
  const response = [{ frequency: 100, xRe: 1, xIm: 0, yRe: 0, yIm: -0.07 / 0.15 }];
  const fit = solveInverse({ path: ellipse, response, config: DEFAULT_CONFIG, periodSamples: 120, sampleRate: rate,
    maxAmplitude: 0.2, preserveTiming: true });
  assert.equal(fit.model, 'measured');
  assert.equal(fit.closureError, null);
  assert.equal(fit.periodSamples, 120);
  assert.equal(fit.reference.length, 120);
  assert.ok(fit.trace[0].x > 0.149 && fit.trace[30].y > 0.0699);
  assert.ok(fit.metrics.rmsDistance < 0.00015);
  assert.equal(fit.metrics.coverage, 1);
  assert.equal(fit.metrics.offStroke, 0);
  assert.throws(() => solveInverse({ path: ellipse, config: DEFAULT_CONFIG, response, periodSamples: 110, sampleRate: rate }), /No calibrated response/);
});

test('a single measured horizontal axis cannot cover the vertical lobes of an ellipse', () => {
  const response = [{ frequency: 100, xRe: 1, xIm: 0, yRe: 0, yIm: 0 }];
  const result = solveInverse({ path: ellipse, config: DEFAULT_CONFIG, response, periodSamples: 120, sampleRate: rate });
  assert.ok(result.trace.every(p => p.y === 0));
  assert.ok(result.metrics.coverage < 0.3);
  assert.ok(result.metrics.rmsDistance > 0.02);
});

test('a low-damping loop gets a longer ring-up and the validated orbit closes', () => {
  const result = solveInverse({ path: ellipse, config: { ...DEFAULT_CONFIG, damping: 0.003 }, sampleRate: rate, periodSamples: 75 });
  assert.ok(result.warmupSamples > 0.65 * rate);
  assert.ok(result.closureError !== null && result.closureError <= 0.005);
});

test('small-signal phasor agrees with both observed axes of the discrete simulator', () => {
  const samples = 75, amplitude = 0.001, frequency = rate / samples;
  const pcm = Float32Array.from({ length: rate }, (_, i) => amplitude * Math.cos(2 * Math.PI * i / samples));
  const block = new Simulator(DEFAULT_CONFIG, rate).process(pcm);
  const h = modelResponse(DEFAULT_CONFIG, rate)(frequency);
  let xr = 0, xi = 0, yr = 0, yi = 0;
  for (let i = 0; i < samples; i++) {
    const j = pcm.length - samples + i;
    const x = block.xy[2 * j] - neutral, y = block.xy[2 * j + 1];
    const c = 2 * Math.cos(2 * Math.PI * i / samples) / (amplitude * samples);
    const s = -2 * Math.sin(2 * Math.PI * i / samples) / (amplitude * samples);
    xr += x * c; xi += x * s; yr += y * c; yi += y * s;
  }
  for (const [measured, expected] of [[xr, h.xRe], [xi, h.xIm], [yr, h.yRe], [yi, h.yIm]]) {
    assert.ok(Math.abs(measured - expected) < 0.0002 * Math.max(1, Math.abs(expected)));
  }
});

test('missing samples count against both distance and coverage without bridging the gap', () => {
  const a = { x: -0.1, y: 0 }, b = { x: 0.1, y: 0 }, missing = { x: NaN, y: NaN };
  const result = shapeMetrics([a, missing, b, missing], [a, { x: 0, y: 0 }, b], 0.2);
  assert.equal(result.missFraction, 0.5);
  assert.equal(result.offStroke, 0.5);
  assert.equal(result.coverage, 2 / 3);
  assert.ok(Number.isFinite(result.rmsDistance) && result.rmsDistance > 0.08);
});

test('invalid or immobile configurations explain the failure', () => {
  const input = { path: ellipse, config: DEFAULT_CONFIG, sampleRate: rate };
  assert.throws(() => solveInverse({ ...input, config: { ...DEFAULT_CONFIG, gain: 0 } }), /gain/);
  assert.throws(() => solveInverse({ ...input, config: { ...DEFAULT_CONFIG, damping: 0 } }), /damping/);
  assert.throws(() => solveInverse({ ...input, path: [{ x: 0, y: 0 }, { x: 0, y: 0 }] }), /visible extent/);
  assert.throws(() => solveInverse({ ...input, response: [{ frequency: 140, xRe: 0, xIm: 0, yRe: 0, yIm: 0 }] }), /response is zero/);
  assert.throws(() => solveInverse({ ...input, maxAmplitude: 1.01 }), /amplitude/);
});
