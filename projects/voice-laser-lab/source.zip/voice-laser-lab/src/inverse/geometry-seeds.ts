import type { FrequencyResponse, Point } from './solver';

const GRID_SIZE = 64;
const MAX_HARMONICS = 16;
const TAU = 2 * Math.PI;
interface Tone {
  re: number;
  im: number;
}
export interface GeometrySeed {
  period: number;
  target: Point[];
  tones: Tone[];
  /** Symmetric geometric error with a penalty for uncovered and off-stroke samples, in metres. */
  score: number;
}
interface WallBasis {
  x: Float64Array[];
  y: Float64Array[];
  columns: number;
}
interface Match extends Point {
  edge: number;
  fraction: number;
  nx: number;
  ny: number;
  distance2: number;
}
interface Fit {
  controls: Float64Array;
  points: Point[];
  score: number;
}
function harmonicTable(wave: (angle: number) => number) {
  return Array.from({ length: MAX_HARMONICS }, (_, k) =>
    Float64Array.from({ length: GRID_SIZE }, (_, j) => wave(TAU * (k + 1) * j / GRID_SIZE))
  );
}

const cosine = harmonicTable(Math.cos);
const sine = harmonicTable(Math.sin);

function nearest(p: Point, ring: Point[]): Match {
  let edge = 0;
  let fraction = 0;
  let x = ring[0].x, y = ring[0].y;
  let distance2 = Infinity;
  for (let i = 0; i < ring.length; i++) {
    const a = ring[i], b = ring[(i + 1) % ring.length];
    const dx = b.x - a.x, dy = b.y - a.y;
    const len2 = dx * dx + dy * dy;
    // Clamp the projection to the segment so corners also participate in the fit.
    const t = len2 ? Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / len2)) : 0;
    const qx = a.x + t * dx, qy = a.y + t * dy;
    const d = (p.x - qx) ** 2 + (p.y - qy) ** 2;
    if (d >= distance2) continue;
    distance2 = d;
    edge = i;
    fraction = t;
    x = qx;
    y = qy;
  }
  const a = ring[edge], b = ring[(edge + 1) % ring.length];
  const length = Math.hypot(b.x - a.x, b.y - a.y);
  const nx = length ? (b.y - a.y) / length : 0;
  const ny = length ? (a.x - b.x) / length : 0;
  return { edge, fraction, x, y, nx, ny, distance2 };
}

function wallBasis(h: FrequencyResponse[]): WallBasis {
  const columns = 2 * h.length;
  const rows = () => Array.from({ length: GRID_SIZE }, () => new Float64Array(columns));
  const x = rows(), y = rows();
  for (let k = 0; k < h.length; k++) {
    const { xRe, xIm, yRe, yIm } = h[k];
    for (let j = 0; j < GRID_SIZE; j++) {
      const c = cosine[k][j], s = sine[k][j];
      const re = 2 * k, im = re + 1;
      x[j][re] = xRe * c - xIm * s;
      x[j][im] = -xRe * s - xIm * c;
      y[j][re] = yRe * c - yIm * s;
      y[j][im] = -yRe * s - yIm * c;
    }
  }
  return { x, y, columns };
}

/** Each weighted observation constrains the normal strongly and leaves room to move along the stroke. */
class NormalEquations {
  readonly matrix: Float64Array[];
  readonly rhs: Float64Array;
  private readonly normal: Float64Array;
  private readonly tangent: Float64Array;
  constructor(columns: number) {
    this.matrix = Array.from({ length: columns }, () => new Float64Array(columns));
    this.rhs = new Float64Array(columns);
    this.normal = new Float64Array(columns);
    this.tangent = new Float64Array(columns);
  }

  add(x: Float64Array, y: Float64Array, point: Point, nx: number, ny: number, tangentWeight: number) {
    const normalTarget = nx * point.x + ny * point.y;
    const tangentTarget = (ny * point.x - nx * point.y) * tangentWeight;
    for (let i = 0; i < x.length; i++) {
      const a = nx * x[i] + ny * y[i], b = ny * x[i] - nx * y[i];
      this.normal[i] = a;
      this.tangent[i] = b;
      this.rhs[i] += a * normalTarget + b * tangentTarget;
      const row = this.matrix[i], bw = b * tangentWeight;
      for (let j = 0; j <= i; j++) row[j] += a * this.normal[j] + bw * this.tangent[j];
    }
  }

  solve(ridge: number) {
    // Factor the regularized normal matrix as LLᵀ. Reuse its lower triangle for L.
    const a = this.matrix, u = this.rhs;
    for (let i = 0; i < u.length; i++) {
      a[i][i] += ridge;
      for (let j = 0; j <= i; j++) {
        let sum = a[i][j];
        for (let k = 0; k < j; k++) sum -= a[i][k] * a[j][k];
        a[i][j] = i === j ? Math.sqrt(Math.max(1e-20, sum)) : sum / a[j][j];
      }
      for (let j = 0; j < i; j++) u[i] -= a[i][j] * u[j];
      u[i] /= a[i][i];
    }
    // The forward substitution above solved Lv = rhs. Solve Lᵀu = v in place.
    for (let i = u.length - 1; i >= 0; i--) {
      for (let j = i + 1; j < u.length; j++) u[i] -= a[j][i] * u[j];
      u[i] /= a[i][i];
    }
    return u;
  }
}

function score(points: Point[], path: Point[], size: number) {
  let sum = 0, outside = 0;
  const tolerance = 0.04 * size;
  for (let j = 0; j < GRID_SIZE; j++) {
    const a = nearest(path[j], points).distance2;
    const b = nearest(points[j], path).distance2;
    sum += a + b;
    outside += Number(a > tolerance ** 2) + Number(b > tolerance ** 2);
  }
  return Math.sqrt(sum / (2 * GRID_SIZE)) + 0.15 * tolerance * outside / GRID_SIZE;
}

function fit(
  path: Point[], basis: WallBasis, peak: number, size: number,
  ridge: number, tangentWeight: number, previous?: Fit,
): Fit {
  const equations = new NormalEquations(basis.columns);
  const x = new Float64Array(basis.columns), y = new Float64Array(basis.columns);
  for (let j = 0; j < GRID_SIZE; j++) {
    if (!previous) {
      const a = path[(j + GRID_SIZE - 1) % GRID_SIZE], b = path[(j + 1) % GRID_SIZE];
      const length = Math.hypot(b.x - a.x, b.y - a.y) || 1;
      equations.add(basis.x[j], basis.y[j], path[j], (b.y - a.y) / length, (a.x - b.x) / length, tangentWeight);
      continue;
    }
    const target = nearest(previous.points[j], path);
    equations.add(basis.x[j], basis.y[j], target, target.nx, target.ny, tangentWeight);
    // Reverse matches pull uncovered target segments back into the trace.
    const match = nearest(path[j], previous.points);
    const left = match.edge, right = (left + 1) % GRID_SIZE, w = match.fraction;
    for (let i = 0; i < basis.columns; i++) {
      x[i] = basis.x[left][i] + w * (basis.x[right][i] - basis.x[left][i]);
      y[i] = basis.y[left][i] + w * (basis.y[right][i] - basis.y[left][i]);
    }
    equations.add(x, y, path[j], match.nx, match.ny, tangentWeight);
  }
  // Scale the input-energy penalty with the number of observations in this fit.
  const controls = equations.solve(ridge * GRID_SIZE * (previous ? 2 : 1));
  let amplitude = 0;
  for (let j = 0; j < GRID_SIZE; j++) {
    let u = 0;
    for (let k = 0; k < controls.length / 2; k++) {
      u += controls[2 * k] * cosine[k][j] - controls[2 * k + 1] * sine[k][j];
    }
    amplitude = Math.max(amplitude, Math.abs(u));
  }
  if (amplitude > peak) {
    for (let i = 0; i < controls.length; i++) controls[i] *= peak / amplitude;
  }
  const points = basis.x.map((row, j) => {
    let x = 0, y = 0;
    for (let k = 0; k < controls.length; k++) {
      x += row[k] * controls[k];
      y += basis.y[j][k] * controls[k];
    }
    return { x, y };
  });
  return { controls, points, score: score(points, path, size) };
}

/** Scan periods for mono Fourier controls, then refine the two-way segment matches.
 * Input is a uniform arc-length sampling of an oriented ring. Tone k is Re(u[k] exp(i (k+1) wt)).
 * The caller verifies finalists with full optics and its final audio sample bounds.
 */
export function geometrySeeds(
  uniform: Point[], periods: number[], rate: number,
  response: (frequency: number) => FrequencyResponse, peak: number,
): GeometrySeed[] {
  const path = Array.from({ length: GRID_SIZE }, (_, j) => {
    const phase = uniform.length * j / GRID_SIZE, i = Math.floor(phase);
    const a = uniform[i], b = uniform[(i + 1) % uniform.length];
    const w = phase - i;
    return { x: a.x + w * (b.x - a.x), y: a.y + w * (b.y - a.y) };
  });
  const extent = (key: 'x' | 'y') => Math.max(...path.map(p => p[key])) - Math.min(...path.map(p => p[key]));
  const size = Math.max(extent('x'), extent('y'));
  // Express the ridge in wall metres per unit PCM so it follows target size and available drive.
  const penalty = Math.max(1e-14, (size / peak) ** 2);
  const pool: { period: number; basis: WallBasis; solution: Fit }[] = [];
  // Thin the search logarithmically so dense calibration sweeps have bounded cost.
  const ordered = [...new Set(periods)].sort((a, b) => a - b);
  let last = 0;
  for (const period of ordered) {
    if (period < last * 1.022) continue;
    last = period;
    const count = Math.min(MAX_HARMONICS, Math.floor((period - 1) / 2));
    const transfer = Array.from({ length: count }, (_, k) => response(rate * (k + 1) / period));
    if (!transfer.some(h => Math.hypot(h.xRe, h.xIm, h.yRe, h.yIm) > 1e-12)) continue;
    const basis = wallBasis(transfer);
    let best: Fit | undefined;
    for (const tangent of [0.002, 0.04, 0.16]) {
      for (const ridge of [0.008, 0.5]) {
        const attempt = fit(path, basis, peak, size, penalty * ridge, tangent);
        if (!best || attempt.score < best.score) best = attempt;
      }
    }
    pool.push({ period, basis, solution: best! });
  }
  pool.sort((a, b) => a.solution.score - b.solution.score);
  const finalists: typeof pool = [];
  for (const row of pool) {
    if (finalists.some(other => Math.abs(other.period / row.period - 1) < 0.023)) continue;
    finalists.push(row);
    if (finalists.length === 18) break;
  }
  for (const row of finalists) {
    for (let iteration = 0; iteration < 28; iteration++) {
      const updated = fit(path, row.basis, peak, size, penalty * 0.065, 0.15, row.solution);
      if (updated.score >= row.solution.score - size * 1e-6) break;
      row.solution = updated;
    }
  }
  finalists.sort((a, b) => a.solution.score - b.solution.score);
  return finalists.slice(0, 3).map(({ period, solution }) => ({
    period,
    target: uniform,
    score: solution.score,
    tones: Array.from({ length: solution.controls.length / 2 }, (_, k) => ({
      re: solution.controls[2 * k],
      im: solution.controls[2 * k + 1],
    })),
  }));
}
