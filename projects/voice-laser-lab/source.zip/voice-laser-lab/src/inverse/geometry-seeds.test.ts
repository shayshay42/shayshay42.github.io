import assert from 'node:assert/strict';
import test from 'node:test';
import { DEFAULT_CONFIG, Simulator, neutralWallX } from '../physics/engine';
import { modelResponse, shapeMetrics } from './solver';
import { geometrySeeds } from './geometry-seeds';

test('normal-weighted Fourier controls cover the sides of a square on the fixed apparatus', () => {
  const corners = [
    { x: -0.025, y: 0.025 }, { x: 0.025, y: 0.025 },
    { x: 0.025, y: -0.025 }, { x: -0.025, y: -0.025 },
  ];
  const target = Array.from({ length: 96 }, (_, i) => {
    const side = Math.floor(i / 24), w = i % 24 / 24;
    const a = corners[side], b = corners[(side + 1) % 4];
    return { x: a.x + w * (b.x - a.x), y: a.y + w * (b.y - a.y) };
  });
  const rate = 16000;
  const seeds = geometrySeeds(target, [388, 398, 412], rate, modelResponse(DEFAULT_CONFIG, rate), 0.8);
  assert.ok(seeds.length > 0 && seeds.length <= 3);
  const best = seeds[0];
  const cycle = Float32Array.from({ length: best.period }, (_, j) => best.tones.reduce((u, t, k) => {
    const angle = 2 * Math.PI * (k + 1) * j / best.period;
    return u + t.re * Math.cos(angle) - t.im * Math.sin(angle);
  }, 0));
  assert.ok(cycle.every(sample => Math.abs(sample) < 0.8));
  const sim = new Simulator(DEFAULT_CONFIG, rate);
  for (let j = 0; j < Math.ceil(0.75 * rate / best.period); j++) sim.process(cycle);
  const { hits, xy } = sim.process(cycle);
  assert.ok(hits.every(Boolean));
  const trace = Array.from(hits, (_, i) => ({
    x: xy[2 * i] - neutralWallX(DEFAULT_CONFIG.wallDistance),
    y: xy[2 * i + 1],
  }));
  const m = shapeMetrics(trace, target, 0.05);
  assert.ok(m.rmsDistance < 0.0035 && m.coverage > 0.7);
});
