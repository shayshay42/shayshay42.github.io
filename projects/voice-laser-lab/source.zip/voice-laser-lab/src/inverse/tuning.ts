import type { SimulationConfig } from '../physics/engine';
import { solveInverse, type InverseOptions, type InverseResult } from './solver';

interface Fit {
  result: InverseResult;
  config: SimulationConfig;
}

function screenScore(result: InverseResult): number {
  const m = result.metrics;
  return m.rmsDistance + 0.5 * m.tolerance * (1 - m.coverage + m.offStroke);
}

function closeEnough(result: InverseResult): boolean {
  const m = result.metrics;
  return m.coverage === 1 && m.offStroke === 0 && m.missFraction === 0 && result.outlineError <= 0.25 * m.tolerance;
}

function tryCandidate(options: InverseOptions): InverseResult | undefined {
  try {
    return solveInverse(options);
  } catch (error) {
    // Weakly damped candidates can miss the solver's finite settling horizon.
    if (!(error instanceof Error) || !error.message.includes('did not settle')) throw error;
  }
}

/** Opt-in search over the lab's membrane settings. The current configuration is
 * always a finalist. Measured response tables belong to a particular apparatus.
 */
export function solveWithTuning(options: InverseOptions): Fit {
  const starting = options.config;
  const baseline = { result: solveInverse(options), config: { ...starting } };
  if (options.response || closeEnough(baseline.result)) return baseline;

  const rate = options.sampleRate ?? 48000;
  // Fixed periods keep their exact physical frequency in both rounds.
  const screenRate = options.periodSamples === undefined ? Math.min(rate, 12000) : rate;
  const screened: { config: SimulationConfig; score: number }[] = [];
  const visited = new Set<string>();
  function screen(tension: number, asymmetry: number, damping: number) {
    const config = { ...starting, tension, asymmetry, damping };
    const key = [tension, asymmetry, damping].join(',');
    if (visited.has(key)) return;
    visited.add(key);
    const result = tryCandidate({ ...options, config, sampleRate: screenRate, search: 'quick' });
    if (result) screened.push({ config, score: screenScore(result) });
  }

  const tension = Math.max(0.25, Math.min(4, Math.round(starting.tension * 20) / 20));
  const startingSplit = Math.max(0, Math.min(0.5, Math.round(starting.asymmetry * 100) / 100));
  const startingDamping = Math.max(0.005, Math.min(0.15, Math.round(starting.damping * 200) / 200));
  screen(tension, startingSplit, startingDamping);
  for (const asymmetry of [0.12, 0.30, 0.50]) {
    for (const damping of [0.005, 0.025, 0.075, 0.15]) screen(tension, asymmetry, damping);
  }
  screened.sort((a, b) => a.score - b.score);

  // Tension shifts the resonance frequencies together. Check its range on the
  // two most promising modal splits and damping ratios.
  for (const { config } of screened.slice(0, 2)) {
    for (const value of [0.25, 0.65, 1.35, 2.5, 4]) screen(value, config.asymmetry, config.damping);
  }

  screened.sort((a, b) => a.score - b.score);
  const leader = screened[0]?.config;
  if (leader) {
    // Probe halfway between coarse split values and half an octave in damping.
    for (const delta of [-0.10, 0.10]) {
      const split = Math.max(0, Math.min(0.5, Math.round((leader.asymmetry + delta) * 100) / 100));
      for (const factor of [Math.SQRT1_2, Math.SQRT2]) {
        const rawStep = Math.round(leader.damping * (factor - 1) * 200);
        const step = rawStep || Math.sign(factor - 1);
        const damping = Math.max(1, Math.min(30, Math.round(leader.damping * 200) + step)) / 200;
        screen(leader.tension, split, damping);
      }
    }
  }
  screened.sort((a, b) => a.score - b.score);
  let best = baseline;
  for (const { config } of screened.slice(0, 2)) {
    if (config.tension === starting.tension && config.damping === starting.damping && config.asymmetry === starting.asymmetry) continue;
    const result = tryCandidate({ ...options, config });
    if (result && result.outlineError < best.result.outlineError) best = { result, config };
  }
  return best;
}
