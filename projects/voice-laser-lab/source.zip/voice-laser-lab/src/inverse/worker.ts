import { solveInverse } from './solver';
import { solveWithTuning } from './tuning';
import type { SimulationConfig } from '../physics/engine';

interface InverseRequest {
  path: { x: number; y: number }[];
  config: SimulationConfig;
  tune?: boolean;
}

self.onmessage = ({ data }: MessageEvent<InverseRequest>) => {
  try {
    const { result, config } = data.tune ? solveWithTuning(data) : { result: solveInverse(data), config: data.config };
    self.postMessage({
      type: 'done',
      pcm: result.pcm,
      sampleRate: result.sampleRate,
      trace: result.trace,
      coverage: result.metrics.coverage,
      offTarget: result.metrics.offStroke,
      tolerance: result.metrics.tolerance,
      rmsDistance: result.metrics.rmsDistance,
      config,
      periodHz: result.frequency,
    }, { transfer: [result.pcm.buffer] });
  } catch (error) {
    self.postMessage({ type: 'error', message: error instanceof Error ? error.message : 'Could not fit the drawing.' });
  }
};
