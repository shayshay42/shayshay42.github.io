"use client";

import { useCallback, useEffect, useId, useMemo, useRef, useState } from "react";
import type { KeyboardEvent, PointerEvent } from "react";
import { assetPath } from "../asset-path";
import type { SimulationConfig } from "../physics/engine";
import { encodeFloatWav } from "../session/wav";
import { extractContours } from "./contours";
import "./inverse.css";

type Point = { x: number; y: number };
type OutlineImage = { preview: string; width: number; height: number; contours: Point[][] };
type Fit = { trace: Point[]; coverage: number; offTarget: number; periodHz: number; tolerance: number; rmsDistance: number; config: SimulationConfig };
type Solution = Fit & { url: string; file: File };
type WorkerReply =
  | (Fit & { type: "done"; pcm: Float32Array; sampleRate: number })
  | { type: "error"; message: string };

const TARGET_SIZE = 0.05;
const PAD_HEIGHT_MM = 70;
const PAD_WIDTH_MM = PAD_HEIGHT_MM * 4 / 3;

function normalizeStroke(points: Point[]): Point[] {
  if (points.length < 2) return [];
  let left = Infinity, right = -Infinity, top = Infinity, bottom = -Infinity;
  for (const { x, y } of points) {
    left = Math.min(left, x);
    right = Math.max(right, x);
    top = Math.min(top, y);
    bottom = Math.max(bottom, y);
  }
  const span = Math.max(right - left, bottom - top);
  if (!span) return [];
  const scale = TARGET_SIZE / span;
  return points.map(({ x, y }) => ({
    x: (x - (left + right) / 2) * scale,
    y: ((top + bottom) / 2 - y) * scale,
  }));
}

function loopStroke(points: Point[], join: boolean): Point[] {
  if (points.length < 2) return [];
  const first = points[0], last = points[points.length - 1];
  const gap = Math.hypot(first.x - last.x, first.y - last.y);
  if (!gap) return points;
  if (join || gap < TARGET_SIZE * 0.025) return [...points, first];
  return points.concat(points.slice(0, -1).reverse());
}

function svgPath(points: Point[], metric = false): string {
  let path = "", move = true;
  for (const point of points) {
    if (!Number.isFinite(point.x) || !Number.isFinite(point.y)) { move = true; continue; }
    const x = metric ? point.x * 1000 : point.x;
    const y = metric ? -point.y * 1000 : point.y;
    path += (move ? "M" : "L") + x.toFixed(2) + " " + y.toFixed(2);
    move = false;
  }
  return path;
}

async function readImage(file: File): Promise<OutlineImage> {
  const url = URL.createObjectURL(file);
  const image = new Image();
  try {
    image.src = url;
    await image.decode();
    const scale = 448 / Math.max(image.naturalWidth, image.naturalHeight);
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(image.naturalWidth * Math.min(scale, 1)));
    canvas.height = Math.max(1, Math.round(image.naturalHeight * Math.min(scale, 1)));
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Your browser could not read the image.");
    ctx.fillStyle = "white";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
    const contours = extractContours(ctx.getImageData(0, 0, canvas.width, canvas.height));
    if (!contours.length) throw new Error("No outline found. Try an image with a clearer edge.");
    return { preview: canvas.toDataURL(), width: canvas.width, height: canvas.height, contours };
  } finally {
    URL.revokeObjectURL(url);
  }
}

function settingsKey(config: SimulationConfig) {
  return [config.gain, config.tension, config.damping, config.asymmetry, config.wallDistance].join('/');
}

export function InverseLab({ config, onPlayInLab }: { config: SimulationConfig; onPlayInLab?: (file: File, settings: SimulationConfig) => void }) {
  const [stroke, setStroke] = useState<Point[]>([]);
  const [draft, setDraft] = useState<Point[]>([]);
  const [join, setJoin] = useState(false);
  const [tune, setTune] = useState(false);
  const [image, setImage] = useState<OutlineImage | null>(null);
  const [outline, setOutline] = useState(0);
  const [reading, setReading] = useState(false);
  const [busy, setBusy] = useState(false);
  const [solution, setSolution] = useState<Solution | null>(null);
  const [error, setError] = useState("");
  const [keyboardPoint, setKeyboardPoint] = useState<Point | null>(null);
  const worker = useRef<Worker | null>(null);
  const audio = useRef<HTMLAudioElement>(null);
  const readId = useRef(0);
  const activePointer = useRef<number | null>(null);
  const draftPoints = useRef<Point[]>([]);
  const grid = useId();
  const help = useId();
  const configKey = settingsKey(config);
  const [previousConfig, setPreviousConfig] = useState(configKey);
  if (previousConfig !== configKey) {
    setPreviousConfig(configKey);
    setBusy(false);
    if (solution && settingsKey(solution.config) !== configKey) setSolution(null);
    setError("");
  }
  useEffect(() => {
    if (window.location.hash === '#draw-to-sound') document.getElementById('draw-to-sound')?.scrollIntoView();
  }, []);

  const stopSolve = useCallback(() => {
    worker.current?.terminate();
    worker.current = null;
    audio.current?.pause();
    setBusy(false);
    setSolution(null);
    setError("");
  }, []);

  useEffect(() => () => { worker.current?.terminate(); worker.current = null; }, [configKey]);
  useEffect(() => () => { readId.current++; }, []);
  useEffect(() => () => { if (solution) URL.revokeObjectURL(solution.url); }, [solution]);

  const target = useMemo(() => loopStroke(stroke, join || image !== null), [stroke, join, image]);
  const targetPath = useMemo(() => svgPath(target, true), [target]);
  const actualPath = useMemo(() => solution ? svgPath(solution.trace, true) : "", [solution]);
  const graphHeight = useMemo(() => {
    let height = PAD_HEIGHT_MM;
    for (const { x, y } of solution?.trace ?? []) {
      if (Number.isFinite(x) && Number.isFinite(y)) height = Math.max(height, 2200 * Math.abs(y), 1650 * Math.abs(x));
    }
    return height;
  }, [solution]);
  const graphWidth = graphHeight * 4 / 3;

  function reset() {
    stopSolve();
    readId.current++;
    activePointer.current = null;
    draftPoints.current = [];
    setDraft([]);
    setKeyboardPoint(null);
    setStroke([]);
    setReading(false);
    setImage(null);
  }

  function addPoint(point: Point) {
    const points = draftPoints.current;
    const last = points[points.length - 1];
    if (last && Math.hypot(point.x - last.x, point.y - last.y) < 0.20) return;
    points.push(point);
    setDraft(points.slice());
  }

  function finishStroke() {
    setStroke(normalizeStroke(draftPoints.current));
    activePointer.current = null;
    draftPoints.current = [];
    setDraft([]);
    setKeyboardPoint(null);
  }

  function pointerPoint(event: PointerEvent<SVGSVGElement>) {
    const box = event.currentTarget.getBoundingClientRect();
    return {
      x: (Math.max(0, Math.min(1, (event.clientX - box.left) / box.width)) - 0.5) * PAD_WIDTH_MM,
      y: (Math.max(0, Math.min(1, (event.clientY - box.top) / box.height)) - 0.5) * PAD_HEIGHT_MM,
    };
  }

  function startPointer(event: PointerEvent<SVGSVGElement>) {
    if (!event.isPrimary || event.button !== 0) return;
    reset();
    activePointer.current = event.pointerId;
    event.currentTarget.setPointerCapture(event.pointerId);
    addPoint(pointerPoint(event));
  }

  function drawWithKeys(event: KeyboardEvent<SVGSVGElement>) {
    if (event.key === "Escape" && keyboardPoint) { event.preventDefault(); reset(); return; }
    if (event.key === "Enter" && keyboardPoint) { event.preventDefault(); finishStroke(); return; }
    if (event.key === " " && !keyboardPoint) {
      event.preventDefault();
      reset();
      const center = { x: 0, y: 0 };
      setKeyboardPoint(center);
      addPoint(center);
      return;
    }
    if (!keyboardPoint) return;
    const step = event.shiftKey ? 5 : 1;
    const delta: Record<string, Point> = {
      ArrowLeft: { x: -step, y: 0 }, ArrowRight: { x: step, y: 0 },
      ArrowUp: { x: 0, y: -step }, ArrowDown: { x: 0, y: step },
    };
    if (!Object.hasOwn(delta, event.key)) return;
    event.preventDefault();
    const { x, y } = delta[event.key];
    const point = {
      x: Math.max(-PAD_WIDTH_MM / 2, Math.min(PAD_WIDTH_MM / 2, keyboardPoint.x + x)),
      y: Math.max(-PAD_HEIGHT_MM / 2, Math.min(PAD_HEIGHT_MM / 2, keyboardPoint.y + y)),
    };
    setKeyboardPoint(point);
    addPoint(point);
  }

  async function importImage(file: File) {
    reset();
    const id = readId.current;
    setReading(true);
    try {
      const imported = await readImage(file);
      if (readId.current !== id) return;
      setImage(imported);
      setOutline(0);
      setStroke(normalizeStroke(imported.contours[0]));
    } catch (failure) {
      if (readId.current !== id) return;
      setError(failure instanceof Error && failure.name === "Error" ? failure.message : "This image could not be opened. Try a PNG or JPEG.");
    } finally {
      if (readId.current === id) setReading(false);
    }
  }

  function solve() {
    if (!target.length) return;
    stopSolve();
    try {
      const next = new Worker(assetPath("generated/inverse-worker.js?fit=2"), { type: "module" });
      worker.current = next;
      setBusy(true);
      const finish = () => { next.terminate(); worker.current = null; setBusy(false); };
      next.onerror = () => {
        if (worker.current !== next) return;
        finish();
        setError("The solver could not finish. Try again.");
      };
      next.onmessage = ({ data }: MessageEvent<WorkerReply>) => {
        if (worker.current !== next) return;
        finish();
        if (data.type === "error") { setError(data.message); return; }
        try {
          const wav = Uint8Array.from(encodeFloatWav(data.pcm, data.sampleRate));
          const file = new File([wav.buffer], "voice-laser-drawing.wav", { type: "audio/wav" });
          const url = URL.createObjectURL(file);
          setSolution({ trace: data.trace, coverage: data.coverage, offTarget: data.offTarget, periodHz: data.periodHz,
            tolerance: data.tolerance, rmsDistance: data.rmsDistance, config: data.config, url, file });
        } catch {
          setError("The solver returned audio that could not be encoded.");
        }
      };
      next.postMessage({ path: target, config, tune });
    } catch {
      stopSolve();
      setError("The solver could not start. Try reloading this page.");
    }
  }

  function loadExample(name: string) {
    reset();
    const example = name === "square" ? [{ x: -1, y: -1 }, { x: 1, y: -1 }, { x: 1, y: 1 }, { x: -1, y: 1 }]
      : Array.from({ length: 128 }, (_, i) => {
        const theta = i * Math.PI * 2 / 128;
        return name === "eight" ? { x: Math.sin(theta), y: -0.6 * Math.sin(2 * theta) }
          : { x: Math.cos(theta), y: -0.15 * Math.sin(theta) };
      });
    setStroke(normalizeStroke([...example, example[0]]));
  }

  function saveTarget() {
    const url = URL.createObjectURL(new Blob([JSON.stringify(target)], { type: "application/json" }));
    const link = document.createElement("a");
    link.href = url;
    link.download = "target.json";
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 10_000);
  }

  return <section className="inverse-lab" aria-label="Draw to sound">
    <div className="inverse-heading">
      <h2>Draw to sound</h2>
      <p>Draw one stroke or choose an outline from an image. Find a sound that brings the simulated laser close to it.</p>
    </div>
    <div className="inverse-workbench">
      <div>
        <div className="inverse-pad-wrap">
          <div className="inverse-legend"><span><i />Target</span><span><i className="inverse-laser-key" />Final simulated loop</span><span className="inverse-grid-scale">1 cm grid</span></div>
          <svg className="inverse-pad" viewBox={[-graphWidth / 2, -graphHeight / 2, graphWidth, graphHeight].join(" ")}
            role="application" tabIndex={0} aria-label="Drawing pad" aria-describedby={help}
            onPointerDown={startPointer} onPointerMove={e => { if (activePointer.current === e.pointerId) addPoint(pointerPoint(e)); }}
            onPointerUp={e => { if (activePointer.current === e.pointerId) { addPoint(pointerPoint(e)); finishStroke(); } }}
            onPointerCancel={e => { if (activePointer.current === e.pointerId) reset(); }}
            onKeyDown={drawWithKeys}>
            <defs><pattern id={grid} width="10" height="10" patternUnits="userSpaceOnUse">
              <path d="M10 0H0V10" fill="none" stroke="#e2e4e2" strokeWidth="1" vectorEffect="non-scaling-stroke" />
            </pattern></defs>
            <rect x={-graphWidth / 2} y={-graphHeight / 2} width={graphWidth} height={graphHeight} fill={`url(#${grid})`} />
            <path className="inverse-target" d={draft.length ? svgPath(draft) : targetPath} />
            <path className="inverse-trace" d={actualPath} />
            {keyboardPoint && <circle cx={keyboardPoint.x} cy={keyboardPoint.y} r="0.7" fill="currentColor" />}
          </svg>
          {!target.length && !draft.length && <span className="inverse-pad-hint">Draw here</span>}
        </div>
        <p className="inverse-hint" id={help}>Drag to draw. With the pad focused, press Space, draw with the arrow keys, then press Enter.</p>
      </div>
      <div className="inverse-controls">
        <div className="inverse-inputs">
          <label className="inverse-file">Upload image<input type="file" accept="image/*" onChange={e => {
            const file = e.currentTarget.files?.[0];
            e.currentTarget.value = "";
            if (file) void importImage(file);
          }} /></label>
          <select aria-label="Example drawing" value="" onChange={event => loadExample(event.target.value)}>
            <option value="" disabled>Try an example…</option>
            <option value="ellipse">Ellipse</option><option value="eight">Figure eight</option><option value="square">Square</option>
          </select>
        </div>
        {image && <div className="inverse-source">
          <svg viewBox={`0 0 ${image.width} ${image.height}`} role="img" aria-label={`Source image with outline ${outline + 1} highlighted`}>
            <image href={image.preview} width={image.width} height={image.height}/>
            <path d={svgPath(image.contours[outline]) + "Z"} fill="none" stroke="#bc2f22" strokeWidth="2" vectorEffect="non-scaling-stroke" />
          </svg>
          <label>Image outline<select value={outline} onChange={e => {
            stopSolve();
            const index = Number(e.target.value);
            setOutline(index);
            setStroke(normalizeStroke(image.contours[index]));
          }}>{image.contours.map((_, i) => <option key={i} value={i}>Outline {i + 1} of {image.contours.length}</option>)}</select></label>
        </div>}
        {!image && <label className="inverse-routing">Open strokes<select value={join ? "join" : "retrace"} onChange={e => { stopSolve(); setJoin(e.target.value === "join"); }}>
          <option value="retrace">Retrace to the start</option><option value="join">Join the endpoints</option>
        </select></label>}
        <p className="inverse-caption">The target is centered on the resting spot. Its longest side spans 5 cm.</p>
        {target.length > 0 && <button type="button" className="inverse-link inverse-save" onClick={saveTarget}>Save target coordinates</button>}
        <label className="inverse-tuning"><input type="checkbox" checked={tune} onChange={event => { stopSolve(); setTune(event.target.checked); }} />
          Also fit the simulated membrane</label>
        <div className="inverse-run">
          <button className="primary-button" type="button" onClick={solve} disabled={!target.length || reading || busy}>Find sound</button>
          {busy ? <button type="button" className="inverse-link" onClick={stopSolve}>Cancel</button>
            : <button type="button" className="inverse-link" onClick={reset} disabled={!stroke.length && !draft.length && !reading && !error}>Clear</button>}
        </div>
        <div role="status" className="inverse-status">
          {reading && "Finding outlines…"}{busy && "Finding a waveform…"}{solution && "Waveform ready."}
        </div>
        {error && <p className="error-message" role="alert">{error}</p>}
        {solution && <div className="inverse-output">
          <p className="inverse-caption">Fit after startup, within {(solution.tolerance * 1000).toFixed(1)} mm of the target.</p>
          <dl><div><dt>Target covered</dt><dd>{Math.round(solution.coverage * 100)}%</dd></div>
            <div><dt>Off-target trace</dt><dd>{Math.round(solution.offTarget * 100)}%</dd></div>
            <div><dt>RMS shape error</dt><dd>{(solution.rmsDistance * 1000).toFixed(2)} mm</dd></div>
            <div><dt>Loop frequency</dt><dd>{solution.periodHz.toFixed(1)} Hz</dd></div></dl>
          {tune && <p className="inverse-caption">This fit uses {solution.config.tension.toFixed(2)}× tension, {solution.config.damping.toFixed(3)} damping and {Math.round(solution.config.asymmetry * 100)}% asymmetry.</p>}
          <audio ref={audio} controls preload="metadata" src={solution.url} aria-label="Generated sound" />
          {onPlayInLab && <button type="button" className="inverse-link" onClick={() => {
            audio.current?.pause();
            onPlayInLab(solution.file, solution.config);
          }}>Run in simulator</button>}
          <a href={solution.url} download={solution.file.name}>Download mono WAV</a>
        </div>}
      </div>
    </div>
  </section>;
}
