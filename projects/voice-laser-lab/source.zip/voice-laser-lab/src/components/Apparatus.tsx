"use client";

import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
import { LineSegments2 } from "three/addons/lines/LineSegments2.js";
import { LineSegmentsGeometry } from "three/addons/lines/LineSegmentsGeometry.js";
import { LineMaterial } from "three/addons/lines/LineMaterial.js";
import { TOY, neutralWallX } from "../physics/engine";
import type { VisualBus } from "../visuals/bus";
import { createLaserDot, createTrail } from "../visuals/trail";
import { createToy } from "../visuals/toy";
import { createLabRoom } from "../visuals/room";
import { createTripod } from "../visuals/scene-props";
import { loadHumanModel } from "../visuals/human-model";
import { createProjectionGrid } from "../visuals/projection-grid";
import { createSoundCue } from "../visuals/sound-cue";

export type SceneView = "room" | "toy" | "voice" | "poster";

// Enlarge the complete optical geometry together. Solver coordinates stay in metres.
const APPARATUS_DISPLAY_SCALE = 1.6;

function disposeMeshes(root: THREE.Object3D) {
  const geometries = new Set<THREE.BufferGeometry>();
  const materials = new Set<THREE.Material>();
  const skeletons = new Set<THREE.Skeleton>();
  root.traverse((object) => {
    const mesh = object as THREE.SkinnedMesh;
    if (mesh.geometry) geometries.add(mesh.geometry);
    if (mesh.material) (Array.isArray(mesh.material) ? mesh.material : [mesh.material]).forEach(material => materials.add(material));
    if (mesh.isSkinnedMesh) skeletons.add(mesh.skeleton);
  });
  geometries.forEach(geometry => geometry.dispose());
  materials.forEach(material => material.dispose());
  skeletons.forEach(skeleton => skeleton.dispose());
}

export function Apparatus({ bus, resetToken, sceneView = "room" }: {
  bus: VisualBus; resetToken: number; sceneView?: SceneView;
}) {
  const host = useRef<HTMLDivElement>(null);
  const resetCamera = useRef<(() => void) | null>(null);
  const selectView = useRef<((view: SceneView) => void) | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    const element = host.current;
    if (!element) return;
    setError("");
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "high-performance" });
    } catch {
      setError("The model needs WebGL. Enable hardware acceleration and reload.");
      return;
    }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(0xffffff, 1);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.03;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFShadowMap;
    renderer.domElement.setAttribute("aria-label", "Orbitable model of the laser toy on a simple tripod, a human silhouette, and a room with a physics poster and projection wall");
    renderer.domElement.setAttribute("role", "img");
    renderer.domElement.setAttribute("aria-busy", "true");
    renderer.domElement.style.cssText = "display:block;width:100%;height:100%;touch-action:none";
    element.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const studio = new RoomEnvironment();
    const pmrem = new THREE.PMREMGenerator(renderer);
    const environment = pmrem.fromScene(studio, 0.035);
    scene.environment = environment.texture;
    scene.environmentIntensity = 0.6;
    studio.dispose();
    pmrem.dispose();
    scene.add(new THREE.HemisphereLight(0xffffff, 0xc8bfb1, 1));
    const key = new THREE.DirectionalLight(0xfff5e8, 2.1);
    key.position.set(1.6, 3.2, -0.5);
    key.castShadow = true;
    key.shadow.mapSize.set(2048, 2048);
    key.shadow.camera.left = key.shadow.camera.bottom = -3.6;
    key.shadow.camera.right = key.shadow.camera.top = 3.6;
    key.shadow.camera.near = 0.1;
    key.shadow.camera.far = 10;
    key.shadow.bias = -0.00012;
    key.shadow.normalBias = 0.002;
    key.shadow.radius = 3;
    scene.add(key);
    const fill = new THREE.DirectionalLight(0xe8f0ff, 0.65);
    fill.position.set(-0.7, 1.7, -2.2);
    scene.add(fill);

    const optical = new THREE.Group();
    optical.name = "enlarged-optical-display";
    optical.scale.setScalar(APPARATUS_DISPLAY_SCALE);
    const toy = createToy();
    optical.add(toy.group);
    const room = createLabRoom(bus.config.wallDistance * APPARATUS_DISPLAY_SCALE, APPARATUS_DISPLAY_SCALE);
    const tripod = createTripod();
    const mannequin = new THREE.Group();
    mannequin.name = "human-model-slot";
    scene.add(optical, room.group, tripod, mannequin);
    const soundCue = createSoundCue();
    scene.add(soundCue.group);
    let mouthPosition: [number, number, number] = [0, 0, -0.44];
    const wallGrid = createProjectionGrid({
      minX: room.bounds.min.x, maxX: room.bounds.max.x,
      minY: room.bounds.min.y, maxY: room.bounds.max.y,
      originX: neutralWallX(bus.config.wallDistance * APPARATUS_DISPLAY_SCALE),
      spacingScale: APPARATUS_DISPLAY_SCALE,
    });
    wallGrid.group.name = "projection-wall-grid";
    wallGrid.group.position.z = bus.config.wallDistance * APPARATUS_DISPLAY_SCALE - 0.002;
    scene.add(wallGrid.group);
    const textures = [...toy.textures, ...room.textures];
    textures.forEach((texture) => { texture.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy()); });
    const trail = createTrail(bus);
    optical.add(trail.line);
    const dot = createLaserDot();
    dot.mesh.scale.setScalar(0.003);
    (dot.mesh.material as THREE.ShaderMaterial).depthTest = true;
    optical.add(dot.mesh);

    // Reflection uses the same world coordinates and finite wall as the solver.
    const rayGeometry = new LineSegmentsGeometry();
    rayGeometry.setPositions(new Float32Array(12));
    const rayBuffer = (rayGeometry.getAttribute("instanceStart") as THREE.InterleavedBufferAttribute).data;
    const rayPositions = rayBuffer.array as Float32Array;
    const rayMaterial = new LineMaterial({ color: 0xb3473d, linewidth: 1.8, worldUnits: false, transparent: true, opacity: 0.9, toneMapped: false });
    const rays = new LineSegments2(rayGeometry, rayMaterial);
    rays.frustumCulled = false;
    optical.add(rays);

    const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.01, 40);
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = !window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    controls.dampingFactor = 0.1;
    controls.minZoom = 0.25;
    controls.maxZoom = 12;
    controls.minPolarAngle = 0.05;
    controls.maxPolarAngle = Math.PI * 0.53;
    let currentView: SceneView = sceneView;
    let width = 1, height = 1;
    let halfHeight = 1.7;
    let previousDistance = bus.config.wallDistance;
    let previousFrame: typeof bus.frame = null;
    let frameRequest = 0;
    let visible = true;
    let disposed = false;
    const cameraOffset = new THREE.Vector3();
    const gridOrigin = new THREE.Vector3();
    const gridStepX = new THREE.Vector3();
    const gridStepY = new THREE.Vector3();

    function wake() {
      if (!disposed && visible && !document.hidden && !frameRequest) frameRequest = requestAnimationFrame(draw);
    }
    void room.ready.then(wake).catch(() => {
      if (!disposed) setError("The physics poster could not load. Reload the page.");
    });
    const humanReady = loadHumanModel().then((model) => {
      if (disposed) { disposeMeshes(model); return; }
      mannequin.add(model);
      const mouth = model.userData.mouthPosition;
      if (Array.isArray(mouth) && mouth.length === 3 && mouth.every(Number.isFinite)) {
        mouthPosition = [mouth[0], mouth[1], mouth[2]];
      }
      wake();
    }).catch(() => {
      if (!disposed) setError("The human model could not load. Reload the page.");
    });
    void Promise.allSettled([room.ready, humanReady]).then(() => {
      if (disposed) return;
      renderer.domElement.setAttribute("aria-busy", "false");
      wake();
    });
    function updateFrustum() {
      const aspect = width / height;
      camera.left = -halfHeight * aspect;
      camera.right = halfHeight * aspect;
      camera.top = halfHeight;
      camera.bottom = -halfHeight;
      camera.updateProjectionMatrix();
    }
    function frameBounds(bounds: THREE.Box3, direction: THREE.Vector3, margin = 1.12) {
      const center = bounds.getCenter(new THREE.Vector3());
      controls.target.copy(center);
      camera.position.copy(center).add(direction.normalize().multiplyScalar(8));
      camera.lookAt(center);
      camera.updateMatrixWorld(true);
      let extentX = 0, extentY = 0;
      for (const x of [bounds.min.x, bounds.max.x]) for (const y of [bounds.min.y, bounds.max.y]) for (const z of [bounds.min.z, bounds.max.z]) {
        const projected = new THREE.Vector3(x, y, z).applyMatrix4(camera.matrixWorldInverse);
        extentX = Math.max(extentX, Math.abs(projected.x));
        extentY = Math.max(extentY, Math.abs(projected.y));
      }
      halfHeight = Math.max(extentY, extentX / (width / height)) * margin;
    }
    function applyView(view: SceneView, preserveDirection = false) {
      currentView = view;
      mannequin.visible = view !== "poster";
      const distance = bus.config.wallDistance;
      cameraOffset.copy(camera.position).sub(controls.target);
      camera.zoom = 1;
      if (view === "room") {
        // Frame the experiment and poster closely. Bare room edges may extend out of view.
        const focus = room.bounds.clone();
        focus.max.x = Math.min(focus.max.x, 0.8);
        focus.min.z = Math.max(focus.min.z, -1.4);
        focus.max.y = Math.min(focus.max.y, 1.3);
        frameBounds(focus, preserveDirection ? cameraOffset : new THREE.Vector3(4.5, 2.6, -5.5), 0.99);
      } else if (view === "toy") {
        controls.target.set(0.025, 0, 0.015).multiplyScalar(APPARATUS_DISPLAY_SCALE);
        camera.position.copy(controls.target).add(new THREE.Vector3(0.8, 0.6531972647, 0.8).multiplyScalar(APPARATUS_DISPLAY_SCALE));
        halfHeight = Math.max(0.28, 0.32 / (width / height)) * APPARATUS_DISPLAY_SCALE;
      } else if (view === "voice") {
        controls.target.set(0, -0.06, -0.33);
        camera.position.copy(controls.target).add(new THREE.Vector3(1.3, 0.4, -0.05));
        halfHeight = Math.max(0.34, 0.4 / (width / height));
      } else {
        controls.target.copy(room.posterTarget);
        camera.position.copy(room.posterTarget).add(new THREE.Vector3(0.9, 0, 0));
        halfHeight = Math.max(0.99, 0.82 / (width / height));
      }
      updateFrustum();
      controls.update();
      wake();
    }
    function draw() {
      frameRequest = 0;
      if (!visible || disposed || document.hidden) return;
      controls.update();
      const distance = bus.config.wallDistance;
      if (distance !== previousDistance) {
        room.update(distance * APPARATUS_DISPLAY_SCALE);
        wallGrid.update({
          minX: room.bounds.min.x, maxX: room.bounds.max.x,
          minY: room.bounds.min.y, maxY: room.bounds.max.y,
          originX: neutralWallX(distance * APPARATUS_DISPLAY_SCALE),
          spacingScale: APPARATUS_DISPLAY_SCALE,
        });
        wallGrid.group.position.z = distance * APPARATUS_DISPLAY_SCALE - 0.002;
        previousDistance = distance;
        if (currentView !== "toy") applyView(currentView, true);
      }
      const center = neutralWallX(distance);
      camera.updateMatrixWorld();
      const gridX = center * APPARATUS_DISPLAY_SCALE;
      const gridZ = wallGrid.group.position.z;
      gridOrigin.set(gridX, 0, gridZ).project(camera);
      gridStepX.set(gridX + 0.01 * APPARATUS_DISPLAY_SCALE, 0, gridZ).project(camera);
      gridStepY.set(gridX, 0.01 * APPARATUS_DISPLAY_SCALE, gridZ).project(camera);
      const spacingX = Math.hypot((gridStepX.x - gridOrigin.x) * width / 2, (gridStepX.y - gridOrigin.y) * height / 2);
      const spacingY = Math.hypot((gridStepY.x - gridOrigin.x) * width / 2, (gridStepY.y - gridOrigin.y) * height / 2);
      wallGrid.setMinorVisible(Math.min(spacingX, spacingY) >= 4);
      trail.line.position.z = distance - 0.003;
      trail.update();
      const frame = bus.frame;
      if (frame && frame !== previousFrame) { toy.update(frame); previousFrame = frame; }
      soundCue.update({
        timeSeconds: bus.latestSample / bus.sampleRate,
        level: bus.inputLevel,
        running: bus.running && currentView !== "poster",
        mouth: mouthPosition,
      });
      const intersection = frame?.mirrorHit;
      const hit = frame?.hit ?? true;
      const mx = intersection?.[0] ?? 0, my = intersection?.[1] ?? 0, mz = intersection?.[2] ?? 0;
      rayPositions.set([...TOY.laserPosition, mx, my, mz, mx, my, mz, hit ? frame?.x ?? center : mx, hit ? frame?.y ?? 0 : my, hit ? distance : mz]);
      rayBuffer.needsUpdate = true;
      rayGeometry.instanceCount = hit ? 2 : intersection ? 1 : 0;
      dot.mesh.visible = hit;
      dot.mesh.position.set(frame?.x ?? center, frame?.y ?? 0, distance - 0.004);
      renderer.render(scene, camera);
    }
    function resize() {
      const bounds = element!.getBoundingClientRect();
      width = Math.max(bounds.width, 1); height = Math.max(bounds.height, 1);
      renderer.setSize(width, height, false);
      rayMaterial.resolution.set(width, height);
      applyView(currentView);
    }
    const observer = new ResizeObserver(resize);
    observer.observe(element);
    const intersection = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting;
      if (visible) wake(); else { cancelAnimationFrame(frameRequest); frameRequest = 0; }
    });
    intersection.observe(element);
    controls.addEventListener("change", wake);
    const unsubscribe = bus.subscribe(wake);
    const onVisibility = () => { if (document.hidden) { cancelAnimationFrame(frameRequest); frameRequest = 0; } else wake(); };
    document.addEventListener("visibilitychange", onVisibility);
    resetCamera.current = () => applyView(currentView);
    selectView.current = (view) => applyView(view);
    resize();
    return () => {
      disposed = true;
      cancelAnimationFrame(frameRequest);
      unsubscribe(); observer.disconnect(); intersection.disconnect();
      document.removeEventListener("visibilitychange", onVisibility);
      controls.removeEventListener("change", wake); controls.dispose();
      resetCamera.current = null; selectView.current = null;
      disposeMeshes(scene);
      textures.forEach(texture => texture.dispose());
      environment.dispose(); key.shadow.dispose();
      renderer.dispose(); renderer.forceContextLoss(); renderer.domElement.remove();
    };
  }, [bus]);
  useEffect(() => { selectView.current?.(sceneView); }, [sceneView]);
  useEffect(() => { resetCamera.current?.(); }, [resetToken]);

  return <div ref={host} className="apparatus-canvas" style={{ width: "100%", height: "100%", position: "relative", overflow: "hidden" }}>
    {error && <div role="alert" style={{ position: "absolute", inset: 24, color: "#b3473d", fontSize: 12 }}>{error}</div>}
    <div style={{ position: "absolute", bottom: 17, right: 20, color: "#767676", font: "11px -apple-system, BlinkMacSystemFont, sans-serif", pointerEvents: "none" }}>Drag to rotate · pinch or scroll to zoom</div>
    {sceneView !== "poster" && <div className="sound-cue-label"><span /> Sound input · slowed</div>}
  </div>;
}
