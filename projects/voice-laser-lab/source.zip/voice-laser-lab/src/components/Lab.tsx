"use client";

import { useEffect, useRef, useState, type CSSProperties, type ReactNode } from "react";
import { AudioController, type AudioStatus, type DemoPreset } from "../audio/controller";
import { DEFAULT_CONFIG, type SimulationConfig } from "../physics/engine";
import { Apparatus, type SceneView } from "./Apparatus";
import { Projection } from "./Projection";
import { DEFAULT_PERSISTENCE } from "../visuals/bus";
import { assetPath, releaseFile } from "../asset-path";
import { InverseLab } from "../inverse/InverseLab";

const INITIAL_STATUS: AudioStatus = { playing: false, ready: false, recording: false, mode: null, rms: 0, position: 0, duration: 0, recordedSeconds: 0, error: null, session: null };
type SourceTab = "demo" | "mic" | "file" | "strudel";
type View = "split" | "wall" | "apparatus";

const STRUDEL_STARTERS = {
  beat: `stack(
  s("bd hh sd hh").gain(.3),
  note("e2 ~ g2 b2")
    .s("triangle").gain(.18)
)`,
  tones: `note("e3 g#3 eb4 f4")
  .s("sine").gain(.2)`,
  piano: `await samples('https://raw.githubusercontent.com/felixroos/dough-samples/main/piano.json')
setcpm(108/3)

note(\`<
  [~ ~ [g4 g4]]
  [a4 g4 c5]
  [b4@2 [g4 g4]]
  [a4 g4 d5]
  [c5@2 [g4 g4]]
  [g5 e5 c5]
  [b4 a4 [f5 f5]]
  [e5 c5 d5]
  [c5@3]
>\`)
.sound("piano")
.gain(0.8)
.room(0.3)`,
};
type StrudelPreset = keyof typeof STRUDEL_STARTERS;

function transportAction(source: SourceTab, playing: boolean, fileName: string) {
  if (source === "strudel") return [playing ? "Update" : "Play", "play"];
  if (source === "mic") return playing ? ["Stop listening", "stop"] : ["Use microphone", "mic"];
  if (playing) return ["Pause", "pause"];
  if (source === "file") return [fileName ? "Play file" : "Choose file", "play"];
  return ["Play demo", "play"];
}

function Icon({ name, size = 16 }: { name: string; size?: number }) {
  const paths: Record<string, ReactNode> = {
    play: <path d="m7 4 13 8-13 8Z" fill="currentColor" stroke="none" />,
    pause: <path d="M8 5v14M16 5v14" strokeWidth="4" />,
    stop: <rect x="6" y="6" width="12" height="12" rx="1" fill="currentColor" stroke="none" />,
    restart: <path d="M4 9a8 8 0 1 1 0 6M4 3v6h6" />,
    download: <path d="M12 3v12m-5-5 5 5 5-5M4 16v4h16v-4" />,
    upload: <path d="M12 16V4m-5 5 5-5 5 5M4 16v4h16v-4" />,
    mic: <><rect x="9" y="3" width="6" height="12" rx="3" /><path d="M6 11v1a6 6 0 0 0 12 0v-1M12 18v3m-4 0h8" /></>,
    sound: <path d="m3 9 4 0 5-4v14l-5-4H3ZM16 8a6 6 0 0 1 0 8m3-11a10 10 0 0 1 0 14" />,
    mute: <path d="m3 9 4 0 5-4v14l-5-4H3ZM17 9l5 6m0-6-5 6" />,
    clear: <path d="m15 4 6 6-11 11H4l-3-3L15 4ZM7 12l6 6m0 3h9" />,
    arrow: <path d="M4 12h15m-6-6 6 6-6 6" />,
    chevron: <path d="m8 5 7 7-7 7" />,
    file: <path d="M5 3h9l5 5v13H5ZM14 3v6h5M9 13v4m3-6v7m3-5v3" />,
    wave: <path d="M2 12h3l2-7 3 14 4-14 3 14 2-7h3" />,
    code: <path d="m8 7-5 5 5 5m8-10 5 5-5 5m-3-12-3 14" />,
    lock: <><rect x="5" y="10" width="14" height="11" rx="2" /><path d="M8 10V6a4 4 0 0 1 8 0v4" /></>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name] ?? paths.wave}</svg>;
}

function Waveform({ controller }: { controller: AudioController | null }) {
  const canvas = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const element = canvas.current;
    if (!element) return;
    const context = element.getContext("2d");
    if (!context) return;
    let raf = 0, visible = true;
    const draw = () => {
      raf = 0;
      const { width, height } = element.getBoundingClientRect();
      const ratio = Math.min(window.devicePixelRatio, 2);
      if (element.width !== Math.round(width * ratio) || element.height !== Math.round(height * ratio)) {
        element.width = Math.round(width * ratio); element.height = Math.round(height * ratio);
      }
      context.setTransform(ratio, 0, 0, ratio, 0, 0);
      context.clearRect(0, 0, width, height);
      context.strokeStyle = "#e7e8e5"; context.lineWidth = 0.75;
      context.beginPath(); context.moveTo(0, height / 2); context.lineTo(width, height / 2); context.stroke();
      const wave = controller?.wave;
      if (!wave || !controller?.status.playing) return;
      context.strokeStyle = "#767a76"; context.lineWidth = 0.9;
      context.beginPath();
      for (let i = 0; i < wave.length; i++) {
        const x = i / (wave.length - 1) * width;
        const y = height / 2 - Math.max(-1, Math.min(1, wave[i])) * height * 0.42;
        if (!i) context.moveTo(x, y); else context.lineTo(x, y);
      }
      context.stroke();
    };
    const wake = () => { if (visible && !raf) raf = requestAnimationFrame(draw); };
    const resize = new ResizeObserver(wake);
    resize.observe(element);
    const visibility = new IntersectionObserver(([entry]) => { visible = entry.isIntersecting; if (visible) wake(); });
    visibility.observe(element);
    const unsubscribeBus = controller?.bus.subscribe(wake);
    const unsubscribeStatus = controller?.subscribe(wake);
    wake();
    return () => { cancelAnimationFrame(raf); resize.disconnect(); visibility.disconnect(); unsubscribeBus?.(); unsubscribeStatus?.(); };
  }, [controller]);
  return <canvas ref={canvas} className="waveform" aria-label="Live input waveform" role="img" />;
}

function Slider({ label, value, min, max, step, display, disabled, onChange }: {
  label: string; value: number; min: number; max: number; step: number; display: string; disabled?: boolean; onChange: (value: number) => void;
}) {
  return <label className={`slider-control${disabled ? " disabled" : ""}`}>
    <span className="slider-label"><span>{label}</span><output>{display}</output></span>
    <input aria-label={label} type="range" min={min} max={max} step={step} value={value} disabled={disabled} onChange={(event) => onChange(Number(event.target.value))}
      style={{ "--range-fill": `${(value - min) / (max - min) * 100}%` } as CSSProperties} />
  </label>;
}

const clock = (seconds: number) => `${Math.floor(seconds / 60)}:${Math.floor(seconds % 60).toString().padStart(2, "0")}`;

export function Lab({ intro }: { intro?: ReactNode } = {}) {
  const [controller, setController] = useState<AudioController | null>(null);
  const [status, setStatus] = useState<AudioStatus>(INITIAL_STATUS);
  const [source, setSource] = useState<SourceTab>("demo");
  const [view, setView] = useState<View>("split");
  const [sceneView, setSceneView] = useState<SceneView>("room");
  const [preset, setPreset] = useState<DemoPreset>("two-tone");
  const [frequency, setFrequency] = useState(220);
  const [parameters, setParameters] = useState({ ...DEFAULT_CONFIG });
  const [persistence, setPersistence] = useState(DEFAULT_PERSISTENCE);
  const [audible, setAudible] = useState(false);
  const soundPreferenceSet = useRef(false);
  const [strudelPreset, setStrudelPreset] = useState<StrudelPreset>("beat");
  const [drafts, setDrafts] = useState(STRUDEL_STARTERS);
  const pattern = drafts[strudelPreset];
  const [loop, setLoop] = useState(true);
  const [resetToken, setResetToken] = useState(0);
  const [busy, setBusy] = useState(false);
  const transportRequest = useRef(0);
  const [exporting, setExporting] = useState(false);
  const [exportError, setExportError] = useState("");
  const [fileName, setFileName] = useState("");
  const fileInput = useRef<HTMLInputElement>(null);
  const exportWorker = useRef<Worker | null>(null);
  useEffect(() => {
    const audio = new AudioController();
    setController(audio); setStatus({ ...audio.status });
    const unsubscribe = audio.subscribe(() => setStatus({ ...audio.status }));
    audio.setLoop(true);
    audio.setAudible(false);
    return () => { unsubscribe(); audio.dispose(); exportWorker.current?.terminate(); };
  }, []);
  const replaying = status.mode === "replay";
  const config = replaying && controller ? controller.bus.config : parameters;
  const run = async (action: () => Promise<unknown>) => {
    const request = ++transportRequest.current;
    setBusy(true);
    try { await action(); }
    catch (error) { if (request === transportRequest.current) setExportError(error instanceof Error ? error.message : String(error)); }
    finally { if (request === transportRequest.current) setBusy(false); }
  };
  function stopAudio() {
    ++transportRequest.current; setBusy(false); controller?.stop();
  }
  function chooseSource(next: SourceTab) {
    stopAudio(); controller?.clearError(); setSource(next);
    // Warm the editor's audio module. Play handles initialization and reports load errors.
    if (next === "strudel") void import("../audio/strudel").catch(() => {});
  }
  function setSound(enabled: boolean) {
    soundPreferenceSet.current = true;
    setAudible(enabled);
    controller?.setAudible(enabled);
  }
  function runPattern() {
    if (!controller || busy || replaying || !pattern.trim()) return;
    if (!soundPreferenceSet.current) setSound(true);
    void run(() => controller.playStrudel(pattern));
  }
  function update(patch: Partial<SimulationConfig>) { setParameters((current) => ({ ...current, ...patch })); controller?.setConfig(patch); }
  function updatePersistence(value: number) {
    setPersistence(value);
    if (controller) { controller.bus.persistence = value; controller.bus.notify(); }
  }
  function playDrawing(file: File, fittedConfig: SimulationConfig) {
    if (!controller) return;
    chooseSource("file");
    update(fittedConfig);
    setView("wall");
    void run(async () => {
      if (await controller.loadFile(file)) setFileName(file.name);
    });
    document.getElementById("laser-workbench")?.scrollIntoView({ block: "start" });
  }
  function play() {
    if (!controller) return;
    if (source === "strudel") { runPattern(); return; }
    if (status.playing) { if (source === "mic") controller.stop(); else controller.pause(); }
    else if (source === "mic") void run(() => controller.startMicrophone());
    else if (status.mode === source && (source === "demo" || status.position < status.duration)) void run(() => controller.resume());
    else if (source === "demo") void run(() => controller.playDemo(preset, frequency));
    else if (fileName) void run(() => controller.playFile());
    else fileInput.current?.click();
  }
  function exportSession() {
    if (!status.session || exporting) return;
    setExporting(true); setExportError("");
    const worker = new Worker(assetPath("generated/session-export.js"), { type: "module" });
    exportWorker.current = worker;
    worker.onmessage = ({ data }) => {
      if (data.error) setExportError(data.error);
      else {
        const bytes = Uint8Array.from(data.bytes as Uint8Array);
        const url = URL.createObjectURL(new Blob([bytes.buffer], { type: "application/zip" }));
        const anchor = document.createElement("a"); anchor.href = url; anchor.download = "voice-laser-session.zip"; anchor.click();
        setTimeout(() => URL.revokeObjectURL(url), 10_000);
      }
      worker.terminate(); exportWorker.current = null; setExporting(false);
    };
    worker.onerror = () => { setExportError("The export could not finish. Try a shorter recording."); worker.terminate(); exportWorker.current = null; setExporting(false); };
    worker.postMessage(status.session);
  }
  const [playLabel, playIcon] = transportAction(source, status.playing && status.mode === source, fileName);
  const sourceLabel = replaying ? "Recorded take" : source === "strudel" ? "Strudel" : status.mode === "mic" ? "Microphone" : status.mode === "file" ? "Audio file" : "Tone generator";
  const stateLabel = status.recording ? "Recording" : status.playing ? "Running" : status.ready ? "Paused" : "Ready";
  const sourceError = status.error && <div id="source-error" className="error-message" role="alert">
    {status.error}<button className="text-button" onClick={() => controller?.clearError()}>Dismiss</button>
  </div>;

  return <div className="lab-shell">
    <header className="site-header">
      <a className="brand" href={assetPath("")} aria-label="Voice to Laser Lab home"><svg className="brand-mark" width="25" height="25" viewBox="0 0 36 36" fill="none" aria-hidden="true"><path d="M5 24 15 10l7 18 9-14" stroke="currentColor" strokeWidth="1" /><circle cx="15" cy="10" r="1.8" fill="currentColor" /></svg><span>voice <span className="brand-divider">/</span> laser</span></a>
      <nav className="lab-navigation" aria-label="Lab sections">
        <a className="about-link" href="#draw-to-sound">Draw a sound <Icon name="arrow" size={12} /></a>
        <a className="about-link" href="#model-notes" onClick={() => { const notes = document.querySelector<HTMLDetailsElement>("#model-notes"); if (notes) notes.open = true; }}>About the experiment <Icon name="arrow" size={12} /></a>
      </nav>
    </header>
    <main>
      {intro ?? <div className="intro"><h1>See what sound does.</h1><p className="intro-copy">A membrane, a mirror, a point of light.</p></div>}
      <div className="workbench" id="laser-workbench">
        <section className={`workspace view-${view}`} aria-label="Laser simulator">
          <div className="workspace-toolbar"><div className="view-tabs" role="group" aria-label="View">{([["split", "Both"], ["wall", "Trace"], ["apparatus", "Model"]] as const).map(([id, label]) => <button data-testid={`view-${id}`} disabled={!controller} key={id} aria-pressed={view === id} className={view === id ? "active" : ""} onClick={() => setView(id)}>{label}</button>)}</div><button className="text-button clear-button" onClick={() => controller?.bus.clear()}><Icon name="clear" size={13} /> Clear trace</button></div>
          {view !== "apparatus" && <div className="projection-panel"><div className="panel-heading"><span>Projection</span><span className="panel-unit">{config.wallDistance.toFixed(1)} m from mirror</span></div>{controller && <Projection bus={controller.bus} persistence={persistence} />}{!status.ready && <div className="empty-prompt"><p>Start with a sound.</p><button className="text-button" disabled={busy || !controller || (source === "strudel" && !pattern.trim())} onClick={() => {
            if (source === "strudel") runPattern();
            else { setSource("demo"); if (controller) void run(() => controller.playDemo(preset, frequency)); }
          }}>{source === "strudel" ? "Play pattern" : "Try the demo"} <Icon name="arrow" size={12} /></button></div>}{status.ready && <div className="projection-caption"><span>{sourceLabel}</span></div>}</div>}
          {view !== "wall" && <div className="apparatus-panel"><div className="panel-heading apparatus-heading"><span>The experiment</span><div className="scene-view-controls"><div className="scene-view-tabs" role="group" aria-label="Scene camera">{([["room", "Room"], ["toy", "Toy"], ["voice", "Voice"], ["poster", "Poster"]] as const).map(([id, label]) => <button key={id} data-testid={`scene-${id}`} aria-pressed={sceneView === id} className={sceneView === id ? "active" : ""} onClick={() => setSceneView(id)}>{label}</button>)}</div><button className="text-button reset-scene" aria-label="Reset camera" onClick={() => setResetToken((value) => value + 1)}><Icon name="restart" size={12} /><span>Reset camera</span></button></div></div>{controller && <Apparatus bus={controller.bus} resetToken={resetToken} sceneView={sceneView} /> }</div>}
          <div className="workspace-status"><span data-testid="app-status"><span className={`status-dot ${status.playing ? "active" : ""}`} />{stateLabel}{replaying ? " / Recorded take" : ""}</span><span>{controller ? `${(controller.bus.sampleRate / 1000).toFixed(1)} kHz` : "48.0 kHz"}</span></div>
        </section>
        <aside className="control-panel" aria-label="Experiment controls">
          <section className="control-section audio-section"><h2>Source</h2><div className="source-tabs" role="group" aria-label="Audio source">{([["demo", "wave", "Demo"], ["mic", "mic", "Voice"], ["file", "file", "File"], ["strudel", "code", "Strudel"]] as const).map(([id, icon, label]) => <button data-testid={`source-${id}`} disabled={!controller} key={id} aria-pressed={source === id} className={source === id ? "active" : ""} onClick={() => chooseSource(id)}><Icon name={icon} size={14} />{label}</button>)}</div>
            {source === "demo" && <div className="source-fields"><label className="select-label" htmlFor="demo-preset">Signal</label><select id="demo-preset" value={preset} disabled={busy || !controller} onChange={(event) => { const next = event.target.value as DemoPreset; setPreset(next); if (status.playing && status.mode === "demo") void run(() => controller!.playDemo(next, frequency)); }}><option value="two-tone">Two tones</option><option value="sine">Pure sine</option><option value="sweep">Frequency sweep</option></select>{preset === "sweep" ? <p className="field-note">80–600 Hz, over 8 seconds.</p> : <Slider label="Frequency" min={60} max={600} step={1} value={frequency} display={preset === "two-tone" ? `${frequency} + ${Math.round(frequency * 1.5)} Hz` : `${frequency} Hz`} onChange={(value) => { setFrequency(value); if (status.playing && status.mode === "demo") void controller?.playDemo(preset, value); }} />}</div>}
            {source === "mic" && <div className="source-explainer"><Icon name="mic" size={24} /><p>Speak, hum, or sing.<br /><span>Your microphone drives the membrane live.</span></p></div>}
            {source === "file" && <div className="file-zone"><button className="upload-button" onClick={() => fileInput.current?.click()} disabled={busy}><Icon name="upload" size={20} /><strong>{fileName || "Choose an audio file"}</strong><span>{fileName ? "Click to replace" : "WAV, MP3, M4A, OGG"}</span></button></div>}
            <input ref={fileInput} className="file-input" type="file" accept="audio/*,.wav,.mp3,.m4a,.ogg,.flac" aria-label="Upload audio file" onChange={(event) => { const file = event.target.files?.[0]; if (file && controller) void run(async () => { if (await controller.loadFile(file)) setFileName(file.name); }); event.target.value = ""; }} />
            {source === "strudel" && <div className="strudel-editor">
              <label className="select-label" htmlFor="strudel-preset">Strudel preset</label>
              <select id="strudel-preset" data-testid="strudel-preset" value={strudelPreset} onChange={event => {
                setStrudelPreset(event.target.value as StrudelPreset);
                controller?.clearError();
              }}>
                <option value="beat">Beat and bass</option>
                <option value="tones">Four sine tones</option>
                <option value="piano">Piano melody (online)</option>
              </select>
              <label className="select-label" htmlFor="strudel-code">Strudel code</label>
              <textarea id="strudel-code" data-testid="strudel-code" value={pattern} rows={6} wrap="off"
                spellCheck={false} autoCapitalize="off" autoCorrect="off"
                aria-describedby={status.error ? "strudel-shortcut source-error" : "strudel-shortcut"}
                onChange={event => setDrafts({ ...drafts, [strudelPreset]: event.target.value })}
                onKeyDown={event => {
                  if (event.key === "Enter" && (event.ctrlKey || event.metaKey) && !event.nativeEvent.isComposing) {
                    event.preventDefault();
                    if (!event.repeat) runPattern();
                  }
                }} />
              <div className="strudel-editor-meta">
                <span id="strudel-shortcut">Ctrl/⌘ + Enter to run</span>
                <a href="https://strudel.cc/" target="_blank" rel="noreferrer">© Strudel contributors</a>
              </div>
              {sourceError}
            </div>}
            <div className="transport">
              <button data-testid="play-toggle" className="primary-button"
                aria-keyshortcuts={source === "strudel" ? "Control+Enter Meta+Enter" : undefined}
                disabled={!controller || busy || replaying || (source === "strudel" && !pattern.trim())} onClick={play}>
                <Icon name={playIcon} size={15} />{busy ? "Preparing…" : playLabel}
              </button>
              {source === "strudel" && <button data-testid="strudel-pause" className="icon-button"
                title={status.playing ? "Pause pattern" : "Resume pattern"} aria-label={status.playing ? "Pause pattern" : "Resume pattern"}
                disabled={busy || status.mode !== "strudel"} onClick={() => {
                  if (status.playing) controller?.pause();
                  else if (controller) void run(() => controller.resume());
                }}><Icon name={status.playing ? "pause" : "play"} /></button>}
              <button data-testid="restart-audio" className="icon-button" title="Restart audio" aria-label="Restart audio" disabled={!status.ready || busy || !status.mode} onClick={() => controller && void run(() => controller.restart())}><Icon name="restart" /></button>
              <button data-testid="stop-audio" className="icon-button" title="Stop audio" aria-label="Stop audio"
                disabled={!status.mode && !(source === "strudel" && busy)} onClick={stopAudio}><Icon name="stop" size={14} /></button>
            </div>
            <Waveform controller={controller} /><div className="audio-meta"><span>{source === "mic" ? "Monitoring off" : source === "file" && status.duration ? `${clock(status.position)} / ${clock(status.duration)}` : "Input"}</span>{source !== "mic" && <button className={`sound-button${audible ? " enabled" : ""}`} aria-label={audible ? "Mute audio" : "Enable audio playback"} aria-pressed={audible} onClick={() => setSound(!audible)}><Icon name={audible ? "sound" : "mute"} size={13} />{audible ? "Sound on" : "Sound off"}</button>}</div>
            {source === "file" && <label className="check-label"><input type="checkbox" checked={loop} onChange={(event) => { setLoop(event.target.checked); controller?.setLoop(event.target.checked); }} /> Loop audio</label>}{replaying && <p className="field-note">Choose an audio source to return to live controls.</p>}{source !== "strudel" && sourceError}
          </section>
          <section className="control-section tune-section">
            <div className="section-heading"><h2>Shape</h2><button className="text-button" disabled={replaying || !controller} onClick={() => { update({ ...DEFAULT_CONFIG }); updatePersistence(DEFAULT_PERSISTENCE); }}>Reset</button></div>
            <Slider label="Input gain" min={0} max={5} step={0.05} value={config.gain} display={`${config.gain.toFixed(2)}×`} disabled={replaying || !controller} onChange={(gain) => update({ gain })} />
            <Slider label="Trace persistence" min={0.05} max={2} step={0.05} value={persistence} display={`${persistence.toFixed(2)} s`} onChange={updatePersistence} />
            <details className="mechanics"><summary>Membrane & geometry <Icon name="chevron" size={12} /></summary><div className="mechanics-controls">
              <Slider label="Membrane tension" min={0.25} max={4} step={0.05} value={config.tension} display={`${config.tension.toFixed(2)}×`} disabled={replaying || !controller} onChange={(tension) => update({ tension })} />
              <Slider label="Damping" min={0.005} max={0.15} step={0.005} value={config.damping} display={config.damping.toFixed(3)} disabled={replaying || !controller} onChange={(damping) => update({ damping })} />
              <Slider label="Asymmetry" min={0} max={0.5} step={0.01} value={config.asymmetry} display={`${Math.round(config.asymmetry * 100)}%`} disabled={replaying || !controller} onChange={(asymmetry) => update({ asymmetry })} />
              <Slider label="Wall distance" min={0.5} max={4} step={0.1} value={config.wallDistance} display={`${config.wallDistance.toFixed(1)} m`} disabled={replaying || !controller} onChange={(wallDistance) => update({ wallDistance })} />
            </div></details>
          </section>
          <section className="control-section capture-section"><h2>Capture</h2><button data-testid="record-toggle" className={`record-button${status.recording ? " recording" : ""}`} disabled={(!status.playing && !status.recording) || replaying || busy} onClick={() => status.recording ? controller?.finishRecording() : controller?.startRecording()}><span className="record-dot" />{status.recording ? "Finish recording" : "Record"}<span className="record-time">{status.recording ? `${status.recordedSeconds.toFixed(1)} s` : "60 s max"}</span></button>{status.session && <><div className="saved-take"><span className="status-dot active" /><span>Take saved</span><span>{(status.session.metadata.sampleCount / status.session.metadata.sampleRate).toFixed(1)} s</span></div><div className="capture-actions"><button data-testid="replay-session" className="secondary-button" disabled={status.recording || busy} onClick={() => controller && void run(() => controller.replayRecording())}><Icon name="play" size={13} /> Replay</button><button data-testid="export-session" className="secondary-button" disabled={status.recording || exporting} onClick={exportSession}><Icon name="download" size={13} />{exporting ? "Exporting…" : "Export"}</button></div></>}<p className="capture-note">Audio, settings, and the path of light.</p>{exportError && <p className="error-message" role="alert">{exportError}</p>}</section>
        </aside>
      </div>
      <details id="model-notes" className="model-notes"><summary><span>How it works</span><Icon name="chevron" size={14} /></summary><div className="notes-content"><div><h3>Audio drives the state</h3><p>A mode is a membrane vibration pattern. The engine tracks the displacement and velocity of six modes. These twelve values form the dynamical state. Each audio sample changes that state. The state carries the effect of earlier sound.</p></div><div><h3>The state sets the mirror</h3><p>The six displacements determine the mirror height and two surface slopes. Those slopes determine its normal vector. The engine intersects the laser ray with the mirror plane. It reflects that ray and calculates its intersection with the wall.</p></div><div><h3>The wall shows the output</h3><p>The two wall coordinates are outputs of the membrane state. The beam has no separate inertia in this model. The sound rings show input activity at a reduced display speed. The model does not calculate room acoustics. One input drives both axes, so arbitrary drawings may be unreachable.</p><p className="asset-credit">Human model: <a href="https://www.innerscene.com/tools/library/3d-parts/human-base-mesh-with-editable-53-bone-rig-8e7c8ab1" target="_blank" rel="noreferrer">Innerscene / MakeHuman / MPFB</a> (CC0).</p></div></div></details>
      <div id="draw-to-sound">
        {controller ? <InverseLab config={config} onPlayInLab={playDrawing} /> : <p role="status">Loading drawing tools…</p>}
      </div>
    </main>
    <footer>
      <span>Audio stays on your device.</span>
      <nav className="lab-source-links" aria-label="Voice Laser Lab software">
        <a href={releaseFile('source.zip')} download>Source code (ZIP)</a>
        <a href={releaseFile('LICENSE.txt')} aria-label="Voice Laser Lab code license, AGPL-3.0-or-later">AGPL-3.0-or-later</a>
      </nav>
    </footer>
  </div>;
}
