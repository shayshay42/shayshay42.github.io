"use client";

import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { neutralWallX } from "../physics/engine";
import type { VisualBus } from "../visuals/bus";
import { createLaserDot, createTrail } from "../visuals/trail";
import { createProjectionGrid } from "../visuals/projection-grid";

export function Projection({ bus, persistence }: { bus: VisualBus; persistence: number }) {
  const host = useRef<HTMLDivElement>(null);
  const [error, setError] = useState("");
  useEffect(() => { bus.persistence = persistence; bus.notify(); }, [bus, persistence]);

  useEffect(() => {
    const element = host.current;
    if (!element) return;
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
    } catch {
      setError("The projection needs WebGL. Enable hardware acceleration and reload.");
      return;
    }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(0xffffff, 1);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.domElement.setAttribute("aria-label", "Laser trace on the wall, centered on the resting laser spot");
    renderer.domElement.setAttribute("role", "img");
    renderer.domElement.style.cssText = "display:block;width:100%;height:100%";
    element.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.01, 10);
    camera.position.z = 3;
    let gridOrigin = neutralWallX(bus.config.wallDistance);
    let gridHalfWidth = 1;
    const grid = createProjectionGrid({
      minX: gridOrigin - gridHalfWidth, maxX: gridOrigin + gridHalfWidth,
      minY: -1, maxY: 1, originX: gridOrigin,
    });
    grid.group.position.z = -0.01;
    scene.add(grid.group);

    function updateGrid(center: number, halfWidth = gridHalfWidth) {
      if (center === gridOrigin && halfWidth === gridHalfWidth) return;
      gridOrigin = center;
      gridHalfWidth = halfWidth;
      grid.update({ minX: center - halfWidth, maxX: center + halfWidth, minY: -1, maxY: 1, originX: center });
    }

    const trail = createTrail(bus);
    const dot = createLaserDot();
    scene.add(trail.line, dot.mesh);
    let width = 1;
    let height = 1;
    const visibleHeight = 0.28;
    let raf = 0;
    let visible = true;
    let disposed = false;
    function render() {
      raf = 0;
      if (disposed || !visible || document.hidden) return;
      const center = neutralWallX(bus.config.wallDistance);
      camera.position.x = center;
      updateGrid(center);
      trail.update();
      const frame = bus.frame;
      dot.mesh.visible = !frame || frame.hit;
      dot.mesh.position.set(frame?.x ?? center, frame?.y ?? 0, 0.01);
      renderer.render(scene, camera);
    }
    function wake() {
      if (!raf && visible && !document.hidden && !disposed) raf = requestAnimationFrame(render);
    }
    function resize() {
      const bounds = element!.getBoundingClientRect();
      width = Math.max(1, bounds.width);
      height = Math.max(1, bounds.height);
      renderer.setSize(width, height, false);
      element!.style.setProperty("--projection-centimetre", `${height / visibleHeight * 0.01}px`);
      camera.left = -visibleHeight * width / height / 2;
      camera.right = -camera.left;
      camera.top = visibleHeight / 2;
      camera.bottom = -camera.top;
      camera.updateProjectionMatrix();
      updateGrid(neutralWallX(bus.config.wallDistance), Math.max(1, camera.right + 0.1));
      grid.setMinorVisible(height / visibleHeight * 0.01 >= 4);
      dot.mesh.scale.setScalar(visibleHeight * 4 / height);
      wake();
    }
    const observer = new ResizeObserver(resize);
    observer.observe(element);
    resize();
    const unsubscribe = bus.subscribe(wake);
    const intersection = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting;
      if (visible) wake();
      else { cancelAnimationFrame(raf); raf = 0; }
    });
    intersection.observe(element);
    const visibility = () => {
      if (document.hidden) { cancelAnimationFrame(raf); raf = 0; }
      else wake();
    };
    document.addEventListener("visibilitychange", visibility);
    return () => {
      disposed = true;
      cancelAnimationFrame(raf);
      unsubscribe();
      intersection.disconnect();
      document.removeEventListener("visibilitychange", visibility);
      observer.disconnect();
      trail.dispose();
      dot.dispose();
      grid.dispose();
      renderer.dispose();
      renderer.forceContextLoss();
      renderer.domElement.remove();
    };
  }, [bus]);

  return <div ref={host} className="projection-canvas" style={{ width: "100%", height: "100%", position: "relative", overflow: "hidden", background: "#fff" }}>
    {error && <div role="alert" style={{ position: "absolute", inset: 24, color: "#7c807d", fontSize: 13 }}>{error}</div>}
    <div aria-hidden="true" style={{ position: "absolute", bottom: 20, left: 22, color: "#7c807d", font: "10px ui-monospace, monospace", pointerEvents: "none", display: "flex", alignItems: "center", gap: 8 }}>
      <span style={{ display: "inline-block", width: "var(--projection-centimetre, 20px)", borderTop: "1px solid #b9bdb8", borderLeft: "1px solid #b9bdb8", borderRight: "1px solid #b9bdb8", height: 4 }} />
      1 CM
    </div>
  </div>;
}
