import { DEFAULT_CONFIG, MODEL_VERSION, Simulator, type SimulationConfig, type TraceBlock } from '../physics/engine';
import { createSessionReplayer } from '../session/replay';
import type { RecordedSession, SessionMetadata } from '../session/types';

declare const sampleRate: number;
declare abstract class AudioWorkletProcessor {
  readonly port: MessagePort;
}
declare function registerProcessor(name: string, processor: typeof AudioWorkletProcessor): void;

type SourceMode = 'idle' | 'mic' | 'strudel' | 'file' | 'demo' | 'replay';
type Demo = 'sine' | 'two-tone' | 'sweep';

class LaserProcessor extends AudioWorkletProcessor {
  private sim = new Simulator(DEFAULT_CONFIG, sampleRate);
  private config = { ...DEFAULT_CONFIG };
  private mode: SourceMode = 'idle';
  private playing = false;
  private audible = true;
  private loop = true;
  private demo: Demo = 'two-tone';
  private frequency = 220;
  private pcm: Float32Array = new Float32Array(0);
  private position = 0;
  private replay: ReturnType<typeof createSessionReplayer> | null = null;
  private recording: SessionMetadata | null = null;
  private recordCount = 0;
  private blocks: TraceBlock[] = [];
  private inputBlocks: Float32Array[] = [];
  private queued = 0;

  constructor() {
    super();
    this.port.onmessage = ({ data: message }) => {
      try {
        switch (message.type) {
          case 'config': {
            // A replay follows its recorded parameter timeline, not the live controls.
            if (this.mode === 'replay') break;
            this.sim.setConfig(message.patch);
            this.config = { ...this.config, ...message.patch };
            this.recording?.parameterEvents.push({ sampleIndex: this.sim.getState().sampleIndex, patch: { ...message.patch } });
            this.port.postMessage({ type: 'configured', frame: this.sim.getFrame() });
            break;
          }
          case 'source': {
            this.finishRecording();
            this.flush();
            this.mode = message.mode;
            this.position = 0;
            this.pcm = message.pcm ?? new Float32Array(0);
            this.demo = message.demo ?? 'two-tone';
            this.frequency = message.frequency ?? 220;
            this.sim = new Simulator(this.config, sampleRate);
            this.replay = null;
            this.playing = true;
            this.port.postMessage({ type: 'started', mode: this.mode, generation: message.generation, frame: this.sim.getFrame() });
            break;
          }
          case 'replay': {
            this.finishRecording();
            this.flush();
            const session = message.session as RecordedSession;
            if (session.metadata.sampleRate !== sampleRate) throw new Error('Replay sample rate differs from the audio device. Export the session for exact headless replay.');
            this.replay = createSessionReplayer(session);
            this.sim = this.replay.simulator;
            this.pcm = session.pcm;
            this.mode = 'replay';
            this.position = 0;
            this.playing = true;
            this.port.postMessage({ type: 'started', mode: this.mode, frame: this.sim.getFrame() });
            break;
          }
          case 'pause': this.playing = false; this.flush(); break;
          case 'resume': if (this.mode !== 'idle') this.playing = true; break;
          case 'monitor': this.audible = message.value; break;
          case 'loop': this.loop = message.value; break;
          case 'record-start': {
            if (!this.playing || this.mode === 'replay' || this.recording) break;
            this.flush();
            this.recordCount = 0;
            this.recording = {
              modelVersion: MODEL_VERSION,
              sampleRate,
              initialConfig: { ...this.config },
              initialState: this.sim.getState(),
              parameterEvents: [],
              sampleCount: 0,
            };
            this.port.postMessage({ type: 'record-started' });
            break;
          }
          case 'record-stop': this.finishRecording(); break;
          case 'stop': {
            this.finishRecording();
            this.flush();
            this.playing = false;
            this.mode = 'idle';
            this.replay = null;
            this.sim = new Simulator(this.config, sampleRate);
            this.port.postMessage({ type: 'stopped', frame: this.sim.getFrame() });
            break;
          }
        }
      } catch (error) {
        this.playing = false;
        this.port.postMessage({ type: 'error', message: error instanceof Error ? error.message : String(error) });
      }
    };
  }

  private finishRecording() {
    if (!this.recording) return;
    this.flush();
    this.recording.sampleCount = this.recordCount;
    this.port.postMessage({ type: 'record-finished', metadata: this.recording });
    this.recording = null;
  }

  private flush() {
    if (!this.queued) return;
    const xy = new Float32Array(this.queued * 2);
    const hits = new Uint8Array(this.queued);
    let offset = 0;
    for (const block of this.blocks) {
      xy.set(block.xy, offset * 2);
      hits.set(block.hits, offset);
      offset += block.count;
    }
    const input = new Float32Array(this.queued);
    offset = 0;
    for (const chunk of this.inputBlocks) { input.set(chunk, offset); offset += chunk.length; }
    let energy = 0;
    for (const sample of input) energy += sample * sample;
    const wave = new Float32Array(96);
    for (let i = 0; i < wave.length; i++) wave[i] = input[Math.floor(i * input.length / wave.length)];
    const block: TraceBlock = {
      startSample: this.blocks[0].startSample,
      count: this.queued,
      xy, hits,
      lastFrame: this.blocks[this.blocks.length - 1].lastFrame,
    };
    // At rates such as 44.1 kHz the last recorded sample falls inside a render quantum.
    const recorded = this.recording ? input.subarray(0, sampleRate * 60 - this.recordCount) : undefined;
    if (recorded) this.recordCount += recorded.length;
    this.port.postMessage({
      type: 'trace', block, recorded, wave,
      rms: Math.sqrt(energy / input.length),
      position: this.position / sampleRate,
      duration: this.pcm.length / sampleRate,
      config: this.mode === 'replay' ? this.replay?.config : this.config,
    }, [xy.buffer, hits.buffer, wave.buffer, ...(recorded ? [recorded.buffer] : [])]);
    this.blocks = [];
    this.inputBlocks = [];
    this.queued = 0;
  }

  process(inputs: Float32Array[][], outputs: Float32Array[][]): boolean {
    const output = outputs[0]?.[0];
    if (!output) return true;
    output.fill(0);
    if (!this.playing) return true;
    try {
      const input = new Float32Array(output.length);
      let count = input.length;
      let block: TraceBlock | null = null;
      if (this.mode === 'replay' && this.replay) {
        const start = this.replay.position;
        block = this.replay.processNext(input.length);
        count = block?.count ?? 0;
        input.set(this.pcm.subarray(start, start + count));
        this.position = start + count;
      } else {
        for (let i = 0; i < input.length; i++) {
          if (this.mode === 'mic' || this.mode === 'strudel') {
            const channels = inputs[0] ?? [];
            let sum = 0;
            for (const channel of channels) sum += channel[i] ?? 0;
            input[i] = channels.length ? sum / channels.length : 0;
          } else if (this.mode === 'file') {
            if (this.position >= this.pcm.length) {
              if (this.loop && this.pcm.length) this.position = 0;
              else { count = i; break; }
            }
            input[i] = this.pcm[this.position] ?? 0;
          } else if (this.mode === 'demo') {
            const t = this.position / sampleRate;
            if (this.demo === 'sine') input[i] = 0.22 * Math.sin(2 * Math.PI * this.frequency * t);
            else if (this.demo === 'two-tone') input[i] = 0.2 * Math.sin(2 * Math.PI * this.frequency * t) + 0.2 * Math.sin(2 * Math.PI * this.frequency * 1.5 * t);
            else {
              const s = t % 8;
              input[i] = 0.2 * Math.sin(2 * Math.PI * (80 * s + 0.5 * 65 * s * s));
            }
          }
          this.position++;
        }
        if (count) block = this.sim.process(input.subarray(0, count));
      }
      if (block && count) {
        const actual = input.slice(0, count);
        this.blocks.push(block);
        this.inputBlocks.push(actual);
        this.queued += count;
        if (this.audible && this.mode !== 'mic') {
          // Playback level is independent of the physical input-gain control.
          for (let i = 0; i < count; i++) output[i] = Math.max(-1, Math.min(1, input[i])) * 0.5;
        }
        if (this.queued >= 1024) this.flush();
        if (this.recording && this.recordCount + this.queued >= sampleRate * 60) this.finishRecording();
      }
      if (count < input.length || (this.mode === 'replay' && this.replay?.done)) {
        this.finishRecording();
        this.flush();
        this.playing = false;
        this.port.postMessage({ type: 'ended' });
      }
      return true;
    } catch (error) {
      this.playing = false;
      this.port.postMessage({ type: 'error', message: error instanceof Error ? error.message : String(error) });
      return true;
    }
  }
}

registerProcessor('voice-laser', LaserProcessor);
