import { encodeSessionZip, type RecordedSession } from '../session';

self.onmessage = async ({ data }: MessageEvent<RecordedSession>) => {
  try {
    const bytes = await encodeSessionZip(data, { includeTrace: true });
    self.postMessage({ bytes }, { transfer: [bytes.buffer] });
  } catch (error) {
    self.postMessage({ error: error instanceof Error ? error.message : String(error) });
  }
};
