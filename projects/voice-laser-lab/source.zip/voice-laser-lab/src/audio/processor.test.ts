import assert from 'node:assert/strict';
import test from 'node:test';
import { DEFAULT_CONFIG, Simulator, type TraceBlock } from '../physics/engine';
import { replaySession } from '../session/replay';
import type { RecordedSession } from '../session/types';

const RATE = 48000;
type Message = { type: string; [key: string]: any };
class TestPort {
  onmessage: ((event: { data: Message }) => void) | null = null;
  messages: Message[] = [];
  postMessage(message: Message, transfer: Transferable[] = []) {
    // Transfer semantics catch accidental use of detached worklet buffers.
    this.messages.push(structuredClone(message, { transfer }));
  }
}
interface TestProcessor {
  port: TestPort;
  process(inputs: Float32Array[][], outputs: Float32Array[][]): boolean;
}
let Processor: (new () => TestProcessor) | undefined;
Object.assign(globalThis, {
  sampleRate: RATE,
  AudioWorkletProcessor: class { readonly port = new TestPort(); },
  registerProcessor(name: string, constructor: new () => TestProcessor) {
    assert.equal(name, 'voice-laser');
    Processor = constructor;
  },
});
await import('./processor');

function create(): TestProcessor {
  assert.ok(Processor);
  return new Processor();
}
function send(processor: TestProcessor, message: Message): void {
  processor.port.onmessage!({ data: message });
}
function quantum(processor: TestProcessor, channels: Float32Array[] = [], count = 128): Float32Array {
  const output = new Float32Array(count);
  assert.equal(processor.process([channels], [[output]]), true);
  return output;
}
function messages(processor: TestProcessor, type: string): Message[] {
  return processor.port.messages.filter(message => message.type === type);
}
function concatenate(chunks: Float32Array[]): Float32Array {
  const output = new Float32Array(chunks.reduce((count, chunk) => count + chunk.length, 0));
  let offset = 0;
  for (const chunk of chunks) { output.set(chunk, offset); offset += chunk.length; }
  return output;
}

test('file end processes its exact sample count and silences the unused output', () => {
  const processor = create();
  const pcm = Float32Array.from({ length: 150 }, (_, i) => 0.2 * Math.sin(i * 0.1));
  send(processor, { type: 'loop', value: false });
  send(processor, { type: 'source', mode: 'file', pcm });
  const first = quantum(processor);
  const second = quantum(processor);
  for (let i = 0; i < 128; i++) assert.equal(first[i], pcm[i] * 0.5);
  for (let i = 0; i < 22; i++) assert.equal(second[i], pcm[i + 128] * 0.5);
  assert.ok(second.subarray(22).every(value => value === 0));
  const traces = messages(processor, 'trace');
  assert.equal(traces.length, 1);
  assert.equal(traces[0].block.count, 150);
  assert.deepEqual(traces[0].block, new Simulator().process(pcm));
  assert.equal(messages(processor, 'ended').length, 1);
  assert.ok(quantum(processor).every(value => value === 0));
  assert.equal(messages(processor, 'ended').length, 1);
});

test('midstream recording, parameter events, pause and resume replay sample exactly', () => {
  const processor = create();
  send(processor, { type: 'source', mode: 'demo', demo: 'two-tone', frequency: 220 });
  for (let i = 0; i < 10; i++) quantum(processor);
  send(processor, { type: 'record-start' });
  for (let i = 0; i < 5; i++) quantum(processor);
  send(processor, { type: 'config', patch: { tension: 1.2, gain: 0.8 } });
  for (let i = 0; i < 10; i++) quantum(processor);
  send(processor, { type: 'pause' });
  const traceCount = messages(processor, 'trace').length;
  for (let i = 0; i < 4; i++) assert.ok(quantum(processor).every(value => value === 0));
  assert.equal(messages(processor, 'trace').length, traceCount);
  send(processor, { type: 'resume' });
  for (let i = 0; i < 7; i++) quantum(processor);
  send(processor, { type: 'record-stop' });
  const finished = messages(processor, 'record-finished');
  assert.equal(finished.length, 1);
  const recorded = messages(processor, 'trace').filter(message => message.recorded);
  const session: RecordedSession = {
    metadata: finished[0].metadata,
    pcm: concatenate(recorded.map(message => message.recorded)),
  };
  assert.equal(session.metadata.initialState.sampleIndex, 1280);
  assert.equal(session.metadata.sampleCount, 22 * 128);
  assert.equal(session.pcm.length, session.metadata.sampleCount);
  assert.deepEqual(session.metadata.parameterEvents,
    [{ sampleIndex: 1920, patch: { tension: 1.2, gain: 0.8 } }]);
  const replayed: TraceBlock[] = [];
  replaySession(session, { chunkSize: 377, onTrace: block => replayed.push(block) });
  assert.deepEqual(concatenate(replayed.map(block => block.xy)),
    concatenate(recorded.map(message => message.block.xy)));
  const expectedHits = recorded.flatMap(message => Array.from(message.block.hits));
  assert.deepEqual(replayed.flatMap(block => Array.from(block.hits)), expectedHits);
  assert.equal(messages(processor, 'error').length, 0);
});

test('microphone channels are averaged and are never sent to speakers', () => {
  const processor = create();
  send(processor, { type: 'source', mode: 'mic' });
  send(processor, { type: 'record-start' });
  const left = Float32Array.from({ length: 128 }, (_, i) => 0.4 * Math.sin(i * 0.06));
  const right = Float32Array.from(left, sample => sample * 0.5);
  const output = quantum(processor, [left, right]);
  assert.ok(output.every(value => value === 0));
  send(processor, { type: 'record-stop' });
  const trace = messages(processor, 'trace')[0];
  const expected = Float32Array.from(left, (value, i) => (value + right[i]) / 2);
  assert.deepEqual(trace.recorded, expected);
  assert.deepEqual(trace.block, new Simulator().process(expected));
});

test('Strudel drives the mirror with its stereo mix and records the same input while muted', () => {
  const processor = create();
  const left = Float32Array.from({length: 128}, (_, i) => 0.09 * Math.sin(i * 0.16));
  const right = Float32Array.from({length: 128}, (_, i) => 0.055 * Math.cos(i * 0.23));
  const mono = Float32Array.from(left, (value, i) => (value + right[i]) / 2);
  send(processor, {type: 'source', mode: 'strudel'});
  send(processor, {type: 'record-start'});
  assert.deepEqual(quantum(processor, [left, right]), Float32Array.from(mono, sample => sample * 0.5));
  send(processor, {type: 'monitor', value: false});
  assert.ok(quantum(processor, [left, right]).every(sample => sample === 0));
  send(processor, {type: 'record-stop'});
  const trace = messages(processor, 'trace')[0];
  const pcm = concatenate([mono, mono]);
  assert.deepEqual(trace.recorded, pcm);
  assert.deepEqual(trace.block, new Simulator().process(pcm));
  const metadata = messages(processor, 'record-finished')[0].metadata;
  const replayed: TraceBlock[] = [];
  replaySession({ metadata, pcm }, { onTrace: block => replayed.push(block) });
  assert.deepEqual(concatenate(replayed.map(block => block.xy)), trace.block.xy);
  assert.equal(messages(processor, 'error').length, 0);
});

test('stop finalizes recording, flushes samples and resets the mechanical state', () => {
  const processor = create();
  send(processor, { type: 'source', mode: 'demo' });
  send(processor, { type: 'record-start' });
  quantum(processor);
  send(processor, { type: 'stop' });
  const types = processor.port.messages.map(message => message.type);
  assert.ok(types.indexOf('trace') < types.indexOf('record-finished'));
  assert.ok(types.indexOf('record-finished') < types.indexOf('stopped'));
  assert.equal(messages(processor, 'record-finished')[0].metadata.sampleCount, 128);
  assert.deepEqual(messages(processor, 'stopped')[0].frame, new Simulator().getFrame());
  assert.ok(quantum(processor).every(value => value === 0));
});

test('replay follows its saved configuration and ends after its final sample', () => {
  const processor = create();
  const config = { ...DEFAULT_CONFIG, wallDistance: 3 };
  const session: RecordedSession = {
    metadata: {
      modelVersion: 'membrane-six-mode-v1', sampleRate: RATE, sampleCount: 300,
      initialConfig: config, initialState: new Simulator(config).getState(),
      parameterEvents: [{ sampleIndex: 128, patch: { gain: 0.3, wallDistance: 1.5 } }],
    },
    pcm: Float32Array.from({ length: 300 }, (_, i) => 0.2 * Math.sin(i * 0.1)),
  };
  send(processor, { type: 'replay', session });
  send(processor, { type: 'config', patch: { gain: 5 } });
  quantum(processor); quantum(processor); quantum(processor);
  const traces = messages(processor, 'trace');
  const expected: TraceBlock[] = [];
  replaySession(session, { onTrace: block => expected.push(block) });
  assert.deepEqual(concatenate(traces.map(message => message.block.xy)), expected[0].xy);
  assert.equal(traces[0].config.wallDistance, 1.5);
  assert.equal(traces[0].config.gain, 0.3);
  assert.equal(messages(processor, 'ended').length, 1);
  assert.equal(messages(processor, 'error').length, 0);
});

test('recording automatically finishes at its cap while bounded trace batches continue', () => {
  // This rate puts the 60-second boundary inside the last 128-frame quantum.
  const deviceRate = 11025;
  Object.assign(globalThis, { sampleRate: deviceRate });
  try {
    const processor = create();
    send(processor, { type: 'source', mode: 'demo' });
    send(processor, { type: 'record-start' });
    const cap = deviceRate * 60;
    for (let i = 0; i < cap / 128 + 16; i++) quantum(processor);
    const finished = messages(processor, 'record-finished');
    assert.equal(finished.length, 1);
    assert.equal(finished[0].metadata.sampleCount, cap);
    const traces = messages(processor, 'trace');
    assert.equal(traces.reduce((sum, message) => sum + (message.recorded?.length ?? 0), 0), cap);
    assert.ok(traces.every(message => message.block.count <= 1024));
    assert.equal(traces.at(-1)!.recorded, undefined);
    assert.equal(messages(processor, 'ended').length, 0);
    assert.equal(messages(processor, 'error').length, 0);
  } finally {
    Object.assign(globalThis, { sampleRate: RATE });
  }
});
