import { DEFAULT_CONFIG, Simulator, type SimulationConfig } from '../physics/engine';
import type { RecordedSession, SessionMetadata } from '../session';
import { VisualBus } from '../visuals/bus';
import { assetPath } from '../asset-path';
import type { StrudelRuntime } from './strudel';

export type SourceMode = 'demo' | 'mic' | 'file' | 'strudel' | 'replay';
export type DemoPreset = 'sine' | 'two-tone' | 'sweep';
export interface AudioStatus {
  playing: boolean;
  ready: boolean;
  recording: boolean;
  mode: SourceMode | null;
  rms: number;
  position: number;
  duration: number;
  recordedSeconds: number;
  error: string | null;
  session: RecordedSession | null;
}

export class AudioController {
  readonly bus = new VisualBus();
  wave = new Float32Array(96);
  status: AudioStatus = { playing: false, ready: false, recording: false, mode: null, rms: 0, position: 0, duration: 0, recordedSeconds: 0, error: null, session: null };
  private listeners = new Set<() => void>();
  private context: AudioContext | null = null;
  private node: AudioWorkletNode | null = null;
  private stream: MediaStream | null = null;
  private microphone: MediaStreamAudioSourceNode | null = null;
  private initializing: Promise<void> | null = null;
  private strudel: StrudelRuntime | null = null;
  private loadingStrudel: Promise<StrudelRuntime> | null = null;
  private activePattern: string | null = null;
  private chunks: Float32Array[] = [];
  private config = { ...DEFAULT_CONFIG };
  private lastNotify = 0;
  private filePcm: Float32Array | null = null;
  private preset: DemoPreset = 'two-tone';
  private frequency = 220;
  private audible = true;
  private loop = true;
  private generation = 0;
  private disposed = false;

  constructor() { this.bus.frame = new Simulator().getFrame(); }

  subscribe = (listener: () => void) => { this.listeners.add(listener); return () => { this.listeners.delete(listener); }; };
  private notify(patch: Partial<AudioStatus> = {}) {
    this.status = { ...this.status, ...patch };
    this.listeners.forEach((listener) => listener());
  }
  clearError() { this.notify({ error: null }); }

  private async ensure() {
    if (this.disposed) throw new Error('Audio controller has been closed.');
    if (!this.context) {
      if (!window.AudioContext) throw new Error('This browser does not support Web Audio. Open the app in desktop Chrome.');
      this.context = new AudioContext({ latencyHint: 'interactive' });
      this.bus.sampleRate = this.context.sampleRate;
      this.initializing = (async () => {
        await this.context!.audioWorklet.addModule(assetPath('generated/audio-processor.js'));
        if (this.disposed) return;
        this.node = new AudioWorkletNode(this.context!, 'voice-laser', { numberOfInputs: 1, numberOfOutputs: 1, outputChannelCount: [1], channelCountMode: 'explicit', channelCount: 2 });
        this.node.port.onmessage = ({ data }) => this.onMessage(data);
        this.node.onprocessorerror = () => this.fail(new Error('Audio processing stopped. Reload the page to restart it.'));
        this.node.connect(this.context!.destination);
        this.node.port.postMessage({ type: 'config', patch: this.config });
        this.node.port.postMessage({ type: 'monitor', value: this.audible });
        this.node.port.postMessage({ type: 'loop', value: this.loop });
        this.notify({ ready: true });
      })();
    }
    // Call resume before waiting for module loading to preserve the user gesture.
    await Promise.all([this.context.resume(), this.initializing]);
  }

  // Worklet messages contain transferred typed arrays and validated session metadata.
  private onMessage(data: any) {
    if (this.disposed) return;
    if (data.type === 'trace') {
      if (data.config) this.bus.config = { ...data.config };
      this.bus.inputLevel = data.rms;
      this.bus.push(data.block);
      this.wave = data.wave;
      if (data.recorded) this.chunks.push(data.recorded);
      this.status.position = data.position;
      this.status.duration = data.duration;
      this.status.rms = data.rms;
      if (this.status.recording) this.status.recordedSeconds += (data.recorded?.length ?? 0) / this.bus.sampleRate;
      if (performance.now() - this.lastNotify > 100) { this.lastNotify = performance.now(); this.notify(); }
    } else if (data.type === 'configured') {
      this.bus.frame = data.frame;
      this.bus.notify();
    } else if (data.type === 'started') {
      this.bus.clear();
      this.bus.frame = data.frame;
      if (data.mode === 'strudel' && data.generation !== this.generation) {
        this.bus.notify();
        return;
      }
      this.bus.running = true;
      this.bus.inputLevel = 0;
      this.bus.notify();
      this.notify({ playing: true, mode: data.mode, position: 0, error: null });
    } else if (data.type === 'record-started') {
      this.chunks = [];
      this.notify({ recording: true, recordedSeconds: 0 });
    } else if (data.type === 'record-finished') {
      const metadata = data.metadata as SessionMetadata;
      const pcm = new Float32Array(metadata.sampleCount);
      let cursor = 0;
      for (const chunk of this.chunks) { pcm.set(chunk, cursor); cursor += chunk.length; }
      this.chunks = [];
      this.notify({ recording: false, session: { metadata, pcm }, recordedSeconds: metadata.sampleCount / metadata.sampleRate });
    } else if (data.type === 'ended' || data.type === 'stopped') {
      this.bus.running = false;
      this.bus.inputLevel = 0;
      if (data.frame) { this.bus.clear(); this.bus.frame = data.frame; }
      this.bus.notify();
      this.notify({ playing: false, recording: false, rms: 0 });
    } else if (data.type === 'error') this.fail(new Error(data.message));
  }

  private fail(error: unknown) {
    ++this.generation;
    this.strudel?.pause();
    this.releaseMicrophone();
    this.bus.running = false;
    this.bus.inputLevel = 0;
    this.bus.notify();
    this.node?.port.postMessage({ type: 'pause' });
    this.node?.port.postMessage({ type: 'record-stop' });
    const name = error instanceof DOMException ? error.name : '';
    const message = name === 'NotAllowedError' ? 'Microphone access was denied. Allow it in browser settings, or try a demo or audio file.'
      : name === 'NotFoundError' ? 'No microphone was found. Connect one, or try a demo or audio file.'
      : name === 'NotReadableError' ? 'The microphone is unavailable. Check whether another app is using it.'
      : error instanceof Error ? error.message : String(error);
    this.notify({ playing: false, recording: false, error: message });
  }

  private releaseMicrophone() {
    this.microphone?.disconnect(); this.microphone = null;
    this.stream?.getTracks().forEach((track) => track.stop()); this.stream = null;
  }

  private async getStrudel(): Promise<StrudelRuntime> {
    if (this.strudel) return this.strudel;
    if (!this.loadingStrudel) {
      this.loadingStrudel = (async () => {
        const { createStrudelRuntime } = await import('./strudel');
        if (this.disposed) throw new Error('Audio controller has been closed.');
        const runtime = await createStrudelRuntime(this.context!, this.node!);
        if (this.disposed) {
          runtime.dispose();
          throw new Error('Audio controller has been closed.');
        }
        this.strudel = runtime;
        return runtime;
      })().finally(() => { this.loadingStrudel = null; });
    }
    return this.loadingStrudel;
  }

  private stopStrudel() {
    this.strudel?.stop();
    this.activePattern = null;
  }

  async playStrudel(code: string): Promise<boolean> {
    const generation = ++this.generation;
    try {
      await this.ensure();
      if (generation !== this.generation) return false;
      const runtime = await this.getStrudel();
      if (generation !== this.generation) return false;
      this.releaseMicrophone();
      await runtime.play(code);
      if (generation !== this.generation) return false;
      if (this.activePattern === null) {
        this.bus.config = { ...this.config };
        this.node!.port.postMessage({ type: 'source', mode: 'strudel', generation });
      } else if (!this.status.playing) {
        this.node!.port.postMessage({ type: 'resume' });
      }
      // A hot edit keeps the mechanical state, trail, and recording in progress.
      this.activePattern = code;
      this.bus.running = true;
      this.bus.notify();
      this.notify({ mode: 'strudel', playing: true, error: null });
      return true;
    } catch (error) {
      if (generation === this.generation) {
        this.notify({ error: error instanceof Error ? error.message : String(error) });
      }
      return false;
    }
  }

  async playDemo(preset: DemoPreset = this.preset, frequency = this.frequency) {
    const generation = ++this.generation;
    this.stopStrudel();
    try {
      await this.ensure();
      if (generation !== this.generation) return;
      this.releaseMicrophone();
      this.preset = preset; this.frequency = frequency;
      this.bus.config = { ...this.config };
      this.node!.port.postMessage({ type: 'source', mode: 'demo', demo: preset, frequency });
    } catch (error) { if (generation === this.generation) this.fail(error); }
  }

  async startMicrophone() {
    const generation = ++this.generation;
    this.stopStrudel();
    try {
      if (!navigator.mediaDevices?.getUserMedia) throw new Error('Microphone input needs localhost or HTTPS and a browser with microphone support.');
      await this.ensure();
      if (generation !== this.generation) return;
      this.node!.port.postMessage({ type: 'stop' });
      this.releaseMicrophone();
      const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false } });
      if (generation !== this.generation || this.disposed) { stream.getTracks().forEach((track) => track.stop()); return; }
      this.stream = stream;
      this.microphone = this.context!.createMediaStreamSource(stream);
      this.microphone.connect(this.node!);
      stream.getAudioTracks()[0]?.addEventListener('ended', () => { if (this.stream === stream) this.fail(new Error('The microphone was disconnected. Connect it and try again.')); });
      this.bus.config = { ...this.config };
      this.node!.port.postMessage({ type: 'source', mode: 'mic' });
    } catch (error) { if (generation === this.generation) this.fail(error); }
  }

  async loadFile(file: File): Promise<boolean> {
    const generation = ++this.generation;
    this.stopStrudel();
    try {
      if (file.size > 50 * 1024 * 1024) throw new Error('Choose an audio file smaller than 50 MB. Short clips keep this local experiment responsive.');
      await this.ensure();
      const bytes = await file.arrayBuffer();
      let decoded: AudioBuffer;
      try { decoded = await this.context!.decodeAudioData(bytes); }
      catch { throw new Error('This audio file could not be decoded. Try WAV, MP3, M4A, or OGG supported by your browser.'); }
      if (decoded.duration > 600) throw new Error('Choose a clip of 10 minutes or less. Recording and session export support up to 60 seconds.');
      if (generation !== this.generation) return false;
      const pcm = new Float32Array(decoded.length);
      for (let channel = 0; channel < decoded.numberOfChannels; channel++) {
        const samples = decoded.getChannelData(channel);
        for (let i = 0; i < pcm.length; i++) pcm[i] += samples[i] / decoded.numberOfChannels;
      }
      this.filePcm = pcm;
      this.releaseMicrophone();
      this.bus.config = { ...this.config };
      this.node!.port.postMessage({ type: 'source', mode: 'file', pcm });
      return true;
    } catch (error) { if (generation === this.generation) this.fail(error); return false; }
  }

  pause() {
    ++this.generation;
    this.strudel?.pause();
    this.node?.port.postMessage({ type: 'pause' });
    this.bus.running = false; this.bus.inputLevel = 0;
    this.bus.notify(); this.notify({ playing: false });
  }
  async resume() {
    const generation = ++this.generation;
    try {
      await this.ensure();
      if (generation !== this.generation) return;
      if (this.activePattern !== null) {
        await this.strudel!.resume();
        if (generation !== this.generation) return;
      }
      this.node!.port.postMessage({ type: 'resume' }); this.bus.running = true; this.bus.notify(); this.notify({ playing: true });
    } catch (error) { if (generation === this.generation) this.fail(error); }
  }
  stop() {
    ++this.generation;
    this.stopStrudel(); this.releaseMicrophone();
    this.bus.config = { ...this.config };
    this.node?.port.postMessage({ type: 'stop' });
    this.bus.running = false; this.bus.inputLevel = 0;
    this.bus.notify(); this.notify({ playing: false, mode: null, position: 0, rms: 0 });
  }
  async playFile() {
    if (!this.filePcm) return;
    const generation = ++this.generation;
    this.stopStrudel();
    try {
      await this.ensure();
      if (generation !== this.generation) return;
      this.releaseMicrophone();
      this.bus.config = { ...this.config };
      this.node!.port.postMessage({ type: 'source', mode: 'file', pcm: this.filePcm });
    } catch (error) { if (generation === this.generation) this.fail(error); }
  }
  async restart() {
    if (this.activePattern !== null) {
      const code = this.activePattern;
      this.stop();
      return this.playStrudel(code);
    }
    if (this.status.mode === 'mic') return this.startMicrophone();
    if (this.status.mode === 'replay') return this.replayRecording();
    if (this.status.mode === 'file') return this.playFile();
    return this.playDemo();
  }
  setConfig(patch: Partial<SimulationConfig>) {
    this.config = { ...this.config, ...patch };
    this.bus.config = { ...this.config };
    this.node?.port.postMessage({ type: 'config', patch });
    if (!this.node) this.bus.frame = new Simulator(this.config).getFrame();
    this.bus.notify();
  }
  setAudible(value: boolean) { this.audible = value; this.node?.port.postMessage({ type: 'monitor', value }); }
  setLoop(value: boolean) { this.loop = value; this.node?.port.postMessage({ type: 'loop', value }); }
  startRecording() { if (this.status.playing && this.status.mode !== 'replay') this.node?.port.postMessage({ type: 'record-start' }); }
  finishRecording() { this.node?.port.postMessage({ type: 'record-stop' }); }
  async replayRecording() {
    if (!this.status.session) return;
    const generation = ++this.generation;
    this.stopStrudel();
    try {
      await this.ensure();
      if (generation !== this.generation) return;
      this.releaseMicrophone();
      this.bus.config = { ...this.status.session.metadata.initialConfig };
      this.node!.port.postMessage({ type: 'replay', session: this.status.session });
    } catch (error) { if (generation === this.generation) this.fail(error); }
  }
  dispose() {
    this.disposed = true;
    ++this.generation;
    this.strudel?.dispose();
    this.releaseMicrophone();
    this.node?.disconnect();
    void this.context?.close();
    this.listeners.clear();
  }
}
