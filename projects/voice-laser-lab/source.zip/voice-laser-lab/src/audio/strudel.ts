import {
  defaultPrebake, getSuperdoughAudioController, initAudio, loadBuffer,
  miniAllStrings, samples, setSuperdoughAudioController, transpiler, webaudioRepl,
} from '../../vendor/strudel-web-1.3.0/index.mjs';
import { assetPath } from '../asset-path';

export interface StrudelRuntime {
  play(code: string): Promise<void>;
  pause(): void;
  resume(): Promise<void>;
  stop(): void;
  dispose(): void;
}

// SuperDough caches decode promises by URL, including rejected promises.
// Retry just the failed kit entry with a fresh URL on the next Play.
const sampleRetries = new Map<string, number>();

async function loadKit(context: AudioContext) {
  const entries = await Promise.all(['bd', 'sd', 'hh'].map(async name => {
    const url = new URL(assetPath(`audio/strudel/${name}.wav`), document.baseURI);
    const key = url.href;
    const attempt = sampleRetries.get(key) ?? 0;
    if (attempt) url.searchParams.set('retry', String(attempt));
    try { await loadBuffer(url.href, context, name); }
    catch {
      sampleRetries.set(key, attempt + 1);
      throw new Error(`Could not load the local drum sample "${name}". Try Play again.`);
    }
    return [name, url.href];
  }));
  await samples(Object.fromEntries(entries));
}

/** Strudel has one mixer per window. The lab owns the shared AudioContext and the speaker output. */
export async function createStrudelRuntime(context: AudioContext, destination: AudioNode): Promise<StrudelRuntime> {
  // The lower-level REPL uses the context already unlocked by the player's gesture.
  // It doesn't install the standalone editor's document-wide first-click handler.
  miniAllStrings();
  const repl = webaudioRepl({ audioContext: context, transpiler });
  setSuperdoughAudioController(null);
  const mixer = getSuperdoughAudioController();
  mixer.output.destinationGain.disconnect();

  await Promise.all([defaultPrebake(), initAudio()]);
  // Decode before the scheduler starts, so the first kick arrives on time.
  await loadKit(context);

  let playing = false;
  let disposed = false;
  let generation = 0;
  let pending = Promise.resolve();
  let acceptedPattern: unknown;

  function silence() {
    if (!playing) return;
    playing = false;
    // Reset removes the old orbits and reverb tails. SuperDough creates a new
    // master connected to the speakers during reset; detach it synchronously.
    mixer.reset();
    mixer.output.destinationGain.disconnect();
  }

  async function start(version: number) {
    if (disposed || version !== generation || playing || !acceptedPattern) return;
    await repl.start();
    if (disposed || version !== generation) {
      repl.pause();
      return;
    }
    mixer.output.destinationGain.connect(destination);
    playing = true;
  }

  return {
    play(code) {
      const version = ++generation;
      const evaluate = async () => {
        if (disposed || version !== generation) return;
        // Compile without autostart. On a syntax error the REPL leaves its
        // scheduler on the last good pattern and exposes the error in state.
        const pattern = await repl.evaluate(code, false);
        if (disposed || version !== generation) {
          if (acceptedPattern) await repl.setPattern(acceptedPattern, false);
          return;
        }
        if (repl.state.evalError) throw repl.state.evalError;
        acceptedPattern = pattern;
        await start(version);
      };
      const result = pending.then(evaluate);
      pending = result.catch(() => {});
      return result;
    },
    resume() {
      const version = ++generation;
      return pending.then(() => start(version));
    },
    pause() {
      generation++;
      if (disposed) return;
      repl.pause();
      silence();
    },
    stop() {
      generation++;
      if (disposed) return;
      repl.stop();
      silence();
    },
    dispose() {
      if (disposed) return;
      disposed = true;
      generation++;
      repl.stop();
      silence();
    },
  };
}
