import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { copyFile, mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { writeSourceArchive } from './build-source.mjs';

const root = fileURLToPath(new URL('../', import.meta.url));
const output = path.join(root, 'dist-pages');

for (const args of [
  ['scripts/build-audio.mjs'],
  ['--import', 'tsx', 'scripts/build-poster.mjs'],
  ['node_modules/vite/bin/vite.js', 'build', '--config', 'vite.pages.config.ts'],
]) {
  const result = spawnSync(process.execPath, args, { cwd: root, stdio: 'inherit' });
  if (result.error) throw result.error;
  if (result.status !== 0) process.exit(result.status ?? 1);
}

// Publish only known runtime assets and their provenance, never local settings,
// source maps, server scaffolding, or future unrelated public files.
const assets = [
  'favicon.svg',
  'audio/strudel/bd.wav',
  'audio/strudel/sd.wav',
  'audio/strudel/hh.wav',
  'generated/audio-processor.js',
  'generated/session-export.js',
  'generated/inverse-worker.js',
  'generated/physics-poster.png',
  'generated/physics-poster.svg',
  'models/human/speaker.glb',
  'models/human/CC0-1.0.txt',
  'models/human/README.md',
  'models/human/source-metadata.json',
  'art/john-berger-yasmine-hamdan.png',
  'art/john-berger-source.json',
];
for (const asset of assets) {
  const destination = path.join(output, asset);
  await mkdir(path.dirname(destination), { recursive: true });
  if (asset.endsWith('.js')) {
    const source = await readFile(path.join(root, 'public', asset), 'utf8');
    await writeFile(destination, source.replace(/^\/\/# sourceMappingURL=.*\r?\n?/gm, ''));
  } else {
    try {
      await copyFile(path.join(root, 'public', asset), destination);
    } catch (error) {
      // The source ZIP links to this separately copyrighted illustration.
      if (error.code !== 'ENOENT' || asset !== 'art/john-berger-yasmine-hamdan.png') throw error;
      const url = 'https://raw.githubusercontent.com/shayshay42/shayshay42.github.io/7c627ee8e56f3f1197a8a17b0461efb626f09f42/projects/voice-laser-lab/' + asset;
      const response = await fetch(url);
      if (!response.ok) throw new Error(`Could not retrieve the Berger illustration (HTTP ${response.status}).`);
      const bytes = Buffer.from(await response.arrayBuffer());
      const { sha256 } = JSON.parse(await readFile(path.join(root, 'public/art/john-berger-source.json'), 'utf8'));
      if (createHash('sha256').update(bytes).digest('hex') !== sha256) throw new Error('Berger illustration checksum mismatch.');
      await writeFile(destination, bytes);
    }
  }
}

const notices = [
  'Voice Laser Lab — third-party notices',
  'The human display mesh is CC0. See models/human/README.md and CC0-1.0.txt.',
  'Sketch of Yasmine Hamdan by John Berger. Image source: Hummus for Thought, “Listening: The Aural Resonance of a Formless Line” (2018). See art/john-berger-source.json for source and attribution details.',
  'The kick, snare, and hi-hat are original synthesized one-shots for Voice Laser Lab.',
  'The optional piano preset streams Salamander Grand Piano V3 by Alexander Holm (CC BY 3.0), via felixroos/dough-samples. https://archive.org/details/SalamanderGrandPianoV3 — https://creativecommons.org/licenses/by/3.0/ — https://github.com/felixroos/dough-samples',
];
const strudelLicense = await readFile(path.join(root, 'vendor/strudel-web-1.3.0/LICENSE'), 'utf8');
notices.push(`Strudel (@strudel/web 1.3.0), copyright Strudel contributors — AGPL-3.0-or-later\nhttps://strudel.cc/\nCorresponding upstream source: https://codeberg.org/uzu/strudel/archive/f610965f4332837febe45743105da170e8b331ed.tar.gz\n\n${strudelLicense.trim()}`);
for (const name of ['react', 'react-dom', 'scheduler', 'three', 'fflate', 'mathjax-full']) {
  const packageRoot = path.join(root, 'node_modules', name);
  const metadata = JSON.parse(await readFile(path.join(packageRoot, 'package.json'), 'utf8'));
  const license = await readFile(path.join(packageRoot, 'LICENSE'), 'utf8');
  notices.push(`${name} ${metadata.version} (${metadata.license})\n\n${license.trim()}`);
}
await writeFile(path.join(output, 'THIRD-PARTY-NOTICES.txt'), `${notices.join('\n\n---\n\n')}\n`);
await copyFile(path.join(root, 'LICENSE.txt'), path.join(output, 'LICENSE.txt'));
await writeSourceArchive(root, output, assets);
console.log('Static Pages export is ready in dist-pages/.');
