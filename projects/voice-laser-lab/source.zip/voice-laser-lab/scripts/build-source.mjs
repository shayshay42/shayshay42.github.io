import { glob, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { strToU8, zipSync } from 'fflate';

// Ship the source of the Pages application, including its worklets and inverse
// worker. Keep hardware experiments and the separate hosting scaffold private.
const sourcePatterns = [
  'LICENSE.txt', 'SOURCE.md', 'package-lock.json', 'tsconfig.json',
  'vite.pages.config.ts', 'postcss.config.mjs', 'app/globals.css',
  'scripts/build-{audio,pages,poster,source}.mjs', 'docs/physics.md',
  'pages/{index.html,main.tsx,notebook.css}', 'src/asset-path.ts',
  'src/components/*.tsx', 'src/{audio,physics,session,visuals}/*.ts',
  'src/inverse/{InverseLab.tsx,inverse.css,worker.ts}',
  'src/inverse/{contours,geometry-seeds,outline-error,shape-fit,solver,tuning}{,.test}.ts',
  'vendor/strudel-web-1.3.0/{LICENSE,README.md,index.mjs,index.d.mts}',
  'vendor/strudel-web-1.3.0/assets/*.js',
];

export async function writeSourceArchive(root, output, assets) {
  const files = new Map();
  for await (const file of glob(sourcePatterns, { cwd: root })) {
    const name = file.split(path.sep).join('/');
    files.set(name, await readFile(path.join(root, file)));
  }
  for (const asset of assets) {
    if (asset.startsWith('generated/') || asset === 'art/john-berger-yasmine-hamdan.png') continue;
    files.set('public/' + asset, await readFile(path.join(root, 'public', asset)));
  }
  const manifest = JSON.parse(await readFile(path.join(root, 'package.json'), 'utf8'));
  // Keep the locked dependency graph and expose only commands for this source tree.
  manifest.license = 'AGPL-3.0-or-later';
  manifest.scripts = {
    'build:pages': 'node scripts/build-pages.mjs',
    test: manifest.scripts.test,
    typecheck: 'tsc --noEmit',
  };
  files.set('package.json', strToU8(JSON.stringify(manifest, null, 2) + '\n'));
  files.set('THIRD-PARTY-NOTICES.txt', await readFile(path.join(output, 'THIRD-PARTY-NOTICES.txt')));

  const entries = Object.fromEntries([...files.keys()].sort().map(name => ['voice-laser-lab/' + name, files.get(name)]));
  const archive = zipSync(entries, { level: 6, mtime: new Date(2000, 0, 1) });
  await writeFile(path.join(output, 'source.zip'), archive);
}
