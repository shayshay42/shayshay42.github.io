/**
 * Typeset the complete poster with MathJax, then rasterize its self-contained
 * SVG for the Three.js texture. Run with: node --import tsx scripts/build-poster.mjs
 * Every visible glyph is a path. No browser fonts or remote assets are needed.
 */
import { mkdir, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import sharp from 'sharp';
import { mathjax } from 'mathjax-full/js/mathjax.js';
import { TeX } from 'mathjax-full/js/input/tex.js';
import { SVG } from 'mathjax-full/js/output/svg.js';
import { liteAdaptor } from 'mathjax-full/js/adaptors/liteAdaptor.js';
import { RegisterHTMLHandler } from 'mathjax-full/js/handlers/html.js';
import { AllPackages } from 'mathjax-full/js/input/tex/AllPackages.js';
import { POSTER_COPY } from '../src/visuals/poster-copy.ts';

const adaptor = liteAdaptor();
RegisterHTMLHandler(adaptor);
const document = mathjax.document('', {
  InputJax: new TeX({ packages: AllPackages }),
  OutputJax: new SVG({ fontCache: 'none', mtextInheritFont: false }),
});
const WIDTH = 1800;
const HEIGHT = 2200;
const MARGIN = 124;
const CONTENT_WIDTH = WIDTH - MARGIN * 2;
const INK = '#292b28';
const MUTED = '#74766e';
const RED = '#b3473d';
const parts = [];
const cache = new Map();
const bounds = [];

function xml(value) {
  return value.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;').replaceAll("'", '&apos;');
}
function escapeText(value) {
  return value.replace(/[\\{}%$&#_^]/g, character => ({
    '\\': '\\textbackslash{}', '{': '\\{', '}': '\\}', '%': '\\%', '$': '\\$',
    '&': '\\&', '#': '\\#', '_': '\\_', '^': '\\textasciicircum{}',
  })[character]);
}
function proseTex(value, bold = false) {
  return `\\${bold ? 'textbf' : 'text'}{${escapeText(value)}}`;
}
function typeset(tex) {
  if (cache.has(tex)) return cache.get(tex);
  const node = document.convert(tex, { display: true });
  const svg = adaptor.firstChild(node);
  const viewBox = adaptor.getAttribute(svg, 'viewBox').split(/\s+/).map(Number);
  const inner = adaptor.innerHTML(svg);
  if (inner.includes('data-mml-node="merror"') || /<(?:text|use)\b/.test(inner)) {
    throw new Error(`Poster must contain valid, self-contained path glyphs: ${tex}`);
  }
  const result = { viewBox, inner };
  cache.set(tex, result);
  return result;
}
function measure(tex, size) {
  return typeset(tex).viewBox[2] * size / 1000;
}
function put(tex, x, baseline, size, color = INK, maxWidth = CONTENT_WIDTH) {
  const { viewBox, inner } = typeset(tex);
  const scale = Math.min(size / 1000, maxWidth / viewBox[2]);
  const width = viewBox[2] * scale;
  const height = viewBox[3] * scale;
  const top = baseline + viewBox[1] * scale;
  bounds.push({ tex, left: x, top, right: x + width, bottom: top + height });
  parts.push(`<svg x="${x}" y="${top}" width="${width}" height="${height}" viewBox="${viewBox.join(' ')}" color="${color}" data-tex="${xml(tex)}">${inner}</svg>`);
}
function prose(value, x, baseline, size, color = INK, bold = false, maxWidth = CONTENT_WIDTH) {
  put(proseTex(value, bold), x, baseline, size, color, maxWidth);
}
function paragraph(value, baseline, size, lineHeight, color = INK) {
  let line = '';
  for (const word of value.split(' ')) {
    const next = line ? `${line} ${word}` : word;
    if (line && measure(proseTex(next), size) > CONTENT_WIDTH) {
      prose(line, MARGIN, baseline, size, color);
      baseline += lineHeight;
      line = word;
    } else line = next;
  }
  if (line) prose(line, MARGIN, baseline, size, color);
  return baseline;
}
function definition(value, symbol, x, baseline, size = 38, maxWidth = CONTENT_WIDTH) {
  const description = value.slice(value.indexOf(':') + 1).trim();
  put(`${symbol}:\\enspace${proseTex(description)}`, x, baseline, size, MUTED, maxWidth);
}
function rule(y) {
  parts.push(`<path d="M${MARGIN} ${y}H${WIDTH - MARGIN}" stroke="#dad9cf" stroke-width="2"/>`);
}
put(POSTER_COPY.title.split('→').map(word => proseTex(word.trim(), true)).join('\\;\\rightarrow\\;'), MARGIN, 156, 74);
put(String.raw`u(t)\;\longrightarrow\;\mathbf{q}(t)\;\longrightarrow\;(\mathbf{c},\mathbf{n})\;\longrightarrow\;(X,Y)`, MARGIN, 258, 63, RED);
put(String.raw`\mathbf{s}=(\mathbf{q},\dot{\mathbf{q}}),\qquad \dot{\mathbf{s}}=A\mathbf{s}+Bu,\qquad (X,Y)=H(\mathbf{s})`, MARGIN, 350, 49);
prose(POSTER_COPY.summary, MARGIN, 410, 31);
const systemSymbols = ['A', 'B', 'H', String.raw`\dot{q}`];
const systemX = [MARGIN, 430, 745, 1280];
POSTER_COPY.system.forEach((value, i) => definition(value, systemSymbols[i], systemX[i], 458, 27, i === 2 ? 490 : 300));
rule(492);

prose(POSTER_COPY.audio.title, MARGIN, 555, 43, INK, true);
put(String.raw`\frac{\mathrm{d}^{2}q_i}{\mathrm{d}t^{2}}+2\zeta_i\omega_i\frac{\mathrm{d}q_i}{\mathrm{d}t}+\omega_i^{2}q_i=\beta_i u(t),\quad i=1,\ldots,6`, MARGIN + 16, 661, 62, INK, CONTENT_WIDTH - 32);
put(String.raw`\beta_i=1800\,G\,\alpha_i`, MARGIN, 738, 42);
const audioSymbols = ['u', 'G', 't', 'q_i', String.raw`\zeta_i`, String.raw`\omega_i`, String.raw`\alpha_i`];
const audioX = [MARGIN + 700, MARGIN + 1080, MARGIN + 1370, MARGIN, MARGIN + 400, MARGIN + 780, MARGIN + 1310];
POSTER_COPY.audio.variables.forEach((value, i) => definition(value, audioSymbols[i], audioX[i], i < 3 ? 738 : 797, 28, i === 5 ? 485 : i === 2 ? 180 : i === 6 ? 245 : 365));
prose(POSTER_COPY.audio.note, MARGIN, 852, 30, MUTED);
rule(884);

prose(POSTER_COPY.mirror.title, MARGIN, 948, 43, INK, true);
put(String.raw`\textstyle w(x,y,t)=\sum_{i=1}^{6}\phi_i(x,y)\,q_i(t)`, MARGIN, 1039, 53);
put(String.raw`\mathbf{c}=(0,0,\mathbf{h}^{\mathsf T}\mathbf{q}),\qquad g_x=\mathbf{k}_x^{\mathsf T}\mathbf{q},\quad g_y=\mathbf{k}_y^{\mathsf T}\mathbf{q}`, MARGIN, 1110, 49);
put(String.raw`\mathbf{n}=\frac{(-g_x,-g_y,1)}{\sqrt{1+g_x^2+g_y^2}}`, MARGIN, 1194, 42);
prose(POSTER_COPY.mirror.note, MARGIN + 710, 1192, 29, MUTED, false, 840);
const mirrorSymbols = ['w', String.raw`\phi_i`, String.raw`\mathbf{c}`, 'g_x,g_y', String.raw`\mathbf{n}`, String.raw`\mathbf{h},\mathbf{k}_x,\mathbf{k}_y`];
const mirrorX = [MARGIN, MARGIN + 520, MARGIN + 1080];
POSTER_COPY.mirror.variables.forEach((value, i) => definition(value, mirrorSymbols[i], mirrorX[i % 3], i < 3 ? 1301 : 1352, 29, 485));
rule(1388);

prose(POSTER_COPY.ray.title, MARGIN, 1452, 43, INK, true);
put(String.raw`\mathbf{d}=-\frac{\mathbf{a}}{\|\mathbf{a}\|},\qquad \tau=\frac{(\mathbf{c}-\mathbf{a})\cdot\mathbf{n}}{\mathbf{d}\cdot\mathbf{n}}`, MARGIN, 1540, 47);
put(String.raw`\mathbf{m}=\mathbf{a}+\tau\mathbf{d},\qquad \mathbf{r}=\mathbf{d}-2(\mathbf{d}\cdot\mathbf{n})\mathbf{n}`, MARGIN, 1630, 50);
put(String.raw`\begin{pmatrix}X\\Y\end{pmatrix}=\begin{pmatrix}m_x\\m_y\end{pmatrix}+\frac{L-m_z}{r_z}\begin{pmatrix}r_x\\r_y\end{pmatrix}`, MARGIN, 1740, 61, RED);
const raySymbols = [String.raw`\mathbf{a}`, String.raw`\mathbf{d}`, String.raw`\mathbf{r}`, String.raw`\tau`, String.raw`\mathbf{m}`, 'L', 'X,Y'];
POSTER_COPY.ray.variables.forEach((value, i) => {
  const x = i < 4 ? MARGIN + i * 390 : MARGIN + (i - 4) * 520;
  definition(value, raySymbols[i], x, i < 4 ? 1831 : 1878, 28, i < 4 ? 370 : 500);
});
prose(POSTER_COPY.ray.miss, MARGIN, 1927, 30, MUTED);
rule(1960);
POSTER_COPY.notes.forEach((value, i) => prose(value, MARGIN, 2013 + i * 47, 30, i === 3 ? INK : MUTED));

for (const box of bounds) {
  if (box.left < 0 || box.top < 0 || box.right > WIDTH || box.bottom > HEIGHT) {
    throw new Error(`Poster content exceeds its frame: ${box.tex}`);
  }
}
for (let i = 0; i < bounds.length; i++) {
  for (let j = i + 1; j < bounds.length; j++) {
    const a = bounds[i];
    const b = bounds[j];
    if (Math.min(a.right, b.right) > Math.max(a.left, b.left)
      && Math.min(a.bottom, b.bottom) > Math.max(a.top, b.top)) {
      throw new Error(`Poster elements overlap: ${JSON.stringify({ a, b })}`);
    }
  }
}
const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${WIDTH}" height="${HEIGHT}" viewBox="0 0 ${WIDTH} ${HEIGHT}" role="img" aria-labelledby="poster-title">
<title id="poster-title">The driven dynamical system from mono audio to membrane modes, mirror pose, and laser coordinates on the wall.</title>
<rect width="${WIDTH}" height="${HEIGHT}" fill="#fffdf6"/>
${parts.join('\n')}
</svg>\n`;
if (/<(?:text|use|foreignObject)\b|font-family=|(?:href|src)="https?:/i.test(svg)) {
  throw new Error('Poster has an external font, glyph reference, or non-path text.');
}
const output = fileURLToPath(new URL('../public/generated/', import.meta.url));
await mkdir(output, { recursive: true });
await writeFile(path.join(output, 'physics-poster.svg'), svg);
// 108 dpi rasterizes the 1800 × 2200 vector page directly to 2700 × 3300.
await sharp(Buffer.from(svg), { density: 108 }).png({ compressionLevel: 9 }).toFile(path.join(output, 'physics-poster.png'));
console.log('Poster: MathJax path SVG and 2700 × 3300 PNG generated.');
