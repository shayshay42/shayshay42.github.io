import { build } from 'esbuild';

await build({
  entryPoints: {
    'audio-processor': 'src/audio/processor.ts',
    'session-export': 'src/audio/export-worker.ts',
    'inverse-worker': 'src/inverse/worker.ts',
  },
  outdir: 'public/generated',
  bundle: true,
  format: 'esm',
  target: 'es2022',
  sourcemap: true,
});
